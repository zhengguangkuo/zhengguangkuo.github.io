//
//  UIImageView+DispatchLoad.m
//  M-Pay
//
//  Created by guorong on 14-2-24.
//  Copyright miteno 2014年. All rights reserved.
//

#import "UIImageView+DispatchLoad.h"
#import "FileManager.h"
#import "UIView(Animation).h"
#import "UIImage+Image.h"
#import "UIProgressHud.h"

static dispatch_group_t group;

static dispatch_semaphore_t semaphore;

static UIProgressHud*  sharedHud2;

static NSOperationQueue*  sharedQueue3;



@implementation UIImageView (DispatchLoad)

#pragma mark- download image and refresh
//多线程下载图片，传参url
- (void) setImageFromUrl:(NSString*)urlString {
    //[self setImageFromUrl:urlString withHud:NO];
    [self setImageFromUrl:urlString completion:NULL animate:NO];

    
}



- (void) setImageFromUrl:(NSString*)urlString withHud:(BOOL)hudFlag
{
    //[self setImageFromUrl:urlString withHud:hudFlag animate:NO];
    [self setImageFromUrl:urlString completion:NULL animate:NO];
}


//- (void) setImageFromUrl:(NSString*)urlString withHud:(BOOL)hudFlag animate:(BOOL)bFlag
//{
//    if(!sharedHud2)
//    {
//        static dispatch_once_t oncePredicate2;
//        dispatch_once(&oncePredicate2, ^{
//            sharedHud2 = [[UIProgressHud alloc] init];
//        });
//    }
//
//    if(!group)
//    {
//        static dispatch_once_t oncePredicate4;
//        dispatch_once(&oncePredicate4, ^{
//            group = dispatch_group_create();
//            semaphore = dispatch_semaphore_create(6);
//        });
//    }
//    
//    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
//    dispatch_group_async(group, queue, ^{
//        if(hudFlag)
//        [sharedHud2  startWaiting];
//        
//        [self setImageFromUrl:urlString completion:NULL animate:bFlag];
//        dispatch_semaphore_signal(semaphore);
//    });
//    
//#if !OS_OBJECT_USE_OBJC
//    dispatch_release(queue);
//#endif
//    
//    dispatch_group_notify(group, dispatch_get_main_queue(),
//    ^{
//         //NSLog(@"end");
//         if(hudFlag)
//         [sharedHud2 stopWaiting];
//    });
//}


- (void) setImageFromUrl:(NSString*)urlString
              completion:(void (^)(void))completion animate:(BOOL)bFlag
{
    //__unsafe_unretained id blockSelf = self;
    
    //void (^blk)(id) = [completion copy];//blkInHeap在堆里
    

//    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
    
    if(!sharedQueue3)
    {
        static dispatch_once_t oncePredicate;
        dispatch_once(&oncePredicate, ^{
            sharedQueue3 = [[NSOperationQueue alloc] init];
            [sharedQueue3 setMaxConcurrentOperationCount:6];
        });
    }
    if([FileManager isFileExist:[urlString lastPathComponent]])
        {
            UIImage *avatarImage = [UIImage imageWithContentsOfFile:[FileManager dataFilePath:[urlString lastPathComponent]]];
//            UIImage *avatarImage = [newImage stretchableImageWithLeftCapWidth:newImage.size.width*0.5 topCapHeight:newImage.size.height*0.5];
            
            if(completion)
            {
                completion();
            }
            
            dispatch_async(dispatch_get_main_queue(),
           ^{
               [self setImage:avatarImage];
            });
        }
        else
        {
            __block UIImage *avatarImage = nil;
            NSURL *url = [NSURL URLWithString:urlString];
//            NSData *responseData=[NSData dataWithContentsOfURL:url];
   
            NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
            [request setURL:url];
            [request setHTTPMethod:@"GET"];
            [request setTimeoutInterval:5.0];
//
//            NSError *error = nil;
//            NSData *responseData = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:&error];
    
            //NSData *responseData=[NSData dataWithContentsOfURL:url];
            [NSURLConnection sendAsynchronousRequest:request queue:sharedQueue3 completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
                
                if(data)
                {
                    avatarImage = [UIImage imageWithData:data];
                if(avatarImage)
                {
                    [data writeToFile:[FileManager dataFilePath:[urlString lastPathComponent]] atomically:NO];
                    if(completion)
                        {
                            completion();
                        }
                        
                        dispatch_async(dispatch_get_main_queue(),
                        ^{
                            [self setImage:avatarImage];
                        });
                        
                    }
                    else
                {
                    NSLog(@"-- impossible download: %@", urlString);
                    [self setImage:[UIImage imageNamed:@"load.png"]];
                }

                }
                
            }];
        }
//    });
}


//多线程下载图片，传参url以及block
- (void) setImageFromUrl:(NSString*)urlString
              completion:(void (^)(void))completion
{
    [self setImageFromUrl:urlString completion:completion animate:NO];
}

#pragma mark- refresh image from assign path
//二进制转为图片，并保存,参数为路径以及block
- (void) setImageFromData:(NSData*)cachedata  targetPath:(NSString*)pathName completion:(void (^)(void))block
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
    if(![cachedata isKindOfClass:[NSNull class]]){
        UIImage* cacheImage = [UIImage imageWithData:cachedata];
       if(cacheImage){
        [cachedata writeToFile:[FileManager dataFilePath:[pathName lastPathComponent]] atomically:NO];
        if(block){
              dispatch_async(dispatch_get_main_queue(),block);
         }else{
            dispatch_async(dispatch_get_main_queue(),
           ^{
              [self setImage:cacheImage];
            });
         }
      }
    }
    else{
       NSLog(@"empty data!");
    }
    
  });
}


//二进制转为图片，并保存,参数为路径
- (void) setImageFromData:(NSData *)cachedata targetPath:(NSString *)pathName
{
   [self setImageFromData:cachedata targetPath:pathName completion:NULL];
}


//从目标路径读取图片
- (void) setImageFromCache:(NSString*)pathName
{
     if([FileManager isFileExist:[pathName lastPathComponent]])
   {
      UIImage *avatarImage = [UIImage imageWithContentsOfFile:[FileManager dataFilePath:[pathName lastPathComponent]]];
      
       dispatch_async(dispatch_get_main_queue(),
      ^{
          [self setImage:avatarImage];
       });

   }
}

@end