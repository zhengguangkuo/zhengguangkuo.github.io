//
//  UserAppId.m
//  Miteno
//
//  Created by wg on 14-4-14.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "UserAppId.h"

@implementation UserAppId
- (id)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.appId = dict[@"app_id"];
        self.userId = dict[@"user_id"];

        
    }
    return self;
}
@end
