//
//  CityView.m
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "CityView.h"
#import "CityCell.h"
#import "AreaCode.h"
#import "RegisterViewController.h"
#import "HomeViewController.h"
#define kOriginalH  44
@interface CityView()<UIGestureRecognizerDelegate,UITableViewDataSource,UITableViewDelegate>
{
    UITapGestureRecognizer * _singleRecognizer;
    UIButton               * _current;
    NSArray                * _cityData;
    UITableView            * _cityListView;
    NSUserDefaults         * _defaults;
    BOOL                     _startFirst;
    UIViewController       * _NowCtrl;
}
@end

@implementation CityView
//
- (id)aboveCtroller:(UIViewController *)ctrl cityData:(NSArray *)cityData
{
    if ([super init]) {
        _NowCtrl = ctrl;
 
        self.center = CGPointMake(ScreenWidth/2, ScreenHeight/2);
        self.bounds = CGRectMake(0, 0, ScreenWidth-20,cityData.count * kOriginalH);
        
        _bgView = [[UIView alloc] init];
        _bgView.frame = [UIScreen mainScreen].applicationFrame;
        [_bgView setBackgroundColor:kGlobalBg];
        [ctrl.view.window insertSubview:_bgView atIndex:ctrl.view.window.subviews.count];
        [ctrl.view.window insertSubview:self aboveSubview:_bgView];
        
        //添加手势
        UITapGestureRecognizer *singleRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(operationBg:)];
        singleRecognizer.delegate = self;
        self.backgroundColor = [UIColor greenColor];
        singleRecognizer.numberOfTouchesRequired = 1;
        [_bgView addGestureRecognizer:singleRecognizer];
        _cityListView = [[UITableView alloc] init];
        _cityListView.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
        _cityListView.delegate = self;
        _cityListView.dataSource = self;
        self.cityData = cityData;
        [self addSubview:_cityListView];
        
        _defaults = [NSUserDefaults standardUserDefaults];
        if ([_cityListView.delegate respondsToSelector:@selector(tableView:didSelectRowAtIndexPath:)]) {
            NSInteger row = 0;
            if ([[_defaults objectForKey:kSelectRow] integerValue]>0) {
                row = [_defaults objectForKey:kSelectRow];
            }
            NSIndexPath *selectedIndexPath = [NSIndexPath indexPathForRow:row inSection:0];
            [_cityListView selectRowAtIndexPath:selectedIndexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
        }
    }
    
    return self;
}
- (void)operationBg:(UITapGestureRecognizer*)recognizer{
    [_bgView removeFromSuperview];
        [UIView animateWithDuration:0.3 animations:^{
            self.alpha = 0.0;
            [_bgView removeFromSuperview];
        }
        completion:^(BOOL finished) {
            [self removeFromSuperview];
//            
//           if (isRetina&&![_NowCtrl isKindOfClass:[HomeViewController class]]) {
//               [self.delegate setCityIconBtnCenter];
//           }

       }];
    //底下是刪除手势的方法
    [_bgView removeGestureRecognizer:recognizer];

}
-(void)closeCityView
{
    [self operationBg:_singleRecognizer];
}
- (void) show {
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.7f];
    self.alpha=0.6;
    [self performSelectorOnMainThread:@selector(hidden:) withObject:@"name" waitUntilDone:YES];
    [self performSelectorOnMainThread:@selector(hidden:) withObject:self waitUntilDone:YES];
    [UIView commitAnimations];
}
- (void) hidden:(id)sender{
    if ([self superview]) {
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:2.7f];
        self.alpha=0.0;
        [UIView commitAnimations];
    }
}

#pragma mark -tableve delegate and datasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _cityData.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"CityCell";
    CityCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[CityCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.icon.tag = indexPath.row+10;
    }
    if ([[_defaults objectForKey:kSelectRow] integerValue]==indexPath.row) {
        cell.icon.selected = YES;
        [_cityListView selectRowAtIndexPath:[NSIndexPath indexPathForItem:[[_defaults objectForKey:kSelectRow] integerValue] inSection:0] animated:NO  scrollPosition:UITableViewScrollPositionTop];
    }
    
    AreaCode *area = _cityData[indexPath.row];
    cell.textLabel.text = area.area_name;
    return cell;
}
//选中某一行Cell
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    CityCell *cell = (CityCell *)[tableView cellForRowAtIndexPath:indexPath];
    //保存选定的row
    [_defaults setInteger:indexPath.row forKey:kSelectRow];

    UIButton *btn = (UIButton *)[tableView viewWithTag:(indexPath.row+10)];
    btn.selected = YES;
    NSString *cityName = [[DbHelper sharedDbHelper] queryCityCode:cell.textLabel.text];
    [_delegate cityName:cell.textLabel.text];
    [_delegate clickResultrow:indexPath.row];
    [_delegate cityCode:cityName];
    [_defaults setObject:cityName forKey:kCityCode];
    //关闭
    [self closeCityView];
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIButton *btn = (UIButton *)[tableView viewWithTag:(indexPath.row+10)];
    btn.selected = NO;

}
//- (void)share:(UIButton *)btn{
//    _current.selected = NO;
//    btn.selected = YES;
//    _current = btn;
//}


@end
