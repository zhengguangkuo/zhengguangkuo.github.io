//
//  BasicSettingViewController.h
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "RootViewController.h"
#import <CoreLocation/CoreLocation.h>

@interface CardBagViewController : RootViewController<UITableViewDelegate,UITableViewDataSource,CLLocationManagerDelegate>

@property (nonatomic, assign) BOOL  CardRefreshFlag;

@property (nonatomic, assign) BOOL  MerchRefreshFlag;

@property (nonatomic, assign) BOOL  UnBindBackFlag;

@property (nonatomic, assign) BOOL  DefaultBackFlag;

@end
