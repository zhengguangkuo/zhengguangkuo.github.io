//
//  Contact.h
//  Miteno
//
//  Created by wg on 14-4-2.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "BaseModel.h"

@interface Contact : BaseModel
@property (nonatomic, copy)  NSString     * phone;            //联系电话
@property (nonatomic, copy)  NSString     * areaCode;         //phone地区号
@property (nonatomic, copy)  NSString     * ext;
@end
