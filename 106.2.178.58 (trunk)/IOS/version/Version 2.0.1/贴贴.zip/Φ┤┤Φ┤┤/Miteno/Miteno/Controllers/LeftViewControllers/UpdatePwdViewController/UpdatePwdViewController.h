//
//  AccountViewController.h
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "RootViewController.h"



@class MpayUser;

@interface UpdatePwdViewController : RootViewController

//@property  (nonatomic, strong)  MpayUser* Account;

@end
