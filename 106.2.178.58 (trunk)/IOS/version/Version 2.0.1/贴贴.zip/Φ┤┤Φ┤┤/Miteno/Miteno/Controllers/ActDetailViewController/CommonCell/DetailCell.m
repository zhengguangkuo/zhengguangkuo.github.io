//
//  DetailCell.m
//  Miteno
//
//  Created by wg on 14-4-3.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "DetailCell.h"
#define kSpaceBtn 15
#define kFount    15
@implementation DetailCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initLayout];
    }
    return self;
}

- (void)initLayout
{
    CGSize size = self.frame.size;
    _merDetail = [[UIButton alloc] init];
    _merDetail.frame = CGRectMake(0, 0,size.width/2,size.height);
    _merDetail.backgroundColor = [UIColor clearColor];
    [_merDetail setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [_merDetail.titleLabel setFont:[UIFont systemFontOfSize:kFount]];
    [_merDetail setTitle:@"点击此处查看详情" forState:UIControlStateNormal];
    [self addSubview:_merDetail];
}
@end
