//
//  HttpTool.h
//  Miteno
//
//  Created by HWG on 14-3-13.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import <Foundation/Foundation.h>
@class BaseModel;
@interface HttpTool : NSObject
//广告列表界面
+ (void)sincePage:(NSString *)sicePage rows:(NSString *)rows success:(void (^)(NSMutableArray * ,long))success fail:(void (^)())fail;
@end
