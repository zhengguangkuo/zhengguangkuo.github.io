//
//  DiscountMerchantCell.h
//  Miteno
//
//  Created by HWG on 14-3-11.
//  Copyright (c) 2014年 wenguang. All rights reserved.
// 折扣商家

#import <UIKit/UIKit.h>

@interface DiscountMerchantCell : UITableViewCell
//图片
@property (weak, nonatomic) IBOutlet UIImageView *icon;
//商家名称
@property (weak, nonatomic) IBOutlet UILabel *merchantName;
//距离
@property (weak, nonatomic) IBOutlet UILabel *distance;
//商家折扣
@property (weak, nonatomic) IBOutlet UILabel *merchantDiscount;

@end
