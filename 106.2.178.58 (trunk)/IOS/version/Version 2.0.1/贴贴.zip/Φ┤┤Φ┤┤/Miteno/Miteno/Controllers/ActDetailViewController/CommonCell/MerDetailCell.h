//
//  MerDetailCell.h
//  Miteno
//
//  Created by wg on 14-3-27.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import "ActDetailCell.h"

@interface MerDetailCell : ActDetailCell
@property (nonatomic, strong) UILabel *content;
//初始化cell类
//-(id)initWithReuseIdentifier:(NSString*)reuseIdentifier;
-(void)setIntroductionText:(NSString*)text;
@end
