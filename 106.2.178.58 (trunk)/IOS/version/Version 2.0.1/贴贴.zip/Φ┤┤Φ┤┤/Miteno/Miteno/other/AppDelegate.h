//
//  AppDelegate.h
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright wenguang 2014年. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseNavigationController.h"
#import "UserInfo.h"
#import "BMapKit.h"
#import "WXApi.h"
#import "WXApiObject.h"
#import "Reachability.h"
//extern NSString *const KNOTIFICATIONCENTER_UPDATEUITABBARITEM;
/*
 *   统一保存：移动至 TTSettingKeys 
 */

@class UserInfo;
@class MpayUser;
@interface AppDelegate : UIResponder<UIApplicationDelegate,WXApiDelegate>
{
    BMKMapManager *_mapManager;
}
@property (nonatomic, retain) NSString  *networkType;    //用户当前使用网络类型
@property (strong, nonatomic) UIWindow * window;

@property  (nonatomic, strong) BaseNavigationController* HomeNavigation;

@property  (nonatomic, strong) BaseNavigationController* MenuNavigation;

@property  (nonatomic, assign) BOOL isLogining;

@property  (nonatomic, strong) UserInfo* userAccout;
@property  (nonatomic, strong) IIViewDeckController* DeckController;

@property  (nonatomic, strong)  MpayUser* Account;

+ (AppDelegate*)getApp;

- (void)setLeftMenuDragState;

- (void)setLeftMenuEnable:(BOOL)bFlag;

- (void)setLeftMenuDragged;

- (NSString*)getCityCode;

- (void)RequestForUserInfo:(void(^)(void))finishBlock;

@end
