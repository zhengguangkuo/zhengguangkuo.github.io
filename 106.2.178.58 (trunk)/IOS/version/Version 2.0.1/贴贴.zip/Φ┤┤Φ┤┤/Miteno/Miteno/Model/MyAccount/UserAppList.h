//
//  UserAppList.h
//  Miteno
//
//  Created by wg on 14-4-12.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//所有应用列表

#import "BaseModel.h"

@interface UserAppList : BaseModel
@property (nonatomic, copy) NSString    * app_card_no;
@property (nonatomic, copy) NSString    * app_name;
@property (nonatomic, copy) NSString    * app_type;
@property (nonatomic, copy) NSString    * bind_flag;
@property (nonatomic, copy) NSString    * detail;
@property (nonatomic, copy) NSString    * ID;
@property (nonatomic, copy) NSString    * instName;
@property (nonatomic, copy) NSString    * pic_path;
@property (nonatomic, copy) NSString    * action;   //绑定标示。绑定：bind解绑 unBind
@end
