//
//  UserAppList.m
//  Miteno
//
//  Created by wg on 14-4-12.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "UserAppList.h"

@implementation UserAppList
- (id)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.app_card_no = dict[@"app_card_no"];
        self.app_name = dict[@"app_name"];
        self.app_type = dict[@"app_type"];
        self.bind_flag = dict[@"bind_flag"];
        self.detail = dict[@"detail"];
        self.ID = dict[@"id"];
        self.instName = dict[@"instName"];
        self.pic_path = dict[@"pic_path"];
    }
    return self;
}

- (NSString *)action
{
    return @"bind";
}
@end
