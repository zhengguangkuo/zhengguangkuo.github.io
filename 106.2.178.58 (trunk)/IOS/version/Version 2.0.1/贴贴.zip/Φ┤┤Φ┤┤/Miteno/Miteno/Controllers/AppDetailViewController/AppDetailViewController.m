//
//  BasicSettingViewController.m
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "AppDetailViewController.h"
#import "UIImage(addition).h"
#import "AppCard.h"
#import "UIView(category).h"
#import "NSString(Additions).h"
#import "UIButton(addtion).h"
#import "CardBagViewController.h"
#import "UIView(PopBox).h"
//#import "SetDefaultTxtViewController.h"


#define  kUnbindBtn         0

#define  kDefaultBtn        1

#define  kIntroduce         2

#define  kSetDefaultTitle   @"默认卡的用途"

#define  kSetDefaultMsg     @"设置为默认卡后，在商家消费时会以该张卡作为首选支付卡进行消费，从而将简化您在终端上选择支付卡的步骤，缩短您的交易时间"


@interface AppDetailViewController ()

@property  (nonatomic, strong)  AppCard*  mAppCard;

@property  (nonatomic, strong)  UITableView* DetailTable;

@property  (nonatomic, strong)  NSMutableArray* ViewArray;


- (AppCard*)ConvertToObjFromDic:(NSDictionary*)dic;

@end


@implementation AppDetailViewController

@synthesize App_ID;

@synthesize mAppCard;

@synthesize DetailTable;

@synthesize ViewArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
       self.title = @"绑定卡详情";
       self.App_ID = [[NSString alloc] init];
       self.mAppCard = [[AppCard alloc] init];
       self.ViewArray = [[NSMutableArray alloc] init];
       [self.view setBackgroundColor:[UIColor whiteColor]];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self  NavigationViewBackBtn];
    [self  LoadViewArray];
    self.view.backgroundColor = [UIColor whiteColor];
    self.DetailTable = [[UITableView alloc] initWithFrame:CGRectMake(0, ZeroY, 320, (210*kAdjustRate + 92)+ TableExtraHeight) style:UITableViewStylePlain];
    [self.DetailTable setDelegate:self];
    [self.DetailTable setDataSource:self];
    [self.DetailTable setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [self.view addSubview:self.DetailTable];
    [self LoadBottomButtons];
}


- (void)LoadBottomButtons
{
    UIImage* image = [UIImage imageNamed:@"btn_bg_gray"];
    UIButton*  UnBindBtn = [UIButton ButtonWithParms:[UIColor whiteColor] title:@"解绑" bgnormal:image imgHighlight:nil target:self action:@selector(UnBind)];
    [UnBindBtn setTag:kUnbindBtn];
    [UnBindBtn setFrame:CGRectMake(ScreenWidth/2 - 60, self.DetailTable.frame.origin.y + DetailTable.frame.size.height + 10, 120, 40)];
    [self.view addSubview:UnBindBtn];
    
    
    UIImage* LightImage = [UIImage imageNamed:@"btn_bg_light"];
    UIButton*  SetDefaultBtn = [UIButton ButtonWithParms:[UIColor whiteColor] title:@"设为默认卡" bgnormal:LightImage imgHighlight:nil target:self action:@selector(SetDefault)];
    [SetDefaultBtn setTag:kDefaultBtn];
    [SetDefaultBtn setFrame:CGRectMake(UnBindBtn.origin.x, UnBindBtn.frame.origin.y + UnBindBtn.frame.size.height + 15, 120, 40)];
    [self.view addSubview:SetDefaultBtn];
    
    
    
    UIButton * IntroduceButton = [UIButton buttonWithType:UIButtonTypeCustom];
    IntroduceButton.frame = CGRectMake(ScreenWidth/2 + 30, SetDefaultBtn.bottom + 8, 120, 30);
    IntroduceButton.backgroundColor = [UIColor clearColor];
    IntroduceButton.showsTouchWhenHighlighted = YES;
    IntroduceButton.titleLabel.font = [UIFont systemFontOfSize:13];
    [IntroduceButton setTitle:@"什么是默认卡？" forState:UIControlStateNormal];
    [IntroduceButton setTitleColor:Blue forState:UIControlStateNormal];
    [IntroduceButton addTarget:self action:@selector(IntroduceForSetDefault) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:IntroduceButton];
}


- (void)IntroduceForSetDefault
{
   [self.view drawPopBox:kSetDefaultMsg title:kSetDefaultTitle input:NULL style:UIAlertWithoutBtn];
}


- (void)UnBind
{
    NSString*  testURL =  [NSString stringWithFormat:@"%@%@",  WEB_SERVICE_ENV_VAR,Key_App_Card_Bind];
    NSLog(@"testURL = %@",testURL);
    
    NSString* actionName = @"unBind";
    
    if(!ChNil(self.mAppCard.app_card_no)&&!ChNil(self.mAppCard.ID.app_id))
    {
        NSDictionary*  dic = [NSDictionary dictionaryWithObjectsAndKeys:
                self.mAppCard.app_card_no,@"app_card_no",
                actionName,@"action",
                self.mAppCard.ID.app_id,@"app_id",
                              nil];
        
        HttpService*  tempservice = [HttpService  HttpInitPostForm:testURL
                        body:dic
                    withHud:YES];
        
        [tempservice setDelegate:self];
        
        [tempservice  setDataHandler:^(NSString* data)
         {
             [self ParseJsonToMessage:data block:^{
                 [self UnBindReturn];
             }];
         }
         ];
        
        [tempservice setErrorHandler:^(NSError* error)
         {
             dispatch_async(dispatch_get_main_queue(),
            ^{
                 [self.view makeToast:@"网络状况不佳"];
             });
         }];
        
        [tempservice startOperation];
    }
}


- (void)UnBindReturn
{
  [[self GetLastPage] setUnBindBackFlag:TRUE];
  [self backToPrevious];
}


- (void)SetDefaultReturn
{
  [[self GetLastPage] setDefaultBackFlag:TRUE];
  [self backToPrevious];
}



- (CardBagViewController*)GetLastPage
{
    CardBagViewController*  VCtr = (CardBagViewController*)[self GetPreController];
    [VCtr setCardRefreshFlag:FALSE];
    return VCtr;
}






- (void)SetDefault
{
    NSString*  testURL =  [NSString stringWithFormat:@"%@%@",  WEB_SERVICE_ENV_VAR,Key_App_Card_Default];
    NSLog(@"testURL = %@",testURL);

    if(!ChNil(self.mAppCard.ID.app_id))
{
    NSDictionary*  dic = [NSDictionary dictionaryWithObjectsAndKeys:
        self.mAppCard.ID.app_id,@"appId",nil];
    
        HttpService*  tempservice = [HttpService  HttpInitPostForm:testURL
            body:dic
            withHud:YES];
    
            [tempservice setDelegate:self];
    
            [tempservice  setDataHandler:^(NSString* data)
         {
            [self ParseJsonToMessage:data block:^{
                [self SetDefaultReturn];
            }];
         }];
            [tempservice setErrorHandler:^(NSError* error)
         {
            dispatch_async(dispatch_get_main_queue(),
            ^{
                [self.view makeToast:@"网络状况不佳"];
            });
         }];
         [tempservice startOperation];
}

}


- (void)setBorderAndShadow:(UIView*)view
{
    [view ViewWithBorder:[UIColor clearColor]];
    view.layer.borderWidth = 2.0;
    view.layer.borderColor = [[UIColor whiteColor] CGColor];
    view.layer.shadowOffset = CGSizeMake(3.0f, 3.0f);
    view.layer.shadowOpacity = 0.5;
    view.layer.shadowRadius = 4.0;
    view.layer.shadowColor = [[UIColor blackColor] CGColor];
    view.layer.masksToBounds = NO;
}

- (void)LoadViewArray
{
   UIImageView*  CenterImageView = [[UIImageView alloc] initWithFrame:CGRectMake(5, 6, 310*kAdjustRate, 192*kAdjustRate)];
   [CenterImageView setImage:[UIImage imageNamed:@"adload.png"]];
    CGPoint center = CenterImageView.center;
   [CenterImageView setCenter:CGPointMake(ScreenWidth/2, center.y)];
   [self setBorderAndShadow:CenterImageView];

 
   [self.ViewArray addObject:CenterImageView];
    
   UILabel*  cardName = [[UILabel alloc] initWithFrame:CGRectMake(5, 5, 320, 40)];
   [cardName setTextColor:[UIColor blackColor]];
   [cardName setFont:[UIFont systemFontOfSize:13.0f]];
   [cardName setBackgroundColor:[UIColor clearColor]];
   [cardName setText:@""];
   [self.ViewArray addObject:cardName];
    
   UILabel*  cardNumber = [[UILabel alloc] initWithFrame:CGRectMake(5, 5, 320, 40)];
   [cardNumber setTextColor:[UIColor blackColor]];
   [cardNumber setFont:[UIFont systemFontOfSize:13.0f]];
   [cardNumber setBackgroundColor:[UIColor clearColor]];
   [cardNumber setText:@""];
   [self.ViewArray addObject:cardNumber];
}


- (void)RefreshData
{
  UIImageView* imageView = (UIImageView*)self.ViewArray[0];
  [imageView setImage:[UIImage imageNamed:@"adload.png"]];
    
  UILabel* cardName = (UILabel*)self.ViewArray[1];
  [cardName setText:@""];
    
  UILabel* cardNumber = (UILabel*)self.ViewArray[2];
  [cardNumber setText:@""];
    
  [imageView setImageFromUrl:mAppCard.mpayApp.pic_path];
  //[self setBorderAndShadow:imageView];
    
  [cardName setText:[NSString stringWithFormat:@"卡片类型                            %@",mAppCard.mpayApp.app_name]];

  [cardNumber setText:[NSString stringWithFormat:@"卡号                                   %@",[mAppCard.app_card_no PassWord]]];
}


- (AppCard*)ConvertToObjFromDic:(NSDictionary*)dic
{
    MpayID*  PayID = [[MpayID alloc] initWithDictionary:dic[@"id"]];
    MpayApp*  payApp = [[MpayApp alloc] initWithDictionary:dic[@"mpayApp"]];
    AppCard* card = [[AppCard alloc] initWithDictionary:dic];
    [card setMpayApp:payApp];
    [card setID:PayID];
    return card;
}


- (void)RequestDetail
{
    NSString*  testURL =  [NSString stringWithFormat:@"%@%@",  WEB_SERVICE_ENV_VAR,Key_App_Detail];
    
    NSLog(@"testURL = %@",testURL);
    
    NSDictionary* dic = [NSDictionary dictionaryWithObjectsAndKeys:
             self.App_ID, @"appId",
                     nil];
    
    HttpService*  tempservice = [HttpService  HttpInitPostForm:testURL
                                                          body:dic
                                                       withHud:YES];
    [tempservice setDelegate:self];
    
    [tempservice  setDataHandler:^(NSString* data)
     {
         __block int nTotal = 0;
         NSLog(@"data = %@",data);
         [self ParseJsonToDictionary:data block:^(int Total, NSDictionary *dic){
              if(nTotal==0)
            {
              self.mAppCard = [self ConvertToObjFromDic:dic];
              nTotal = Total;
            }
          }
        ];
       
         NSLog(@"mAppCard.app_name = %@",mAppCard.mpayApp.app_name);
         
         dispatch_async(dispatch_get_main_queue(),
        ^{
            //[self.DetailTable reloadData];
            [self RefreshData];
         });
      }
    ];
    [tempservice startOperation];
}



-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    return 3;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    int n = [indexPath row];
    if(n==0)
        return 210*kAdjustRate;
    else
        return 44;
}


-(UITableViewCell *)tableView:(UITableView *)tableView
		cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
     static NSString *CellDetail = @"DetailCard";
    
     int Row = [indexPath row];
    
     UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellDetail];
    
     if(cell==nil)
   {
       cell = [[UITableViewCell alloc] init];
       [cell setBackgroundColor:[UIColor clearColor]];
       
       CGFloat height = [self tableView:tableView heightForRowAtIndexPath:indexPath];
       
       UIImageView* line = [[UIImageView alloc] initWithFrame:CGRectMake(0, height - 1,320,1)];
       [cell addSubview:line];
       [line setBackgroundColor:[UIColor lightGrayColor]];
   }
    UIView* view = (UIView*)self.ViewArray[Row];
    [cell.contentView addSubview:view];
    
    return cell;
}


-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    [self  RequestDetail];
}


-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
}


-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:YES];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end

