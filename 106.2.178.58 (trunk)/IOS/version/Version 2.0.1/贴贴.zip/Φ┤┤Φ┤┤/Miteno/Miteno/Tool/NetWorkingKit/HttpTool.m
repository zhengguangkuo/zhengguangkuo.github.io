//
//  HttpTool.m
//  Miteno
//
//  Created by HWG on 14-3-13.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "HttpTool.h"
#import "Act.h"
#import "BaseModel.h"
//优惠劵列表
#define kCouponListURL @"mobile/coupon/actListByMerchAct"
@implementation HttpTool
//
+ (void)sincePage:(NSString *)page rows:(NSString *)rows success:(void (^)(NSMutableArray *, long))success fail:(void (^)())fail
{
    
    NSString *url = [NSString stringWithFormat:@"%@%@",kBaseURL,kCouponListURL];
//    //每次加载的条数
//    long row = 10;
//    //每次加载的页数
//    int num = 1;
//    if (_coupons.count) {
//        //当前页
//        int current = _coupons.count/row;
//        num = current + 1;
//        
//    }
    NSDictionary *dict = @{@"page":page,
                           @"rows":rows};
    HttpService  *tempservice = [HttpService  HttpInitPostForm:url
                                                          body:dict
                                                       withHud:YES];
    
    
    [tempservice setDataHandler:^(NSString *data) {
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *arr = dicts[@"rows"];
        NSMutableArray *coupons = [NSMutableArray array];
        for (NSDictionary *dict in arr) {
            Act *act= [[Act alloc] initWithDict:dict];
            [coupons addObject:act];
        }
        //总条数
        long totol = [dicts[@"total"] integerValue];
        
        success(coupons,totol);
    }];
    
    
    [tempservice setErrorHandler:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            fail(@"请检查网络连接");
        });
    }];
    [tempservice startOperation];
}
//请求失败
- (void)handleError:(NSError *)error
{
    NSString *errorMessage = [error localizedDescription];
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"网络连接失败"
														message:errorMessage
													   delegate:self
											  cancelButtonTitle:@"取消"
											  otherButtonTitles:nil];
    
    [alertView show];
}
@end
