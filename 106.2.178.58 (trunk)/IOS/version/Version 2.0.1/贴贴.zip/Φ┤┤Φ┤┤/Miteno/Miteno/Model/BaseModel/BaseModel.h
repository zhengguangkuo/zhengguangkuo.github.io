//
//  BaseModel.h
//  M-pay(Model)
//
//  Created by HWG on 13-12-5.
//  Copyright (c) 2013年 miteno. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseModel : NSObject
- (id)initWithDict:(NSDictionary *)dict;
@end
