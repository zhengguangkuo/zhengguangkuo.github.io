//
//  SeekPassWordViewController.h
//  Miteno
//
//  Created by HWG on 14-2-25.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SeekPassWordViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *userName;
- (IBAction)certainBtn:(id)sender;

@end
