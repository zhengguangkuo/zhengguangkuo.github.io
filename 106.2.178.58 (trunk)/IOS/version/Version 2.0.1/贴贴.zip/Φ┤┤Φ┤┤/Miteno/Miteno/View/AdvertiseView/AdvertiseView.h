//
//  AdvertiseView.h
//  M-Pay
//
//  Created by guorong on 14-2-24.
//  Copyright miteno 2014年. All rights reserved.
//

#import "CarousImageView.h"

@interface AdvertiseView : UIView

- (id)initWithFrame:(CGRect)frame defaultImage:(NSString*)name;

- (void)LoadData:(NSArray*)NameArray;

@end

















