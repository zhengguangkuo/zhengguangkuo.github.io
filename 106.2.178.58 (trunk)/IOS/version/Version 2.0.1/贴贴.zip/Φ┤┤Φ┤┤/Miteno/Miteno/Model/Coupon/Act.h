//
//  Act.h
//  M-pay(Model)
//
//  Created by HWG on 13-12-2.
//  Copyright (c) 2013年 miteno. All rights reserved.
//
typedef enum {
    kActTypeDiscount = 100, //折扣卷
    kActTypeCash //待金卷
}ActType;

#import "BaseModel.h"

@class CouponIssuer,ActRule, CreditsRule,MpayApp,MerchAct;
@interface Act : BaseModel

@property (nonatomic, copy)NSString * idStr;                    //活动ID
@property (nonatomic, copy)NSString * act_name;                 //活动名称
@property (nonatomic, copy)NSString * merchId;                     //商家id
@property (nonatomic, copy)NSString * is_apply;                 //优惠券是否已领

@property (nonatomic, copy)NSString * merch_name;
@property (nonatomic, copy)NSString * coordinate;               //坐标
@property (nonatomic, assign)ActType  actType;                  //优惠劵类型
@property (nonatomic, copy)NSString * voch_amt;                 //代金额度(当类型为代金卷时)
@property (nonatomic, copy)NSString * discount;                 //折扣比例(当类型为折扣卷时)

@property (nonatomic, strong)CouponIssuer * couponIssuer;       //
@property (nonatomic, copy)NSString * issuer_type;
@property (nonatomic, copy)NSString * issuer_id;
@property (nonatomic, copy)NSString * issue_type;
@property (nonatomic, copy)NSString * start_date;               //活动开始时间(领卷)
@property (nonatomic, copy)NSString * start_time;
@property (nonatomic, copy)NSString * end_date;                 //活动结束时间(领卷)
@property (nonatomic, copy)NSString * end_time;

@property (nonatomic, copy)NSString * status;
@property (nonatomic, copy)NSString * claimable;                //可以领取的
@property (nonatomic, copy)NSString * total_cnt;                //总发行数量
@property (nonatomic, copy)NSString * day_cnt;                  //每天发行量

@property (nonatomic, assign)int  personal_limit;               //每人最多领用数量
@property (nonatomic, assign)int  day_limit;                    //每天最多发行量
@property (nonatomic, assign)int  issued_cnt;                   //已发放数量
@property (nonatomic, assign)int  exchanged_cnt;

@property (nonatomic, copy)NSString * pic_path;                 //图片路径
@property (nonatomic, copy)NSString * pic_path_m;
@property (nonatomic, copy)NSString * pic_path_s;

@property (nonatomic, strong)NSString * actRule;

@property (nonatomic, strong)CreditsRule * creditsRule;         //积分规则·

@property (nonatomic, copy)NSString * content;                  //活动详情
@property (nonatomic, copy)NSString * lv1_category;
@property (nonatomic, copy)NSString * lv2_category;

@property (nonatomic, copy)NSString * distr_target;
@property (nonatomic, copy)NSString * consum_duration;
@property (nonatomic, assign)double dis_trtarget;
@property (nonatomic, copy)NSString * handle_flag;
@property (nonatomic, copy)NSString * couponIssuerId;
@property (nonatomic, assign)NSString  *claimFlag;              //绑定标识



@end
