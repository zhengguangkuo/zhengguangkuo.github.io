//
//  UIBarButtonItem+Create.h
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (Create)
//+ (UIBarButtonItem *)barButtonItemWithIcon:(NSString *)icon target:(id)target action:(SEL)action;
//
//+ (UIBarButtonItem *)barButtonItemWithImage:(UIImage *)image target:(id)target action:(SEL)action;
//
//+ (UIBarButtonItem *)barButtonItemWithBg:(NSString *)bg title:(NSString *)title size:(CGSize)size target:(id)target action:(SEL)action;

+ (UIBarButtonItem *)barButtonItemWithBackgroudImage:(UIImage *)bgImage
                                            andTitle:(NSString *)title
                                            andImage:(UIImage *)img
                                           addTarget:(id)target
                                           addAction:(SEL)action;

+ (UIBarButtonItem *)barButtonItemWithNegativeSpacer;
@end
