//
//  MainNavigation.m
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright wenguang 2014年. All rights reserved.
//

#import "MainNavigation.h"
@interface MainNavigation()
@end


@implementation MainNavigation

-(void)NavigationBgImage:(NSString*)imageName
{
    UIImage* bgimage = [UIImage imageNamed:imageName];
    self.barStyle = UIBarStyleBlackTranslucent;
    self.backgroundColor = [UIColor clearColor];
    
    if ([self respondsToSelector:@selector(setBackgroundImage:forBarMetrics:)])
    {
        [self setBackgroundImage:bgimage forBarMetrics:UIBarMetricsDefault];
    }
    else
    {
        UIImageView *imageView = [[UIImageView alloc] initWithImage:bgimage];
        imageView.frame = self.bounds;
        imageView.backgroundColor = [UIColor whiteColor];
        [self insertSubview:imageView atIndex:0];
    }
}


-(void)NavigationViewBackBtn:(UIButton*)back
{
    UIBarButtonItem *toggleLeft=[[UIBarButtonItem alloc]initWithCustomView:back];
    
    self.backItem.leftBarButtonItem=toggleLeft;
}


-(void)NavigationViewRightBtns:(NSArray*)buttons
{
    NSMutableArray* buttonArray =  [[NSMutableArray alloc] initWithCapacity:10];
    for(UIButton*  tempbutton in buttons)
{
   UIBarButtonItem *toggleRight=[[UIBarButtonItem alloc]initWithCustomView:tempbutton];
   [buttonArray addObject:toggleRight];
}
    self.backItem.rightBarButtonItems=buttonArray;
}


-(void)NavigationTitle:(NSString*)title
{
    UILabel* titleLabel =  [[UILabel alloc] initWithFrame:CGRectMake(130, 0, 100, 32)];
    [titleLabel setText:title];
    [titleLabel setTextColor:[UIColor whiteColor]];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [titleLabel setFont:[UIFont systemFontOfSize:14.0f]];
    self.backItem.titleView = titleLabel;
}

@end
