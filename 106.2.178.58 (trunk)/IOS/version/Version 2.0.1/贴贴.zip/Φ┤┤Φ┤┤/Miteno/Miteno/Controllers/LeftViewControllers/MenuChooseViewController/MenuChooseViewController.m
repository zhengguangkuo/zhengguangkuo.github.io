//
//  MenuChooseViewController.m
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "MenuChooseViewController.h"
#import "BusiPackage.h"
#import "UIButton(addtion).h"
#import "UIViewController(SMS).h"
#import "AppDelegate.h"
#import "HomeViewController.h"
#import "BasicSettingViewController.h"


#define  kConfimMsg  @"欢迎订阅梅泰诺（北京）移动信息技术有限公司的电子卡包，包月5元/月，不含通讯费，确认订购请回复Y。"


#define  kDgSuccess  @"您已成功订购北京联通的电子卡包业务，当月订购当月生效，月功能费5元。退订发送TDDZKB到106558892，公司客服电话4000328666。"


#define  kTdSuccess  @"您已成功退订北京联通的电子卡包业务，如需再次订购请发送DGDZKB到106558892。"


#define  kYesBtn  10


#define  kNoBtn   11


@interface MenuChooseViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic, strong)  UITableView*  MenuTableView;

@property (nonatomic, strong)  NSMutableArray*  MenuArray;

@property (nonatomic, strong)  UIButton* cancelBtn;

@end


@implementation MenuChooseViewController

@synthesize MenuTableView;

@synthesize MenuArray;

@synthesize cancelBtn;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"套餐选择";
        self.MenuArray = [[NSMutableArray alloc] init];
        self.view.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self NavigationViewBackBtn];
    [self NavigationRightButtons];
    
    self.MenuTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 320, ScreenHeight - 0.24*ScreenHeight) style:UITableViewStylePlain];
    [MenuTableView setDataSource:self];
    [MenuTableView setDelegate:self];
    [MenuTableView setBackgroundColor:[UIColor whiteColor]];
    [MenuTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];

    [self.view addSubview:self.MenuTableView];
    
    NSArray*  array = [UIFont familyNames];
    for(NSString* namestr in array)
    {
        NSLog(@"namestr = %@",namestr);
    }
    
    [self LoadBottomBtn];

    // Do any additional setup after loading the view.
}


- (void)LoadBottomBtn
{
    
    UIImage* LightImage = [UIImage imageNamed:@"btn_bg_light"];
    UIButton* okBtn = [UIButton ButtonWithParms:[UIColor whiteColor] title:@"下一步" bgnormal:LightImage imgHighlight:nil target:self action:@selector(NextStep)];
    
    [okBtn setTag:kYesBtn];
    [okBtn setFrame:CGRectMake(70, MenuTableView.frame.origin.y + MenuTableView.frame.size.height + 15, 80, 40)];
    [self.view addSubview:okBtn];
    [okBtn setHidden:TRUE];
    
    
    UIButton* noBtn = [UIButton ButtonWithParms:[UIColor whiteColor] title:@"上一步" bgnormal:LightImage imgHighlight:nil target:self action:@selector(PreStep)];
    
    [noBtn setTag:kNoBtn];
    [noBtn setFrame:CGRectMake(170, MenuTableView.frame.origin.y + MenuTableView.frame.size.height + 15, 80, 40)];
    [self.view addSubview:noBtn];
    [noBtn setHidden:TRUE];
}


- (void)NextStep
{
    AppDelegate* app = [AppDelegate getApp];
    [app.userAccout setIsFirstLogin:FALSE];

    [self.navigationController popToRootViewControllerAnimated:YES];
}


- (void)PreStep
{
    BasicSettingViewController* bsc = (BasicSettingViewController*)[self GetPreController];
    [bsc ShowBottomButtonsOrNot];
    [self.navigationController popViewControllerAnimated:YES];
}



- (void)ShowBottomButtonsOrNot
{
    UIButton* okBtn = (UIButton*)[self.view viewWithTag:kYesBtn];
    UIButton* noBtn = (UIButton*)[self.view viewWithTag:kNoBtn];
    
    AppDelegate* app = [AppDelegate getApp];
    if(app.userAccout.isFirstLogin)
    {
        [okBtn setHidden:FALSE];
        [noBtn setHidden:FALSE];
        [self NavigationHiddenBack];
    }
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    [self  RequestMenuList];
    AppDelegate* app = [AppDelegate getApp];
    if(IsEmptyString(app.userAccout.Mobile))
        [app  RequestForUserInfo:NULL];
}


- (void)NavigationRightButtons
{
    self.cancelBtn = [UIButton ButtonWithParms:[UIColor whiteColor] title:@"退订" bgnormal:[UIImage imageNamed:@"top_bt_bg.png"] imgHighlight:nil target:self action:@selector(cancelBook)];
    [cancelBtn setFrame:CGRectMake(260, 4, 60, 36)];
    NSArray*  temArray = [NSArray arrayWithObjects:cancelBtn, nil];
    [self SetNaviationRightButtons:temArray];
    self.cancelBtn.hidden = TRUE;
}


- (void)cancelBook
{
    NSLog(@"退订");

}








- (void)RequestMenuList
{
    cancelBtn.hidden = TRUE;
    [self.MenuArray removeAllObjects];
    NSString*  testURL =  [NSString stringWithFormat:@"%@%@",  WEB_SERVICE_ENV_VAR,Key_Pkg_List];
    NSLog(@"testURL = %@",testURL);
    
    AppDelegate* app = [AppDelegate getApp];
    NSString* city_code = [app getCityCode];

    NSDictionary* dic = [NSDictionary dictionaryWithObjectsAndKeys:
           city_code,@"city",
        nil];
    
    HttpService*  tempservice = [HttpService  HttpInitPostForm:testURL
                    body:dic
                 withHud:YES];
    [tempservice setDelegate:self];
    
    [tempservice  setDataHandler:^(NSString* data)
    {
         static BOOL bCheckFlag = FALSE;
         NSLog(@"data = %@",data);
         [self ParseJsonToDictionary:data block:^(int Total, NSDictionary *dic) {
          __block  BusiPackage*  tempobject = [[BusiPackage alloc] initWithDictionary:dic];
             id BusiPackage_ID = dic[@"id"];
             if(!ChNil(BusiPackage_ID))
             [tempobject setID:[NSString stringWithFormat:@"%@",BusiPackage_ID]];
             NSLog(@"id = %@",tempobject.ID);
             NSLog(@"pkgname = %@",tempobject.pkg_name);
             if([tempobject.bind_flag isEqualToString:@"1"])
             {
                 bCheckFlag = TRUE;
             }
             [self.MenuArray addObject:tempobject];
        }];
         
         dispatch_async(dispatch_get_main_queue(),
        ^{
            if(bCheckFlag)
            cancelBtn.hidden = FALSE;
            
            [self.MenuTableView reloadData];
         });
    }
    ];
    [tempservice startOperation];
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    return [self.MenuArray count];
}


-(UITableViewCell *)tableView:(UITableView *)tableView
		cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString* ChooseIdentifier = @"ChooseTable";
    UITableViewCell*  tempcell2 = nil;
    tempcell2 = [tableView dequeueReusableCellWithIdentifier:ChooseIdentifier];
    
    if(tempcell2==nil)
    {
        tempcell2 = [[UITableViewCell  alloc]  initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ChooseIdentifier];
        tempcell2.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UILabel*  orgnizeLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, 100, 40)];
        [orgnizeLabel setBackgroundColor:[UIColor clearColor]];
        [orgnizeLabel setFont:[UIFont boldSystemFontOfSize:16.0f]];
        [orgnizeLabel setTextColor:[UIColor blackColor]];
        [orgnizeLabel setText:@""];
        [tempcell2.contentView addSubview:orgnizeLabel];
        [orgnizeLabel setTag:1];
        
        
        UIImageView* stateImageView = [[UIImageView alloc] init];
        UIImage* Image = [UIImage  imageNamed:@"normal_no_focus"];
        [stateImageView setFrame:CGRectMake(260, 11, Image.size.width, Image.size.height)];
        [stateImageView setImage:Image];
        [tempcell2.contentView addSubview:stateImageView];
        [stateImageView setTag:2];
        
        
        UIImageView* line = [[UIImageView alloc] initWithFrame:CGRectMake(0, 59,320,1)];
        [tempcell2.contentView addSubview:line];
        [line setBackgroundColor:[UIColor lightGrayColor]];

    }

    BusiPackage*  tempobject = [self.MenuArray objectAtIndex:indexPath.row];
    
    UILabel* tempLabel = (UILabel*)[tempcell2 viewWithTag:1];
    [tempLabel setText:tempobject.pkg_name];
    
    
    UIImageView* stateImageView = (UIImageView*)[tempcell2 viewWithTag:2];
    
    NSString* imageName = nil;
    if([tempobject.bind_flag isEqualToString:@"1"])
        imageName = @"normal_with_focus.png";
    else
        imageName = @"normal_no_focus.png";
    
    [stateImageView setImage:[UIImage imageNamed:imageName]];
    
    return tempcell2;
	
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    AppDelegate* app = [AppDelegate getApp];
    if(IsEmptyString(app.userAccout.Mobile))
    return;
    
    //  NSLog(@"meat hrere");
    BusiPackage*  tempobject = self.MenuArray[indexPath.row];
    NSString* msgTitle = [self GetMsgTitle:tempobject];

    NSArray*  ContactArray = [NSArray arrayWithObjects:app.userAccout.Mobile, nil];
    
    if(self.cancelBtn.hidden)
   {
       if([tempobject.bind_flag isEqualToString:@"0"])
      {
          [self.view drawPopBox:msgTitle title:@"温馨提示" input:^{
              [self finishFail:^{
                  NSLog(@"send fail");
              }];
              
              [self finishSuccess:^{
                  NSLog(@"send success");
                [self.view drawPopBox:kConfimMsg title:@"温馨提示" input:^{
                  
                [self finishSuccess:^{
                    [self.view drawPopBox:kDgSuccess title:@"温馨提示" input:NULL style:UIAlertWithoutBtn];
                }];
                 [self finishFail:NULL];
                 [self finishCancel:NULL];
                 [self sendSMS:@"Y" array:ContactArray];
               }
                 style:UIAlertYesOrNo];
              
              }];

              [self sendSMS:@"DGDZKB" array:ContactArray];
          } style:UIAlertDefault];
      
      }
   }
     else
   {
       if([tempobject.bind_flag isEqualToString:@"1"])
      {
          [self.view drawPopBox:msgTitle title:@"温馨提示" input:^{
              [self finishFail:^{
                  NSLog(@"send fail");
              }];
              
              [self finishSuccess:^{
                  NSLog(@"send success");
                  [self.view drawPopBox:kTdSuccess title:@"温馨提示" input:NULL style:UIAlertWithoutBtn];
              }];

              [self sendSMS:@"TDDZKB" array:ContactArray];
          } style:UIAlertDefault];
      }
   }
}



- (NSString*) GetMsgTitle:(BusiPackage*)object
{
    NSString* action = ([object.bind_flag isEqualToString:@"0"]?@"订阅":@"退订");
    NSString* NameStr = object.pkg_name;
    return [NSString stringWithFormat:@"您要%@%@？",action,NameStr];
}



//点击返回
- (void)backToPrevious
{
    [self.viewDeckController toggleLeftViewAnimated:YES];
    
}

@end
