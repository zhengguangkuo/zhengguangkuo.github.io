//
//  ComboViewController.h
//  Mpay
//
//  Created by HWG on 13-12-25.
//  Copyright (c) 2013年 miteno. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ComboViewController : UITableViewController

@end
