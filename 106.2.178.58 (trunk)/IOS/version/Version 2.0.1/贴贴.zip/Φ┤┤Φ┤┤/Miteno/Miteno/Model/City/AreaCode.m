//
//  AreaCode.m
//  Miteno
//
//  Created by wg on 14-4-8.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "AreaCode.h"

@implementation AreaCode
- (id)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.ID = dict[@"_ID"];
        self.area_level = dict[@"AREA_LEVEL"];
        self.area_name = dict[@"AREA_NAME"];
         self.area_code = dict[@"AREA_CODE"];
        self.phone_area_code = dict[@"PHONE_AREA_CODE"];
        self.super_area_code = dict[@"SUPER_AREA_CODE"];
    }
    return self;
}
@end
