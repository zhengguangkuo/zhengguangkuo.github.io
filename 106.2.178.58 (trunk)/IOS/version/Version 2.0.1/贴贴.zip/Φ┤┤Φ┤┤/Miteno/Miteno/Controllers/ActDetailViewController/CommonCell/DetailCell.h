//
//  DetailCell.h
//  Miteno
//
//  Created by wg on 14-4-3.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "ActDetailCell.h"

@interface DetailCell : ActDetailCell
@property (nonatomic, strong, readonly) UIButton *merDetail;
@end
