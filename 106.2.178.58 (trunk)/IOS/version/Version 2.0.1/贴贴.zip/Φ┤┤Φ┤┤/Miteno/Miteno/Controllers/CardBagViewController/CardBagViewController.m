//
//  BasicSettingViewController.m
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//
#import "CardBagViewController.h"
#import "IIViewDeckController.h"
#import "ActDetailViewController.h"
#import "HttpService.h"
#import "AppCard.h"
#import "Merch.h"
#import "AppCell.h"
#import "MerchCell.h"
#import "UIImage(addition).h"
#import "UIButton(addtion).h"
#import "NSObject(Refresh).h"
#import "BindCardViewController.h"
#import "AppDetailViewController.h"
#import "AppDelegate.h"
#import "Utilities.h"
#import "Act.h"
#import "BMKGeometry.h"

#define kCardPageMax     4

#define kConpusPageMax   4

@interface CardBagViewController ()

@property  (nonatomic, strong)  NSMutableArray* cardArray;

@property  (nonatomic, strong)  NSMutableArray* conpusArray;

@property  (nonatomic, strong)  UITableView*  cardTable;

@property  (nonatomic, assign)  BOOL  TypeSelected;

@property  (nonatomic, strong)  NSMutableArray* buttonArray;

@property  (nonatomic, assign)  int CardTotal;

@property  (nonatomic, assign)  int ConpusTotal;

@property  (nonatomic, assign)  int CurCardPage;

@property  (nonatomic, assign)  int CurConpusPage;

@property  (nonatomic, strong)  CLLocationManager    * _locatitonManager;

@property  (nonatomic, assign)  CLLocationCoordinate2D  _userCoordinate;


- (AppCard*)ConvertToObjFromDic:(NSDictionary*)dic;

- (CLLocationDistance) getCLLocationDistance:(CLLocationCoordinate2D)merchantCoordinate;
- (void)getUserLocation;

@end


@implementation CardBagViewController

@synthesize cardTable;

@synthesize TypeSelected;

@synthesize CardTotal;

@synthesize ConpusTotal;

@synthesize CurCardPage;

@synthesize CurConpusPage;

@synthesize CardRefreshFlag;

@synthesize MerchRefreshFlag;

@synthesize  UnBindBackFlag;

@synthesize  DefaultBackFlag;

@synthesize  _locatitonManager;

@synthesize  _userCoordinate;


static NSString *CellIdentifier = @"AppCard";

static NSString *CellIdentifier2 = @"Merch";


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"电子卡包";
        self.TypeSelected = TRUE;
        self.cardArray = [[NSMutableArray alloc] init];
        self.conpusArray = [[NSMutableArray alloc] init];
        self.buttonArray = [[NSMutableArray alloc] init];
        self.ConpusTotal = 0;
        self.CardTotal = 0;
        self.CurCardPage = 1;
        self.CurConpusPage = 1;
        self.MerchRefreshFlag = FALSE;
        self.CardRefreshFlag = FALSE;
        self.UnBindBackFlag = FALSE;
        self.DefaultBackFlag = FALSE;

        [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage scaleToSize:[UIImage imageNamed:@"leather_bg"] size:kScreenBounds.size]]];
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self  NavigationViewBackBtn];
    [self  NavigationRightButtons];
    
    UIImage* tempImage = [UIImage  generateFromColor:[UIColor whiteColor]];
    UIImage* hilightImage = [UIImage imageNamed:@"business_bg"];
    
    UIButton*  leftButton = [UIButton ButtonWithParms:[UIColor whiteColor] title:@"支付卡" bgnormal:hilightImage imgHighlight:hilightImage target:self action:@selector(ConverState:)];
    [leftButton setTag:0];

    [leftButton setFrame:CGRectMake(0,TableExtraHeight, ScreenWidth/2, 45)];

    [self.view addSubview:leftButton];
    [self.buttonArray addObject:leftButton];
    
    
    UIButton*  rightButton = [UIButton ButtonWithParms:[UIColor blackColor] title:@"电子券" bgnormal:tempImage imgHighlight:tempImage target:self action:@selector(ConverState:)];
    [rightButton setTag:1];
    [rightButton setFrame:CGRectMake(ScreenWidth/2,TableExtraHeight, ScreenWidth/2, 45)];
    [self.view addSubview:rightButton];
    [self.buttonArray addObject:rightButton];
    
    self.cardTable = [[UITableView alloc] initWithFrame:CGRectMake(0, leftButton.frame.origin.y + leftButton.frame.size.height, ScreenWidth, ScreenHeight - (TableExtraHeight + (CGFloat)45)) style:UITableViewStylePlain];
    
    
    [cardTable setDelegate:self];
    [cardTable setDataSource:self];
    [cardTable setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [cardTable setBackgroundColor:[UIColor clearColor]];
    [self.view addSubview:cardTable];

    [self RefreshData:cardTable
    up:
    ^{
        [self RequestCards:UIRefreshUp];
     }
    down:
    ^{
        [self RequestCards:UIRefreshDown];
     }];
}

- (void)NavigationRightButtons
{
    UIButton* NewCard = [UIButton ButtonWithParms:[UIColor clearColor] title:@"" bgnormal:[UIImage imageNamed:@"jh.png"] imgHighlight:nil target:self action:@selector(NewCard)];
    [NewCard setFrame:CGRectMake(260, 7, 20, 20)];
    NSArray*  temArray = [NSArray arrayWithObjects:NewCard, nil];
    [self SetNaviationRightButtons:temArray];
}

- (void)NewCard
{
    NSLog(@"new card");
    BindCardViewController* bindCardCtr = [[BindCardViewController alloc] init];
    [self.navigationController pushViewController:bindCardCtr animated:YES];
}


- (void)ConverState:(id)sender
{
     UIButton* selectdButton = (UIButton*)sender;
    
     if((TypeSelected&&selectdButton.tag==1)||(!TypeSelected&&selectdButton.tag==0))
{
    for(UIButton* button in self.buttonArray)
{
    if(button.tag==selectdButton.tag)
   {
      [button SetButtonStatus:[UIColor whiteColor] bgImage:[UIImage imageNamed:@"business_bg"]];
   }
     else
   {
      [button SetButtonStatus:[UIColor blackColor] bgImage:[UIImage  generateFromColor:[UIColor whiteColor]]];
   }
}

    if(!TypeSelected)
    {
        TypeSelected = TRUE;
        
        if(!self.CardRefreshFlag)
            [self RequestCards:UIRefreshStart];
        else
            [self.cardTable reloadData];

        [self RefreshData:cardTable
        up:
         ^{
             [self RequestCards:UIRefreshUp];
          }
        down:
         ^{
             [self RequestCards:UIRefreshDown];
          }];
    }
    else
    {
        TypeSelected = FALSE;
        
        if(!self.MerchRefreshFlag)
            [self RequestConpus:UIRefreshStart];
        else
            [self.cardTable reloadData];

        
        [self RefreshData:cardTable
        up:
        ^{
             [self RequestConpus:UIRefreshUp];
         }
        down:
        ^{
             [self RequestConpus:UIRefreshDown];
         }];
        
        
    }
}

    
    
}


-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    if(TypeSelected)
         return [self.cardArray count];
    else
         return [self.conpusArray count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(TypeSelected)
         return 128;
    else
         return 112;
}

-(UITableViewCell *)tableView:(UITableView *)tableView
		cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
     int n = [indexPath row];
     if(TypeSelected)
   {
      AppCell*  cell = [self CellForApp:n View:tableView];
       return cell;
   }
     else
   {
      MerchCell* cell = [self CellForMerch:n  View:tableView];
      return cell;
   }
}



//定义编辑样式
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(!TypeSelected)
  {
      [tableView setEditing:YES animated:YES];
      return UITableViewCellEditingStyleDelete;
  }
    else
  {
      [tableView setEditing:NO];
      return UITableViewCellEditingStyleNone;
  }
}


- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return @"退领";
}


//取消缩进状态
- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath
{
    return NO;
}



- (AppCell*)CellForApp:(int)Row  View:(UITableView*)table
{
    AppCell *cell = (AppCell*)[table dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if(cell==nil)
   {
      cell = [[AppCell alloc] initCustom];
      [cell setEditing:NO];
   }
    
    if(Row>=0&&Row<[self.cardArray count])
   {
     AppCard*  tempobject = self.cardArray[Row];
     [cell SetCardObject:tempobject];
   }
    return cell;
}


- (MerchCell*)CellForMerch:(int)Row View:(UITableView*)table
{
    MerchCell *cell = (MerchCell*)[table dequeueReusableCellWithIdentifier:CellIdentifier2];
    if(cell==nil)
    {
        cell = [[MerchCell alloc] initCustom];
        [cell setEditing:YES];
        
        NSString* bgImageName = nil;
        
        if(Row%2!=0)
        {
            bgImageName = @"elebusiness_list_bg";
            
        }
        else
        {
            bgImageName = @"elebusiness_list_bg_down";
        }
        UIImage* bgImage = [UIImage imageNamed:bgImageName];
        UIImage* bgFinal = [UIImage scaleToSize:bgImage size:CGSizeMake(bgImage.size.width, 112)];
        [cell setBackgroundColor:[UIColor colorWithPatternImage:bgFinal]];
        
    }
    
    if(Row>=0&&Row<[self.conpusArray count])
    {
        Merch*  tempobject = self.conpusArray[Row];
        if(tempobject.distance==nil)
     {
        if (tempobject.coordinate) {
            CLLocationCoordinate2D coordinate = [Utilities stringToCLLocationCoordinate2D:tempobject.coordinate];
            CLLocationDistance distance = [self getCLLocationDistance:coordinate];
            [tempobject setDistance:[NSString stringWithFormat:@"%.3fkm",distance]];
        }
         else
        {
           [tempobject setDistance:@"距离未知"];
        }
     }
        
        [cell setMerchObject:tempobject];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(TypeSelected&&[self.cardArray count]>0)
 {
     AppCard* temppbject = self.cardArray[indexPath.row];
     NSString* App_ID = temppbject.ID.app_id;
     AppDetailViewController*  detail_VCtr =[[AppDetailViewController alloc] init];
    [self.navigationController pushViewController:detail_VCtr animated:YES];
    [detail_VCtr setApp_ID:App_ID];
 }
    else
    if(!TypeSelected&&[self.conpusArray count]>0)
 {
     ActDetailViewController *actDetail = [[ActDetailViewController alloc] init];
     [actDetail setClaimFlag:TRUE];
     Merch* object = self.conpusArray[indexPath.row];
     actDetail.act = [self ActObjectConvert:object];
     [self.navigationController pushViewController:actDetail animated:YES];
 }
}


- (Act*)ActObjectConvert:(Merch*)object
{
    Act* tempobject = [[Act alloc] init];
    
    
    [tempobject setMerch_name:object.merch_name];
    NSLog(@"object.merch_name = %@",object.merch_name);
    
    [tempobject setMerchId:object.merch_id];
    [tempobject setPic_path:object.pic_path];
    [tempobject setStart_date:object.start_date];
    [tempobject setEnd_date:object.end_date];
    [tempobject setIdStr:object.act_id];
    [tempobject setIssued_cnt:object.issued_cnt];
    [tempobject setCoordinate:object.coordinate];
    [tempobject setCouponIssuerId:object.act_id];
    [tempobject setAct_name:object.act_name];
    [tempobject setIs_apply:@"0"];
    
    return tempobject;
}







#pragma mark 提交编辑操作(点击了"删除"或者"+"按钮)时调用
// 实现了这个方法，就有左划删除功能
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle  forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        if(!TypeSelected)
    {
        Merch* object = self.conpusArray[indexPath.row];
        [self RequestReturnConpus:object completion:^{
            [self.conpusArray removeObjectAtIndex:indexPath.row];
            [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationLeft];
         }];
    }
}
    
}


- (void)RequestReturnConpus:(Merch*)object completion:(void (^)(void))complishblock
{
    NSString*  testURL =  [NSString stringWithFormat:@"%@%@",  WEB_SERVICE_ENV_VAR,Key_Coupon_Return];
    
    NSDictionary* dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         object.act_id,@"couponIds",
                         @"80000000",@"couponIssuerId",
                         nil];
    
    
    HttpService*  tempservice = [HttpService
                                 HttpInitPostForm:testURL
                                 body:dic
                                 withHud:YES];
    
    [tempservice setDelegate:self];
    
    [tempservice  setDataHandler:^(NSString* data)
    {
//        NSLog(@"data = %@",data);
//        [self ParseJsonToMessage:data block:^{
            dispatch_async(dispatch_get_main_queue(),
        ^{
              if(complishblock)
             {
                 complishblock();
             }
            [self.view makeToast:@"退领成功!"];
         });
//        }];
    }
    ];
    [tempservice startOperation];
}





- (void)RequestCardBagList
{
    if(!self.CardRefreshFlag)
      [self RequestCards:UIRefreshStart];
}


- (void)RequestCards:(UIRefreshStyle)style
{
    if(![self CheckRefresh:CurCardPage total:CardTotal pageMax:kCardPageMax style:style])return;
    
    NSString*  testURL =  [NSString stringWithFormat:@"%@%@",  WEB_SERVICE_ENV_VAR,Kye_App_Card_Binded];
    
    int curPage = [self RefreshIndex:style curr:CurCardPage];

    NSDictionary* dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSString stringWithFormat:@"%d",curPage],@"page",
                         [NSString stringWithFormat:@"%d",kCardPageMax],@"rows",
                         @"0",@"appType",
                         nil];
    
    [self.cardArray removeAllObjects];
    
    HttpService*  tempservice = [HttpService  HttpInitPostForm:testURL
                    body:dic
                    withHud:YES];
    
    [tempservice setDelegate:self];
    
    [tempservice  setDataHandler:^(NSString* data)
     {
         NSLog(@"data = %@",data);
         [self ParseJsonToDictionary:data block:^(int Total, NSDictionary *dic) {
         if(self.CardTotal==0&&Total>0)
         self.CardTotal = Total;
         [self.cardArray addObject:[self ConvertToObjFromDic:dic]];
         }];
         
         NSString *leftButtontitle = [NSString stringWithFormat:@"支付卡(%d张)",self.CardTotal];
         [[self.buttonArray objectAtIndex:0] setTitle:leftButtontitle forState:UIControlStateNormal];
         
         self.CurCardPage = [self NewCurrIndex:self.CurCardPage total:CardTotal pageMax:kCardPageMax style:style];

         if(style==UIRefreshStart)
         {
             if(!CardRefreshFlag)
           {
              self.CardRefreshFlag = TRUE;
           }
         }
         
         dispatch_async(dispatch_get_main_queue(),
        ^{
            [self.cardTable reloadData];
            
              if(UnBindBackFlag)
            {
               self.UnBindBackFlag = FALSE;
               [self.view makeToast:@"应用解绑成功"];
            }
              else
              if(DefaultBackFlag)
            {
               self.DefaultBackFlag = FALSE;
               [self.view makeToast:@"默认设置完成"];
            }
        });
     }
     ];
    
    [tempservice startOperation];
}

- (AppCard*)ConvertToObjFromDic:(NSDictionary*)dic
{
    MpayID*  PayID = [[MpayID alloc] initWithDictionary:dic[@"id"]];
    MpayApp*  payApp = [[MpayApp alloc] initWithDictionary:dic[@"mpayApp"]];
    AppCard* card = [[AppCard alloc] initWithDictionary:dic];
    [card setMpayApp:payApp];
    [card setID:PayID];
    return card;
}

- (void)RequestConpusList
{
    if(!self.MerchRefreshFlag)
        [self RequestConpus:UIRefreshStart];
}

- (void)RequestConpus:(UIRefreshStyle)style
{
    if(![self CheckRefresh:CurConpusPage total:ConpusTotal pageMax:kConpusPageMax style:style])return;
    
    NSString*  testURL =  [NSString stringWithFormat:@"%@%@",  WEB_SERVICE_ENV_VAR,Key_Coupon_Receive/*Key_Coupon_All_List*/];
    int curPage = [self RefreshIndex:style curr:CurConpusPage];
    NSString *point = [Utilities CLLocationCoordinate2DToString:_userCoordinate];
    
    NSDictionary* dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         [NSString stringWithFormat:@"%d",curPage],@"page",
                         [NSString stringWithFormat:@"%d",kConpusPageMax],@"rows",
                         point,@"point",
                         nil];
    
    [self.conpusArray removeAllObjects];
    
    HttpService*  tempservice = [HttpService
        HttpInitPostForm:testURL
        body:dic
        withHud:YES];
    
    [tempservice setDelegate:self];
    
    [tempservice  setDataHandler:^(NSString* data)
    {
         NSLog(@"conpus data = %@",data);
         //[self ParseJson:data];
         [self ParseJsonToDictionary:data block:^(int Total, NSDictionary *dic) {
             Merch* object = [[Merch alloc] initWithDictionary:dic];
             if(self.ConpusTotal==0&&Total>0)
             self.ConpusTotal = Total;
             NSLog(@"Total = %d",Total);
             
             [self.conpusArray addObject:object];
         }];
        
        NSString *rightButtonTitle = [NSString stringWithFormat:@"商业券(%d)",self.ConpusTotal];
        
        [[self.buttonArray objectAtIndex:1] setTitle:rightButtonTitle forState:UIControlStateNormal];
        
        self.CurConpusPage = [self NewCurrIndex:self.CurConpusPage total:ConpusTotal pageMax:kConpusPageMax style:style];
        
        if(style==UIRefreshStart)
        {
            if(!self.MerchRefreshFlag)
            {
                self.MerchRefreshFlag = TRUE;
            }
        }

        dispatch_async(dispatch_get_main_queue(),
       ^{
            [self.cardTable reloadData];
        });
    }
    ];
    [tempservice startOperation];
}


-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    AppDelegate* app = [AppDelegate getApp];
    [app setLeftMenuEnable:NO];
    
    if(TypeSelected)
    {
       [self RequestCardBagList];
    }
    else
    {
       [self RequestConpusList];
    }
}



- (CLLocationDistance) getCLLocationDistance:(CLLocationCoordinate2D)merchantCoordinate
{
    CLLocationDistance dis = BMKMetersBetweenMapPoints(BMKMapPointForCoordinate(_userCoordinate), BMKMapPointForCoordinate(merchantCoordinate));
    return dis/1000.0;
}

- (void)getUserLocation
{
    if (!_locatitonManager) {
        _locatitonManager = [[CLLocationManager alloc]init];
    }
    if ([CLLocationManager locationServicesEnabled]) {
        _locatitonManager.delegate = self;
        _locatitonManager.desiredAccuracy = kCLLocationAccuracyBest;
        _locatitonManager.distanceFilter = 10.0f;
        [_locatitonManager startUpdatingLocation];
    }
}

#pragma location manager methods
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    CLLocation *location = [locations lastObject];
    _userCoordinate = BMKCoorDictionaryDecode(BMKBaiduCoorForWgs84(location.coordinate));
    [_locatitonManager stopUpdatingLocation];
    NSLog(@"userLocationCoordinate:%f,%f",_userCoordinate.latitude,_userCoordinate.longitude);
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end

