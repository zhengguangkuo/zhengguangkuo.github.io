//
//  SeekPassWordViewController.m
//  Miteno
//
//  Created by HWG on 14-2-25.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "SeekPassWordViewController.h"

#define kSeekPwdURL [NSString stringWithFormat:@"%@mpayFront/getNewPasswordByEmail",kBaseURL]
@interface SeekPassWordViewController ()

@end

@implementation SeekPassWordViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"密码找回";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    UIBarButtonItem *item =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                            andTitle:nil
                                            andImage:[UIImage imageNamed:@"gb_button"]
                                           addTarget:self
                                           addAction:@selector(back)];
    
    UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];
    
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];
    //[UIBarButtonItem barButtonItemWithBg:@"nav_image_bg.png" title:@"返回" size:CGSizeMake(70, 35) target:self action:@selector(back)];
}
- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}

//确定
- (IBAction)certainBtn:(id)sender {
    [self.view endEditing:YES];
    
    //判断账号是否匹配
//    NSString *regex=@"(^[a-zA-Z\u4e00-\u9fa5]{1}[\\u4E00-\\u9FA5\\uF900-\\uFA2D\\w]{1,15}$)";
    
    if([_userName.text isEqualToString:@""]||_userName.text==nil){
        [SystemDialog alert:@"请输入账号"];
        
        return;
    }
    /*
    if (![_userName.text isMatchedByRegex:regex]) {
        [SystemDialog alert:@"账号应为4-16位英文、数字或中文！且首字母不能为数字！"];
        return;
    }else{
        int addLength = 0;                              //字符串中的汉字个数
        NSString *temp = nil;
        regex = @"^([\u4e00-\u9fa5]$)";
        int nowLength = _userName.text.length;      //当前长度
        
        //遍历账号 每拿到一个汉字就将账号的长度+1
        for (int i = 0; i < nowLength ; i++) {
            temp = [_userName.text substringWithRange:NSMakeRange(i, 1)];
            //判断字符是否是汉字
            if ([temp isMatchedByRegex:regex]) {
                addLength++;
            }
        }
        nowLength += addLength;
        if (nowLength < 4 || nowLength > 16) {
            //            [SystemDialog alert:@"账号应为4-16位英文、数字或中文！且首字母不能为数字！"];
            return;
        }
    }
     */
    /*0重置成功-1重置失败-3一定时间内不能重复发送请求 -4参数userId为空  -5输入的用户名不存在*/
    NSDictionary *dict = @{@"userId": _userName.text};
        HttpService *tempservice = [HttpService  HttpInitPostForm:kSeekPwdURL
                                                             body:dict
                                                          withHud:YES];
        [tempservice  setDataHandler:^(NSString *data)
         {
             NSDictionary *dict = [data objectFromJSONString];
             NSString *result = [dict objectForKey:@"respcode"];
        
             if ([result integerValue]==0) {
                 if (ChNil([dict objectForKey:@"message"])) {
                     [SystemDialog alert:@"邮箱未绑定"];
                 }else{
                     NSString *email = [NSString stringWithFormat:@"%@",[dict objectForKey:@"message"]];
                     [SystemDialog alert:email];
                 }
             }
      
             if ([result integerValue]==-1) {
                 [SystemDialog alert:[dict objectForKey:@"message"]];
             }
             if ([result integerValue]==-3) {
                 [SystemDialog alert:[dict objectForKey:@"message"]];
             }
             if ([result integerValue]==-4) {
                 [SystemDialog alert:[dict objectForKey:@"message"]];
             }
             if ([result integerValue]==-5) {
                 [SystemDialog alert:[dict objectForKey:@"message"]];
             }
         }];
        
        [self getError:tempservice];
        [tempservice startOperation];
}
//网络异常
- (void)getError:(HttpService *)tempservice
{
    [tempservice setErrorHandler:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [SystemDialog alert:kConnectFailure];
        });
    }];
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [self.view endEditing:YES];
}
@end
