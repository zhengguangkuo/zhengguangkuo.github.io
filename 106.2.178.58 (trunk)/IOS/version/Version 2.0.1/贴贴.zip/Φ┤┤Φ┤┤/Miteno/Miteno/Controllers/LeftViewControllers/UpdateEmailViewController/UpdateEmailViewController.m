//
//  AccountViewController.m
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "UpdateEmailViewController.h"
#import "UIView(category).h"
#import "UIButton(addtion).h"
#import "UIImage(addition).h"
#import "AppDelegate.h"
#import "NSString(Additions).h"
#import "AccountViewController.h"
#import "AppDelegate.h"


@interface UpdateEmailViewController ()
@property  (nonatomic, strong)  UITableView* MailTableView;

@end



@implementation UpdateEmailViewController

@synthesize MailTableView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"修改邮箱";
        self.view.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self  NavigationViewBackBtn];
    UITapGestureRecognizer*tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(ResignKeyBoard)];
    [self.view addGestureRecognizer:tap];
    
    
    self.MailTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 320, 100 + TableExtraHeight) style:UITableViewStylePlain];
    [MailTableView setDataSource:self];
    [MailTableView setDelegate:self];
    [MailTableView setScrollEnabled:NO];
    [MailTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [MailTableView setBackgroundColor:[UIColor clearColor]];
    
    [self.view addSubview:self.MailTableView];
    
    

    
    UIImage* LightImage = [UIImage imageNamed:@"btn_bg_light"];
    UIButton*  okBtn = [UIButton ButtonWithParms:[UIColor whiteColor] title:@"确认" bgnormal:LightImage imgHighlight:nil target:self action:@selector(requestUpdateEmail)];
    [okBtn setFrame:CGRectMake(ScreenWidth/2 - 60, MailTableView.frame.origin.y + MailTableView.frame.size.height, 120, 40)];
    [self.view addSubview:okBtn];


    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    return 1;
}


-(UITableViewCell *)tableView:(UITableView *)tableView
		cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString*  MailIdentifier = @"MailTable";
    UITableViewCell*  tempcell2 = nil;
    tempcell2 = [tableView dequeueReusableCellWithIdentifier:MailIdentifier];
    
    if(tempcell2==nil)
    {
        tempcell2 = [[UITableViewCell  alloc]  initWithStyle:UITableViewCellStyleDefault reuseIdentifier:MailIdentifier];
        tempcell2.selectionStyle = UITableViewCellSelectionStyleNone;
        
        UITextField* input3 = [[UITextField alloc] initWithFrame:CGRectMake(8, 8, 300, 40)];
        input3.keyboardType = UIKeyboardTypeDefault;
        input3.returnKeyType = UIReturnKeyDefault;
        input3.leftViewMode=UITextFieldViewModeAlways;
        input3.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 3, 40)];
        [input3 setText:@""];
        
        AppDelegate* app = [AppDelegate getApp];
        NSString* emailText = app.userAccout.Email;
        if(emailText)
        [input3 setText:emailText];
        
        [input3 setDelegate:self];
        input3.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        [input3 setFont:[UIFont systemFontOfSize:15.0f]];
        [input3  ViewWithBorder:[UIColor orangeColor]];
        [tempcell2.contentView addSubview:input3];
        [input3 setTag:3];
    }
    return tempcell2;
	
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
 	UIView*  tempview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 36)];
    
//  UITapGestureRecognizer*tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(ResignKeyBoard)];
//    [tempview addGestureRecognizer:tap];

    tempview.backgroundColor = [UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1];
    UILabel* titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(4, 2, 150, 32)];
    [titleLabel setFont:[UIFont systemFontOfSize:14.0f]];
    [titleLabel setTextColor:[UIColor blackColor]];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [tempview addSubview:titleLabel];
    
    [titleLabel setText:@"电子邮箱"];
    
    return tempview;
}



- (void)ResignKeyBoard
{
    NSIndexPath* Path = [NSIndexPath indexPathForRow:0 inSection:0];
    UITableViewCell* cell = [MailTableView cellForRowAtIndexPath:Path];
    UITextField*  filed = (UITextField*)[cell viewWithTag:3];
    [filed resignFirstResponder];
}



- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 36.0f;
}



- (void)viewDidAppear:(BOOL)animated
{
    [super  viewDidAppear:YES];
    
    dispatch_async(dispatch_get_main_queue(),
   ^{
       NSIndexPath* Path = [NSIndexPath indexPathForRow:0 inSection:0];
       UITableViewCell* cell = [MailTableView cellForRowAtIndexPath:Path];
       UITextField*  filed = (UITextField*)[cell viewWithTag:3];
       [filed becomeFirstResponder];
    });
}



- (void)requestUpdateEmail
{
    NSIndexPath* Path = [NSIndexPath indexPathForRow:0 inSection:0];
    UITableViewCell* cell = [MailTableView cellForRowAtIndexPath:Path];
    UITextField*  filed = (UITextField*)[cell viewWithTag:3];
    
    
    dispatch_async(dispatch_get_main_queue(),
    ^{
        [filed resignFirstResponder];
    });

    
    if(IsEmptyString([filed text]))
    {
        [self.view makeToast:@"电子邮箱不能为空!"];
        return;
    }
    else
    if(![NSString  checkEmail:[filed text]])
    {
        [self.view makeToast:@"请输入正确格式的电子邮箱!"];
        return;
    }
    
    NSString*  testURL =  [NSString stringWithFormat:@"%@%@",  WEB_SERVICE_ENV_VAR,Key_Secrity_UpdatePwd];
    NSLog(@"testURL = %@",testURL);
    
    AppDelegate* app = [AppDelegate getApp];
 
    NSDictionary* dic = [NSDictionary dictionaryWithObjectsAndKeys:
            app.userAccout.PassWord,@"originalpwd",
            app.userAccout.PassWord,@"newpwd",
            [filed text],@"email",
                     nil];
    
    NSLog(@"filed text = %@",[filed text]);
    
    HttpService*  tempservice = [HttpService  HttpInitPostForm:testURL
                        body:dic
                    withHud:YES];
    
    [tempservice  setDataHandler:^(NSString* data)
     {
         NSLog(@"data = %@",data);
         
         [self ParseJsonToMessage:data block:^{
             
             dispatch_async(dispatch_get_main_queue(),
            ^{
                AccountViewController* AVCtr = (AccountViewController*)[self GetPreController];
                [AVCtr setRefreshFlag:YES];
                [self backToPrevious];
             });
             
         }];
         
     }
     ];
    [tempservice startOperation];

}

@end
