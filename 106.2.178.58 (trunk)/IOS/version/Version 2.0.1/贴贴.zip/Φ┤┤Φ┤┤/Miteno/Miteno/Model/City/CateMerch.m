//
//  CateMerch.m
//  Miteno
//
//  Created by wg on 14-4-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "CateMerch.h"

@implementation CateMerch
- (id)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.ID = dict[@"_ID"];
        self.type_code = dict[@"TYPE_CODE"];
        self.type_name = dict[@"TYPE_NAME"];
        self.type_level = dict[@"TYPE_LEVEL"];
        self.super_type = dict[@"SUPER_TYPE"];
    }
    return self;
}
@end
