//
//  BasicCard.m
//  M-Pay
//
//  Created by guorong on 14-2-24.
//  Copyright miteno 2014年. All rights reserved.
//

#import "Credits.h"

@implementation ID

@synthesize user_id;
@synthesize c_iss_id;

@end


@implementation Credits

@synthesize creditsID;
@synthesize credits;
@synthesize creditsIssuer;

@end


@implementation CouponIssuer

@synthesize cname;
@end
