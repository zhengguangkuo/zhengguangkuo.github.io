//
//  BasicCard.m
//  M-Pay
//
//  Created by guorong on 14-2-24.
//  Copyright miteno 2014年. All rights reserved.
//

#import "BasicCard.h"

@implementation BasicCard

@synthesize bind_flag;
@synthesize input_tip;
@synthesize card_no_len;
@synthesize card_type;
@synthesize pic_path;
@synthesize card_no;
@synthesize card_bin;
@synthesize card_name;

@end
