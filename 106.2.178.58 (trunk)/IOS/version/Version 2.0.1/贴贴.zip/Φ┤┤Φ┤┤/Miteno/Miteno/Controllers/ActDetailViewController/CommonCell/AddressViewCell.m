//
//  AddressViewCell.m
//  Miteno
//
//  Created by HWG on 14-3-20.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "AddressViewCell.h"
#define kAddressSpace 15
#define kCellFrameH 80
@implementation AddressViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
//        self.selectionStyle = UITableViewCellSelectionStyleGray;
        [self addChildViews];
        self.bounds = CGRectMake(0, 0, 290, 88);
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}
- (void)addChildViews
{
    CGSize size = self.frame.size;
    
    _header = [[UILabel alloc] init];
    _header.textColor = Orange;
    [_header setFont:[UIFont systemFontOfSize:20]];
    _header.backgroundColor = [UIColor clearColor];
    _header.frame= CGRectMake(15, 0,size.width-80,44);

    [self addSubview:_header];
    _horizontal = [[UIImageView alloc] init];
    _horizontal.frame = CGRectMake(10, _header.frame.size.height, _header.frame.size.width+5, 0.5);
    _horizontal.backgroundColor = white3;
    [self addSubview:_horizontal];
    _content = [[UILabel alloc] init];
    _content.frame= CGRectMake(15,_horizontal.height+_horizontal.origin.y+15,_header.size.width,kCellFrameH);
    [_content setFont:[UIFont systemFontOfSize:15]];
    [self addSubview:_content];

    _Vertical = [[UIImageView alloc] init];
    _Vertical.frame = CGRectMake(_header.size.width+15,0,0.5,_content.height+_header.height);
    _Vertical.backgroundColor = white3;
    [self addSubview:_Vertical];

    _queryMap = [[UIButton alloc] init];
    [_queryMap setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    [_queryMap.titleLabel setFont:[UIFont systemFontOfSize:11]];
    _queryMap.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [_queryMap setTitle:@"查\n看\n地\n图" forState:UIControlStateNormal];
    _queryMap.titleLabel.numberOfLines=0;
    [_queryMap setBackgroundImage:[UIImage imageNamed:@"mini_locationIcon.png"] forState:UIControlStateNormal];
    _queryMap.frame = CGRectMake(_header.size.width+15.5,0,size.width-_header.size.width-12, _header.height+_content.size.height+_horizontal.height-55);
    _queryMap.center = CGPointMake(_header.size.width+20+(size.width-_header.size.width-12)/2, (_header.height+_content.size.height+_horizontal.height)/2-20);
    [self addSubview:_queryMap];
    
}
//赋值 and 自动换行,计算出cell的高度
-(void)setContentText:(NSString *)text{
    //获得当前cell高度
    CGRect frame = [self frame];
    self.content.text = text;
    self.content.numberOfLines = 10;
    CGSize size = CGSizeMake(_header.size.width, MAXFLOAT);
    CGSize labelSize = [self.content.text sizeWithFont:self.content.font constrainedToSize:size lineBreakMode:NSLineBreakByClipping];
    self.content.frame = CGRectMake(self.content.frame.origin.x, self.content.frame.origin.y, labelSize.width, labelSize.height);
    //计算出自适应的高度
    frame.size.height = labelSize.height+25 + _header.height+_horizontal.height+5;
    _Vertical.height = frame.size.height;
    self.frame = frame;
}
@end
