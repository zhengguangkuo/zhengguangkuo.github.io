//
//  RootViewController.m
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright wenguang 2014年. All rights reserved.
//

#import <Foundation/NSObject.h>
#import "RootViewController.h"
#import "MainNavigation.h"
#import "UIImage(addition).h"
#import "NSString(Additions).h"
#define kClientVersonURL [NSString stringWithFormat:@"%@mobile/coupon/versionReplace",kBaseURL]
//#import "SystemDialog.h"

@interface RootViewController ()
{
    NSString    * _newVersionUrl;
}
//@property  (nonatomic, strong)  MainNavigation* navigationbar;

//-(void)SetBackgroundImage;

@end


@implementation RootViewController


#define  FULL_SCREEN_Frame     [UIScreen mainScreen].applicationFrame

#define RGBCOLOR(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]


@synthesize service = _service;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        //        [self getClientVersion];
    }
    return self;
}

#pragma mark-  viewcontroller life circle

- (void)viewDidLoad
{
    [super viewDidLoad];
    //    self.view.backgroundColor = [UIColor whiteColor];
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}


-(void)viewDidAppear:(BOOL)animated
{
    [super viewWillAppear:NO];
}


-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:NO];
}


#pragma mark-  custom method for encapsulation navigationbar
- (void)SetNaviationTitleName:(NSString*)str
{
    UILabel*    titleLabel =  [[UILabel alloc] initWithFrame:CGRectMake(127, 16, 100, 32)];
    
    [titleLabel setTextColor:[UIColor whiteColor]];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [titleLabel setFont:[UIFont boldSystemFontOfSize:16.0f]];
    [self.navigationItem setTitleView:titleLabel];
    [titleLabel setText:str];
}

- (CGFloat)GetNavigationBarPosY
{
    return 64.0f;
}




-(void)NavigationViewBackBtn
{
    //    UIButton* barbutton=[UIButton buttonWithType:UIButtonTypeCustom];
    //    UIImage*  iconImage = [UIImage imageNamed:@"gb_button"];
    //    [barbutton setBackgroundImage:[UIImage imageNamed:@"top_bt_bg.png"] forState:UIControlStateNormal];
    //    [barbutton setImage:iconImage forState:UIControlStateNormal];
    //    [barbutton setFrame:CGRectMake(-12, 7, 58, 34)];
    //    [barbutton addTarget:self action:@selector(backToPrevious) forControlEvents:UIControlEventTouchUpInside];
    //    UIBarButtonItem* item = [[UIBarButtonItem alloc] initWithCustomView:barbutton];
    
    UIBarButtonItem *item =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                            andTitle:nil
                                            andImage:[UIImage imageNamed:@"gb_button"]
                                           addTarget:self
                                           addAction:@selector(backToPrevious)];
    
    UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];
    
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];
    //    [self.navigationItem setLeftBarButtonItem:item];
    
}


- (void)backToPrevious
{
    [self.navigationController  popViewControllerAnimated:YES];
}


-(void)NavigationHiddenBack
{
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:nil];
    
}

-(void)NavigationTitleColor:(UIColor*)color
{
    UILabel*  TitleLabel = (UILabel*)self.navigationItem.titleView;
    [TitleLabel setTextColor:color];
}



- (void)SetNaviationBgImg:(UIImage *)image
{
    [self.navigationController SetBackgroundImage:image];
}


- (void)SetNaviationRightButtons:(NSArray *)buttons
{
    NSMutableArray* array = [[NSMutableArray alloc] init];
    for(UIButton* btn in buttons)
    {
        UIBarButtonItem* item = [[UIBarButtonItem alloc] initWithCustomView:btn];
        [array addObject:item];
    }
    [self.navigationItem setRightBarButtonItems:array];
}


- (void)PopBoxMsg:(NSString *)WarningMsg
{
    dispatch_async(dispatch_get_main_queue(),
                   ^{
                       [self.view  makeToast:WarningMsg];
                   });
}

//- (int)GetCurrentController
//{
//   NSArray*  array = self.navigationController.viewControllers;
//    int i = 0;
//    for(i = 0; i < [array count]; i ++)
//   {
//       UIViewController* VCtr = array[i];
//       if(VCtr==self)
//      {
//          break;
//      }
//   }
//    return i;
//}


- (UIViewController*)GetPreController
{
    NSArray* array = self.navigationController.viewControllers;
    int n = [array count] - 2;
    UIViewController* VCtr = (UIViewController*)array[n];
    return VCtr;
}


- (NSString*)Md5Encry:(NSString*)pwd userName:(NSString*)User
{
    NSString*  newPwd = [NSString stringWithFormat:@"%@{%@}",pwd,User];
    return [newPwd md5];
}

- (void)getClientVersion
{
    NSDictionary *infoDic = [[NSBundle mainBundle] infoDictionary];
    //CFShow((__bridge CFTypeRef)(infoDic));
    NSString *currentVersion = [infoDic objectForKey:@"CFBundleVersion"];
    MyLog(@"当前版本号:%@",currentVersion);
    NSString *appleID = @"882398375";
    NSString *appURL = [NSString stringWithFormat:@"http://itunes.apple.com/lookup?id=%@",appleID];
    
    HttpService  *tempservice = [HttpService  HttpInitPostForm:appURL                                                                                                       body:nil withHud:YES];
    
    [tempservice setDataHandler:^(NSString *data) {
        MyLog(@"%@",data);
        NSDictionary *dicts = [data objectFromJSONString];
        if ([[dicts objectForKey:@"resultCount"] integerValue]<1) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"当前版本已是最新!" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alert show];
            return ;
        }
        NSArray *infoArray = [dicts objectForKey:@"results"];
        NSDictionary *releaseInfo = [infoArray objectAtIndex:0];
        NSString *latestVersion = [releaseInfo objectForKey:@"version"];
        
        //APPstrore应用程序的介绍界面URL
//        NSString *trackViewUrl = [releaseInfo objectForKey:@"trackViewUrl"];
        
        if (![latestVersion isEqualToString:currentVersion]) {
            //trackViewURL = [releaseInfo objectForKey:@"trackVireUrl"];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"当前不是最新,是否前往更新?" message:nil delegate:self cancelButtonTitle:@"前往更新" otherButtonTitles:@"下次再说", nil];
            alert.tag = 100001;
            [alert show];
        }else{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"当前版本已是最新!" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
            [alert show];
        }
    }];
    [tempservice startOperation];
   [self getError:tempservice];
}
//    _clientVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
//    NSDictionary *dict = @{@"versionNo":_clientVersion};
//    MyLog(@"当前版本号:%@",_clientVersion);

//    HttpService  *tempservice = [HttpService  HttpInitPostForm:kClientVersonURL
//                                                      body:dict
//                                                   withHud:YES];
//[tempservice setDataHandler:^(NSString *data) {
//
//    NSDictionary *dicts = [data objectFromJSONString];
//    //已是最新版本
//    if ([[dicts objectForKey:@"respcode"] integerValue]==0) {
//        MyLog(@"当前version%@",_clientVersion);
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"已是最新版本" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:@"取消", nil];
//        [alert show];
//    }
//    //新版本
//    if ([[dicts objectForKey:@"respcode"] integerValue]==1) {
//        //新版本更新的内容
////                    [SystemDialog alert:[dict objectForKey:@"replaceContent"]];
//
//        //最新版本号
////           [SystemDialog alert:[dict objectForKey:@"newVersionNo"]];
//        //新版本下载地址
//        NSString *newVersionUrl = [dicts objectForKey:@"linkAddress"];
//        _newVersionUrl = newVersionUrl;
////        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"当前版本已是最新!" message:nil delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
////        [alert show];
//        NSString *mesg = [NSString stringWithFormat:@"新版本%@",[dict objectForKey:@"newVersionNo"]];
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"当前不是最新,是否前往更新?" message:mesg delegate:self cancelButtonTitle:@"前往更新" otherButtonTitles:@"下次再说", nil];
//        alert.tag = 100001;
//        [alert show];
//    }
//    //版本号不正确
//    if ([[dicts objectForKey:@"respcode"] integerValue]==-1) {
//
//        [SystemDialog alert:[dict objectForKey:@"message"]];
//    }
//
//}];
//        [tempservice startOperation];
//        [self getError:tempservice];
//
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==10001) {
        
        if (buttonIndex == 0) {
            NSURL *url = [NSURL URLWithString:@"https://itunes.apple.com"];
            [[UIApplication sharedApplication]openURL:url];
        }
    }
}
- (void)getError:(HttpService *)tempservice
{
    [tempservice setErrorHandler:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [SystemDialog alert:kConnectFailure];
        });
    }];
}

@end
