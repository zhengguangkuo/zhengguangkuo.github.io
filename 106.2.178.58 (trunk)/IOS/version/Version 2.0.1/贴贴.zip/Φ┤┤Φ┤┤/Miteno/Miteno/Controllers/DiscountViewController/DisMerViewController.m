//
//  DisMerViewController.m
//  Miteno
//
//  Created by zhengguangkuo on 14-5-7.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "DisMerViewController.h"
#import "Dock.h"
#import "CouponCell.h"
#import "DiscountMerchantCell.h"
#import "Act.h"
#import "DisCountMerch.h"
#import "Utilities.h"
#import "BMKGeometry.h"
#import "BaseNavigationController.h"
#import "ActDetailViewController.h"
#import "MerchantViewController.h"

#define kToastMeg     @"已经没有卷啦...."
//优惠劵列表
#define kCouponListURL [NSString stringWithFormat:@"%@mobile/coupon/getMerchantActs/list",kBaseURL]
//http://192.168.16.40:8089/miteno-mobile/mobile/coupon/getMerchantActs/list
//折扣商家列表
#define kMerchListURL [NSString stringWithFormat:@"%@mobile/coupon/getMerchMpayDiscountByMerchant/list",kBaseURL]
//http://192.168.16.40:8089/miteno-mobile/mobile/coupon/getMerchMpayDiscountByMerchant/list


@interface DisMerViewController ()
{
    Dock                                *  _dock;
    UITableView                         *  _table;
    NSMutableArray                      *  _coupons;           //所有优惠劵
    NSMutableArray                      *  _discountMerchs;    //折扣商家优惠信息
    CLLocationManager                   *  _locatitonManager;
    CLLocationCoordinate2D                 _userCoordinate;
    
    MJRefreshHeaderView                 *  _header;            //上拉
    MJRefreshFooterView                 *  _footer;            //下拉
    NSUserDefaults                      *  _userDefaults;
    BOOL                           _isCoupon;
}

- (void)addHeaderView;
- (void)backButtonClicked;
- (void)addDock;
- (void)addTable;
@end

@implementation DisMerViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        _coupons = [NSMutableArray array];
        _discountMerchs = [NSMutableArray array];
    }
    return self;
}

- (id)init
{
    self = [super init];
    if (self) {
        _coupons = [NSMutableArray array];
        _discountMerchs = [NSMutableArray array];
    }
    return  self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self addHeaderView];
    [self addDock];
    [self addTable];
    // Do any additional setup after loading the view.
    [self loadCouponContent];
    _isCoupon = YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)addHeaderView
{
    UIImage *image = [UIImage imageNamed:@"nav_image_bg.png"];
    
    [self.navigationController.navigationBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
    self.title = @"商家优惠";
    UIBarButtonItem *item =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                            andTitle:nil
                                            andImage:[UIImage imageNamed:@"gb_button.png"]
                                           addTarget:self
                                           addAction:@selector(backButtonClicked)];
    
    UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];
    
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];

}

- (void)backButtonClicked
{
    [self dismissViewControllerAnimated:NO completion:nil];
}

- (void)addDock
{
    CGFloat dockY =  0;
    if (IOS7) {
        dockY = SIMULATOR?64:0;
    }
    _dock = [[Dock alloc] initWithFrame:CGRectMake(0,dockY, ScreenWidth, kDockHeight)];
    NSString *nor = @"nav_image_bg.png";
    NSString *select = @"business_bg";
//    [_dock addDockBtnWithBgIcon:nor selectIcon:select title:@"商家优惠券"];
//    [_dock addDockBtnWithBgIcon:nor selectIcon:select title:@"商家折扣"];
    [self.view addSubview:_dock];
    
    __unsafe_unretained DisMerViewController *discount =self;
   __block BOOL *tmpDiscount = NO;
    //监听item点击事件
    _dock.itemClickBlock = ^(int index){
        discount-> _header.hidden = NO;
        discount-> _footer.hidden = NO;
        
        if (index == 1) {
            [discount loadDiscountMerch];
            tmpDiscount = YES;
        }else{
            [discount loadCouponContent];
            tmpDiscount = NO;
        }
    };
}

- (void)addTable
{
    _table = [[UITableView alloc] initWithFrame:CGRectMake(0, _dock.frame.origin.y + _dock.frame.size.height, ScreenWidth, ScreenHeight - (TableExtraHeight + (CGFloat)45)) style:UITableViewStylePlain];
    
    
    [_table setDelegate:self];
    [_table setDataSource:self];
    [_table setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [_table setBackgroundColor:[UIColor clearColor]];
    [self.view addSubview:_table];
}

//优惠劵列表 下拉加载最小的
- (void)loadCouponContent
{
    long row = 10;
    int num = 1;
    NSString *page = [NSString stringWithFormat:@"%d",num];
    NSString *rows = [NSString stringWithFormat:@"%ld",row];
    NSString *merchantId = [NSString stringWithFormat:@"%@",self.merchantDet.merchId];
    NSDictionary *dict = @{@"page":page,
                           @"rows":rows,
                           @"merchId":merchantId};
    HttpService  *tempservice = [HttpService  HttpInitPostForm:kCouponListURL
                                                          body:dict
                                                       withHud:YES];
    
    [tempservice setDataHandler:^(NSString *data) {
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *arr = dicts[@"rows"];
        NSMutableArray *coupons = [NSMutableArray array];
        for (NSDictionary *dict in arr) {
            Act *act = [[Act alloc] initWithDict:dict];
            act.end_date = [dict objectForKey:@"end_date"];
            act.merch_name = self.merchantDet.cName;
            [coupons addObject:act];
        }
        _coupons = coupons;
        //刷新表格
        _isCoupon = YES;
        [_table reloadData];
        [_header endRefreshing];
        [SystemDialog alert:kEndMeg];
    }];
    
    [tempservice startOperation];
    [self getError:tempservice];
}
//优惠劵列表 上拉加载较大的
- (void)loadUpCouponContent
{
    long row = 10;
    int num = 1;
    if (_coupons.count) {
        int current = _coupons.count/row;
        num = current + 1;
    }
    NSString *page = [NSString stringWithFormat:@"%d",num];
    NSString *rows = [NSString stringWithFormat:@"%ld",row];
    NSString *merchantId = [NSString stringWithFormat:@"%@",self.merchantDet.merchId];
    NSDictionary *dict = @{@"page":page,
                           @"rows":rows,
                           @"merchId":merchantId};
    HttpService  *tempservice = [HttpService  HttpInitPostForm:kCouponListURL
                                                          body:dict
                                                       withHud:YES];
    
    [tempservice setDataHandler:^(NSString *data) {
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *arr = dicts[@"rows"];
        NSMutableArray *coupons = [NSMutableArray array];
        for (NSDictionary *dict in arr) {
            Act *act = [[Act alloc] initWithDict:dict];
            act.end_date = [dict objectForKey:@"end_date"];
            act.merch_name = self.merchantDet.cName;
            [coupons addObject:act];
        }
        [_coupons addObjectsFromArray:coupons];
        //总条数
        long total = [dicts[@"total"] integerValue];
        if (_coupons.count == total) {
            [SystemDialog alert:kToastMeg];
        }
        //刷新表格
        _isCoupon = YES;
        [_table reloadData];
        [_footer endRefreshing];
    }];
    
    [tempservice startOperation];
    [self getError:tempservice];
}
//折扣商家 下拉加载最小的
- (void)loadDiscountMerch{
    long row = 10;
    int num = 1;
    NSString *page = [NSString stringWithFormat:@"%d",num];
    NSString *rows = [NSString stringWithFormat:@"%ld",row];
    NSString *merchantId = [NSString stringWithFormat:@"%@",self.merchantDet.merchId];
    NSDictionary *dict = @{@"page":page,
                           @"rows":rows,
                           @"merchId":merchantId};
    HttpService  *tempservice = [HttpService  HttpInitPostForm:kMerchListURL
                                                          body:dict
                                                       withHud:YES];
    [tempservice setDataHandler:^(NSString *data) {
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *arr = dicts[@"rows"];
        NSMutableArray *newMerch = [NSMutableArray array];
        for (NSDictionary *dict in arr) {
            DisCountMerch *merch = [[DisCountMerch alloc] initWithDict:dict];
            [newMerch addObject:merch];
        }
        _discountMerchs = newMerch;
        [self hiddrenRefresh:_discountMerchs];
        //刷新表格
        _isCoupon = NO;
        [_table reloadData];
//        [_header endRefreshing];
        if (_discountMerchs.count == 0) {
            _header.hidden = YES;
            _footer.hidden = YES;
            [SystemDialog alert:@"暂无数据"];
        }else{
            _discountMerchs.count==0?:[SystemDialog alert:kEndMeg];
        }
        
    }];
    [tempservice startOperation];
    [self getError:tempservice];
    
}
//折扣商家 上拉加载较大的
- (void)loadUpDiscountMerch{
    long row = 10;
    int num = 1;
    if (_discountMerchs.count) {
        int current = _discountMerchs.count/row;
        num = current + 1;
    }
    NSString *page = [NSString stringWithFormat:@"%d",num];
    NSString *rows = [NSString stringWithFormat:@"%ld",row];
    NSDictionary *dict = @{@"page":page,
                           @"rows":rows,};
    HttpService  *tempservice = [HttpService  HttpInitPostForm:kMerchListURL
                                                          body:dict
                                                       withHud:YES];
    [tempservice setDataHandler:^(NSString *data) {
        
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *arr = dicts[@"rows"];
        NSMutableArray *newMerch = [NSMutableArray array];
        for (NSDictionary *newDict in arr) {
            DisCountMerch *merch = [[DisCountMerch alloc] initWithDict:newDict];
            [newMerch addObject:merch];
        }
        [_discountMerchs addObjectsFromArray:newMerch];
        //总条数
        long total = [dicts[@"total"] integerValue];
        if (_discountMerchs.count == total) {
            [SystemDialog alert:kToastMeg];
        }
        //刷新表格
        _isCoupon = NO;
        [_table reloadData];
        [_footer endRefreshing];
        
    }];
    [tempservice startOperation];
    [self getError:tempservice];
}

- (void)hiddrenRefresh:(NSMutableArray *)data
{
    if (data==nil) {
        [_header setHidden:YES];
        [_footer setHidden:YES];
    }
}

- (void)getError:(HttpService *)tempservice
{
    [tempservice setErrorHandler:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [_footer endRefreshing];
            [_header endRefreshing];
            [SystemDialog alert:kConnectFailure];
        });
    }];
}


#pragma table view data source methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    /*The count of discount Merchants is always 0,because no cell will return when reload the table with
     discount merchant data.*/
    return _isCoupon?_coupons.count:_discountMerchs.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (_isCoupon) {
        //优惠劵
        static  NSString *identifier = @"CouponCell";
        CouponCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell == nil) {
            cell = [[[NSBundle mainBundle]loadNibNamed:@"CouponCell" owner:self options:nil] lastObject];
            
            cell.merchantMessage.hidden = YES;
            CGFloat height = cell.cname.frame.size.height;
            CGRect cellFram = cell.deadline.frame;
            cell.deadline.frame = CGRectMake(cellFram.origin.x, cellFram.origin.y - height, cellFram.size.width, cellFram.size.height);
            CGRect issueFrame = cell.issueCount.frame;
            cell.issueCount.frame = CGRectMake(issueFrame.origin.x, issueFrame.origin.y - height, issueFrame.size.width, issueFrame.size.height);
        }
        if (!_coupons.count)             return cell;
        Act *act = _coupons[indexPath.row];
        cell.cname.text = act.act_name;
        NSString *date = [NSString stringWithFormat:@"%@-%@",act.start_date,act.end_date];
        cell.deadline.text = date;
        cell.issueCount.text = [NSString stringWithFormat:@"已经发放%d张",act.issued_cnt];
        if (![act.pic_path isKindOfClass:[NSNull class]]) {
            [cell.icon setImageFromUrl:act.pic_path];
        };
        
        cell.distance.hidden = YES;

        return cell;
    }else{
        
#warning TODO:cell shouble be designed again.
        //折扣商家
        static  NSString *identifier = @"DiscountStore";
        DiscountMerchantCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell == nil) {
            cell = [[[NSBundle mainBundle]loadNibNamed:@"DiscountMerchantCell" owner:self options:nil] lastObject];
        }
        
        if (!_discountMerchs.count){
            return cell;
        }
        DisCountMerch *merch = _discountMerchs[indexPath.row];
        if (![merch.picPath isKindOfClass:[NSNull class]]) {
            
            [cell.icon setImageFromUrl:merch.picPath];
        }
        CGFloat discount = [merch.discount floatValue];
        cell.merchantDiscount.text = [NSString stringWithFormat:@"%.1f折",discount*10] ;
        cell.merchantName.text = merch.merchant.cName;
        cell.distance.text = [NSString stringWithFormat:@"%f",merch.merchant.distance];
        return cell;
    }
}


#pragma table view data delegate methods
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (_isCoupon) {
        ActDetailViewController *actDetail = [[ActDetailViewController alloc] init];
        actDetail.act = _coupons[indexPath.row];
        [self.navigationController pushViewController:actDetail animated:YES];
    }else{
        MerchantViewController *merchantVc = [[MerchantViewController alloc] init];
        merchantVc.disCountMerch= _discountMerchs[indexPath.row];
        [self.navigationController pushViewController:merchantVc animated:YES];
    }
}


- (CLLocationDistance) getCLLocationDistance:(CLLocationCoordinate2D)merchantCoordinate
{
    CLLocationDistance dis = BMKMetersBetweenMapPoints(BMKMapPointForCoordinate(_userCoordinate), BMKMapPointForCoordinate(merchantCoordinate));
    return dis/1000.0;
}

- (void)getUserLocation
{
    if (!_locatitonManager) {
        _locatitonManager = [[CLLocationManager alloc]init];
    }
    if ([CLLocationManager locationServicesEnabled]) {
        _locatitonManager.delegate = self;
        _locatitonManager.desiredAccuracy = kCLLocationAccuracyBest;
        _locatitonManager.distanceFilter = 10.0f;
        [_locatitonManager startUpdatingLocation];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 88;
}

#pragma location manager methods
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    CLLocation *location = [locations lastObject];
    _userCoordinate = BMKCoorDictionaryDecode(BMKBaiduCoorForWgs84(location.coordinate));
    [_locatitonManager stopUpdatingLocation];
    NSLog(@"userLocationCoordinate:%f,%f",_userCoordinate.latitude,_userCoordinate.longitude);
}

@end
