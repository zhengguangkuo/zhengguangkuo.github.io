//
//  LoginViewController.m
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "LoginViewController.h"
#import "RegisterViewController.h"
#import "SeekPassWordViewController.h"
#import "UIKeyboardViewController.h"
#import "ActDetailViewController.h"
#import "AppDelegate.h"
#import "BasicSettingViewController.h"


#define kBgH    40

//登陆
#define kLoginURL [NSString stringWithFormat:@"%@mpayFront/j_spring_security_check",kBaseURL]

@interface LoginViewController ()<UIKeyboardViewControllerDelegate>
{
    UITextField                             *   _userNameField;     //账号编辑框
    UITextField                             *   _passwordField;     //密码编辑框
    UIKeyboardViewController                *   _keyBoardController; //键盘keyBoardTool
}
@property (nonatomic, strong)UIImageView    *   bgImageView;
@end

@implementation LoginViewController
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)loadView
{
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:kScreenBounds];
    scrollView.contentSize = CGSizeMake(0, 0);
    self.view = scrollView;
}
- (void)viewWillAppear:(BOOL)animated{
    _keyBoardController=[[UIKeyboardViewController alloc] initWithControllerDelegate:self];
	[_keyBoardController addToolbarToKeyboard];
}

- (void)viewDidAppear:(BOOL)animated
{
    [_userNameField becomeFirstResponder];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    //1.设置导航主题
    [self setNavTheme];
    
    //2.初始化视图
    [self initView];
}

#pragma mark -导航主题
- (void)setNavTheme
{
    self.title = @"用户登陆";
    
    //导航左边一个按钮
    UIBarButtonItem *item =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                            andTitle:nil
                                            andImage:[UIImage imageNamed:@"gb_button"]
                                           addTarget:self
                                           addAction:@selector(back)];
    
    UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];
    
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];
    //[UIBarButtonItem barButtonItemWithIcon:@"navigationbar_back.png" target:self action:@selector(back)];
    //右边
    self.navigationItem.rightBarButtonItem =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                            andTitle:@"注册"
                                            andImage:nil
                                           addTarget:self
                                           addAction:@selector(goRegister)];
    //[UIBarButtonItem barButtonItemWithBg:@"nav_image_bg.png" title:@"注册" size:CGSizeMake(70, 35) target:self action:@selector(goRegister)];
    
}
#pragma mark -初始化视图
- (void)initView
{
    //创建全局背景
//    _bgImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"loading_bg.png"]];
//    self.bgImageView.userInteractionEnabled = YES;
//    _bgImageView.frame = CGRectMake(0, 0, ScreenWidth, ScreenHeight);
//    _bgImageView.userInteractionEnabled = YES;
//    _bgImageView.backgroundColor = [UIColor clearColor];
//    [self.view addSubview:_bgImageView];
    
    //创建区域背景图片 (编辑账号/密码时/移动该视图)
//    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, ScreenWidth, ScreenHeight-64)];
//    view.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
////    view.backgroundColor = [UIColor clearColor];
//    [self.view addSubview:view];
    
    //机会无处不在图片
//    UIImageView * textImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"slogan.png"]];
//    textImage.frame = CGRectMake((self.view.frame.size.width-153)/2, 50, 153, 23);
//    //    textImage.alpha = 0.5;
//    [self.view addSubview:textImage];

    CGFloat color = 230/255.0;
    self.view.backgroundColor = [UIColor colorWithRed:color green:color blue:color alpha:1];
    //输入框背景
    UIImageView * editView = [[UIImageView alloc] initWithImage:[UIImage stretchImageWithName:@"loading_input.png"]];
    editView.clipsToBounds = YES;
    editView.userInteractionEnabled = YES;
    editView.backgroundColor = [UIColor clearColor];
    editView.frame = CGRectMake((self.view.frame.size.width-240)/2, 50, 240, kBgH*2);
//    editView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    //    editView.layer.borderWidth = 1.0f;
    //    editView.layer.borderColor = [UIColor colorWithWhite:0.05 alpha:0.1].CGColor;
    [self.view addSubview:editView];
    
    //账号label
    UILabel *userNameLabel = [[UILabel alloc] initWithFrame: CGRectMake(10, 0, 40, kBgH)];
    userNameLabel.backgroundColor = [UIColor clearColor];
    userNameLabel.autoresizingMask = UIViewAutoresizingNone;
    userNameLabel.text = @"账 号";
    userNameLabel.textColor = Black1;
    userNameLabel.font = [UIFont systemFontOfSize:15];
    [editView addSubview:userNameLabel];

    //账号 输入框
    _userNameField = [[UITextField alloc] initWithFrame:CGRectMake(userNameLabel.right+5, 0, 185, kBgH)];
    _userNameField.backgroundColor = [UIColor clearColor];
    _userNameField.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    _userNameField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    _userNameField.tag =  kSignUpItemUserNameField;
    _userNameField.textColor = [UIColor grayColor];
    _userNameField.font = [UIFont systemFontOfSize:13.0f];
    _userNameField.placeholder = @"账号/手机号/邮箱";
    //    _userNameField.delegate = self;
    //    userNameField.keyboardType = UIKeyboardTypeASCIICapable;
    _userNameField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [editView addSubview:_userNameField];
    
    
    //密码label
    UILabel *passwordLabel = [[UILabel alloc] initWithFrame: CGRectMake(10, 40, 40, kBgH)];
    passwordLabel.backgroundColor = [UIColor clearColor];
    passwordLabel.autoresizingMask = UIViewAutoresizingNone;
    passwordLabel.text = @"密 码";
    passwordLabel.textColor = Black1;
    passwordLabel.font = [UIFont systemFontOfSize:15];
    [editView addSubview:passwordLabel];
    
    
    //密码 输入框
    _passwordField = [[UITextField alloc] initWithFrame:CGRectMake(passwordLabel.right+5, 40, 185, kBgH)];
    _passwordField.backgroundColor = [UIColor clearColor];
    _passwordField.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    _passwordField.tag =  kSignUpItemPasswordField;
    _passwordField.textColor = [UIColor grayColor];
    _passwordField.font = [UIFont systemFontOfSize:13.0f];
    _passwordField.placeholder = @"6-16位数字或字母";
    _passwordField.secureTextEntry = YES;
    //    _passwordField.delegate = self;
    _passwordField.keyboardType = UIKeyboardTypeASCIICapable;
    _passwordField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [editView addSubview:_passwordField];
    
    
    //登录按钮
    UIButton * signInButton = [UIButton buttonWithType:UIButtonTypeCustom];
    signInButton.frame = CGRectMake((ScreenWidth/2-30), editView.bottom+30, 60, 37);
    signInButton.backgroundColor = [UIColor clearColor];
    signInButton.tag = KSignInButtonSignIn;
    signInButton.showsTouchWhenHighlighted = YES;
    [signInButton setTitle:@"登录" forState:UIControlStateNormal];
    [signInButton setBackgroundImage:[UIImage imageNamed:@"registerBtn.png"] forState:UIControlStateNormal];
    [signInButton setTitleColor:Black1 forState:UIControlStateNormal];
    //    [signInButton setTitleColor:white1 forState:UIControlStateHighlighted];
    [signInButton addTarget:self action:@selector(requestSignIn) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:signInButton];
    
    
    //忘记密码按钮
    UIButton * ForgetButton = [UIButton buttonWithType:UIButtonTypeCustom];
    ForgetButton.frame = CGRectMake((ScreenWidth/2-120), editView.bottom+80, 240, 37);
    ForgetButton.backgroundColor = [UIColor clearColor];
    ForgetButton.tag = KSignInButtonForgetpassword;
    ForgetButton.showsTouchWhenHighlighted = YES;
    ForgetButton.titleLabel.font = [UIFont systemFontOfSize:13];
    [ForgetButton setTitle:@"忘记密码?请点击这里" forState:UIControlStateNormal];
    [ForgetButton setTitleColor:Blue forState:UIControlStateNormal];
    [ForgetButton addTarget:self action:@selector(seekPassWord) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:ForgetButton];
    
}
#pragma mark -登录
- (void)requestSignIn
{
    NSString *userName = _userNameField.text;
    NSString *passWord = _passwordField.text;
    NSString * regex = @"(^[\\w]{6,16}$)";
    if (userName==nil||[userName isEqualToString:@""]) {
        [SystemDialog alert:@"请输入账号"];
        return;
    }
    if (passWord == nil ||[passWord isEqualToString:@""]) {
        [SystemDialog alert:@"请输入密码"];
        return;
    }
    if(![passWord isMatchedByRegex:regex]){
        [SystemDialog alert:@"密码应为6-16位数字或字母！\n"];
        return;
    }
    [_userNameField resignFirstResponder];
    [_passwordField resignFirstResponder];
    
    //加密格式
    NSString *appendPassWord = [NSString stringWithFormat:@"%@{%@}",passWord,userName];
    //md5加密
    NSString *md5PassWord = [appendPassWord md5Encrypt];
    
    UserInfo* account = [[UserInfo alloc] init];
    [account setUserName:userName];
    [account setPassWord:md5PassWord];

//    NSString *loginURL = [NSString stringWithFormat:@"%@mpayFront/j_spring_security_check",kBaseURL];
    
    
    NSDictionary *dict = @{@"j_username":userName,
                           @"j_password":md5PassWord
                           };
    HttpService  *tempservice = [HttpService  HttpInitPostForm:kLoginURL
                                                          body:dict
                                                       withHud:YES];
    
    AppDelegate* app = [AppDelegate getApp];
    
    [tempservice setDataHandler:^(NSString *data) {
        NSLog(@"Login data = %@",data);
        NSDictionary *dicts = [data objectFromJSONString];
        //登陆成功
        
                if ([[dicts objectForKey:@"respcode"] integerValue]==0||[[dicts objectForKey:@"respcode"] integerValue]>6) {
                    [app.userAccout LoginAccount:account];

                    if (self.backController) {
                       [self.navigationController popViewControllerAnimated:YES];
                    }else{
                         [self.navigationController popToRootViewControllerAnimated:NO];
                    }
                    NSString *reValue = [dicts objectForKey:@"message"];
                    if (reValue==nil) {
                        [SystemDialog alert:@"登陆成功"];
                    }else{
                        [SystemDialog alert:reValue];
                    }
                }
                //初次登陆成功进入新手引导页

               if ([[dicts objectForKey:@"respcode"] integerValue]==6) {
                   [SystemDialog alert:[dicts objectForKey:@"message"]];
                   [app.userAccout LoginAccount:account];
                   [app.userAccout setIsFirstLogin:TRUE];
                   
                   if(app.userAccout.isFirstLogin==TRUE)
                   {
                       BasicSettingViewController* BSCtr =[[BasicSettingViewController alloc] init];
                       [self.navigationController pushViewController:BSCtr animated:YES];
                       [BSCtr ShowBottomButtonsOrNot];
                   }
//                   [SystemDialog alert:@"登陆成功"];
               }
               //登陆失败
              if ([[dicts objectForKey:@"respcode"] integerValue]==-1) {
                   [SystemDialog alert:[dicts objectForKey:@"message"]];
              }

    }];
    
    [self getError:tempservice];
    [tempservice startOperation];
}
//网络异常
- (void)getError:(HttpService *)tempservice
{
    [tempservice setErrorHandler:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [SystemDialog alert:kConnectFailure];
        });
    }];
}
#pragma mark 返回上一级控制器
-(void)back{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark 进入注册控制器
- (void)goRegister
{
     RegisterViewController *registe = [[RegisterViewController alloc] init];
    
    [self.navigationController pushViewController:registe animated:YES];
}
#pragma mark 监听屏幕点击 退出键盘
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    //退出键盘
    [_bgImageView endEditing:YES];
}
#pragma mark -找回密码
- (void)seekPassWord
{
    SeekPassWordViewController *seek = [[SeekPassWordViewController alloc] initWithNibName:@"SeekPassWordViewController" bundle:nil];
    [self.navigationController pushViewController:seek animated:YES];
}

@end
