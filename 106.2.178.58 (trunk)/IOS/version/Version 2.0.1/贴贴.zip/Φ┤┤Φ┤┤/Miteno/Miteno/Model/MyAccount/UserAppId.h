//
//  UserAppId.h
//  Miteno
//
//  Created by wg on 14-4-14.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "BaseModel.h"

@interface UserAppId : BaseModel
@property (nonatomic, strong) NSString  * appId;
@property (nonatomic, strong) NSString  * userId;


@end
