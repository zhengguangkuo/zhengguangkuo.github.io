//
//  Merchant.h
//  Miteno
//
//  Created by HWG on 14-3-12.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "BaseModel.h"

@interface Merchant : BaseModel
@property (nonatomic, copy)NSString *  cName;
@property (nonatomic, assign)double  distance;

@end
