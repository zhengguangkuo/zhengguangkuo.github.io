//
//  Contact.m
//  Miteno
//
//  Created by wg on 14-4-2.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "Contact.h"

@implementation Contact
- (id)initWithDict:(NSDictionary *)dict
{
    if (self = [super initWithDict:dict]) {

        self.areaCode = dict[@"areaCode"];
        self.phone = dict[@"phone"];
        self.ext = dict[@"ext"];
    }
    return self;
}
@end
