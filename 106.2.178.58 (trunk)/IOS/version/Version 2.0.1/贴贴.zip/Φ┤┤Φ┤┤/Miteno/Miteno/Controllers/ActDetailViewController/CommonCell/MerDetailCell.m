//
//  MerDetailCell.m
//  Miteno
//
//  Created by wg on 14-3-27.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "MerDetailCell.h"

@implementation MerDetailCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self initLayout];
    }
    return self;
}
- (void)initLayout
{
    _content = [[UILabel alloc] init];
    _content.frame = CGRectMake(15, 10, 290, 44);
    [_content setFont:[UIFont systemFontOfSize:15]];
    _content.backgroundColor = [UIColor clearColor];
    [self addSubview:_content];
}
//赋值 and 自动换行,计算出cell的高度
-(void)setIntroductionText:(NSString*)text{
    //获得当前cell高度
    CGRect frame = [self frame];
    //文本赋值
    self.content.text = text;
    //设置label的最大行数
    self.content.numberOfLines = 10;
    CGSize size = CGSizeMake(270, MAXFLOAT);
    CGSize labelSize = [self.content.text sizeWithFont:self.content.font constrainedToSize:size lineBreakMode:NSLineBreakByClipping];
    self.content.frame = CGRectMake(self.content.frame.origin.x, self.content.frame.origin.y, labelSize.width, labelSize.height);
    
    //计算出自适应的高度
    frame.size.height = labelSize.height+25;
    
    self.frame = frame;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
