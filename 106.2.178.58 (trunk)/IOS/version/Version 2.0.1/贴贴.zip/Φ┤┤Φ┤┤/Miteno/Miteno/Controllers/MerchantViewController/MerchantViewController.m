//
//  MerchantViewController.m
//  Miteno
//
//  Created by HWG on 14-3-23.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//
#import "MerchantViewController.h"
#import "ActDetailCell.h"
#import "PhoneCell.h"
#import "DetailCell.h"
#import "MerchantDetail.h"
#import "DisCountMerch.h"
#import "Contact.h"
#import "Dock.h"
#import "AFNetworking.h"
#import "AddressViewCell.h"
#import "MerDetailCell.h"
#import "DisMerDetailViewController.h"
#import "Base64.h"
#import "MapsViewController.h"
#define kTopImageHeight ScreenHeight*0.25
#define kImageBarHeight 50
#define kSpace 0
#define kClaimedHeight kImageBarHeight
#define kMerchantURL [NSString stringWithFormat:@"%@mobile/coupon/merchMpayDiscountView/list",kBaseURL]
#define kMer @"http://app.yacol.com/yacolApp/mobile/store.do"
#define kCellHeight 44
#define kRankWeidth 20
#define kRankHeight 25
#define kFount  [ UIFont systemFontOfSize:15]
//由于cell不规格。将每个cell抽出来
@interface MerchantViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    UIImageView     *  _topImageView;    //顶部图片
    UILabel         *  _title;           //商家标题
    UILabel         *  _discount;        //雅酷价格折扣
    Dock            *  _rank;            //等级度
    UIView          *  _imgBar;
    UITableView     *  _merchantView;    //tableView
    NSArray         *  _headTitle;       //标题数组
    NSString        *  _telephone;       //记录号码
    NSString        *  _intro;           //商家介绍
    NSString        *  _xPos;            //商家坐标x
    NSString        *  _yPos;            //商家y
}
@property (nonatomic, strong)NSMutableArray *merDetails;
@property (nonatomic, copy)NSString *iconPath;
@property (nonatomic, copy)void (^blockIcon)(NSString *iconPath);
@end

@implementation MerchantViewController
@synthesize disCountMerch;
- (void)loadView
{
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:kScreenBounds];
    scrollView.contentSize = CGSizeMake(ScreenWidth, ScreenHeight+200);
    self.view = scrollView;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.view.backgroundColor = white2;
        self.merDetails = [NSMutableArray array];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"商家介绍";
    _headTitle = [NSArray arrayWithObjects:@"商家信息",@"商家地址",@"乘车路线",@"联系方式", nil];
    
    UIBarButtonItem *item =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                            andTitle:nil
                                            andImage:[UIImage imageNamed:@"gb_button"]
                                           addTarget:self
                                           addAction:@selector(back)];
    
    UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];
    
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];
    //[UIBarButtonItem barButtonItemWithIcon:@"top_bt_bg.png" target:self action:@selector(back)];
    
    [self addImageView];
    [self addViewAndTableView];
}
- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark -添加imageView
- (void)addImageView
{
    _topImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0,0, ScreenWidth, kTopImageHeight)];
//    _topImageView.backgroundColor = [UIColor brownColor];
    _topImageView.userInteractionEnabled = YES;
    [self.view addSubview:_topImageView];
    _imgBar = [[UIView alloc] initWithFrame:CGRectMake(0, _topImageView.frame.size.height, ScreenWidth, kImageBarHeight)];
    _imgBar.backgroundColor = kGlobalBg;
    [_topImageView addSubview:_imgBar];
    
    CGFloat width = 70;
    _discount = [[UILabel alloc] initWithFrame:CGRectMake(_imgBar.frame.size.width-width+100+25,kSpace,ScreenWidth-_imgBar.frame.size.width-width-100,kClaimedHeight)];
    _discount.backgroundColor = [UIColor clearColor];
    _discount.font = [UIFont fontWithName:@"TrebuchetMS-Bold" size:20];
    _discount.textColor = Orange;
    //    _discount.text = @"9.7折";
    [_imgBar addSubview:_discount];
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(_imgBar.frame.size.width-width-100,kSpace, width,kClaimedHeight)];
    title.backgroundColor = [UIColor clearColor];
    title.textColor = Orange;
    title.font = [UIFont systemFontOfSize:12];
    title.text = @"雅酷价格:";
    [_imgBar addSubview:title];
}
#pragma mark -添加tableview
- (void)addViewAndTableView
{
    //商户名称
    CGFloat y = kTopImageHeight + _imgBar.height;
    _title = [[UILabel alloc] initWithFrame:CGRectMake(kActDetailSpace, y, ScreenWidth, 40)];
    _title.font = [UIFont boldSystemFontOfSize:23];
    _title.backgroundColor = [UIColor clearColor];
    _title.text = @"商家名称";
    [self.view addSubview:_title];
    //等级
    _rank = [[Dock alloc] initWithFrame:CGRectMake(_title.origin.x,_title.height+_title.origin.y,ScreenWidth, kRankHeight)];
    _rank.backgroundColor = [UIColor clearColor];
    for (int i = 0; i <5; i++){
        UIImageView *rankView = [[UIImageView alloc] init];
        rankView.frame = CGRectMake(kRankWeidth*i, 0,kRankWeidth,_rank.height);
        rankView.image = [UIImage imageNamed:@"common_icon_membership@2x.png"];
        [_rank addSubview:rankView];
    }
    [self.view addSubview:_rank];
    //addTableView
    _merchantView= [[UITableView alloc] initWithFrame:CGRectMake(0,y+_title.height+_rank.height, ScreenWidth,self.view.height+150) style:UITableViewStyleGrouped];
    _merchantView.backgroundColor = white2;
    _merchantView.sectionHeaderHeight = 10;
    _merchantView.sectionFooterHeight = 5;
    _merchantView.delegate = self;
    _merchantView.dataSource = self;
    _merchantView.scrollEnabled = NO;
    [self.view addSubview:_merchantView];
}
#pragma mark -tableViewDelegateAndDatasources
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
    //return _headTitle.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==1) {
        return 1;
    }else{
        return 2;
    }
}
#pragma mark -cell delegate
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MerchantDetail *mer = [_merDetails lastObject];
    if (indexPath.row==0) {
        if (indexPath.section==1) {
            static NSString *ID = @"AddressViewCell";
            AddressViewCell *adCell = (AddressViewCell *)[tableView dequeueReusableCellWithIdentifier:ID];
            if (adCell == nil) {
                adCell = [[AddressViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
            }
            adCell.header.text = _headTitle[indexPath.section];
            adCell.content.text = mer.addr;
            [adCell setContentText:adCell.content.text];
            [adCell.queryMap addTarget:self action:@selector(queryMap) forControlEvents:UIControlEventTouchUpInside];
            _xPos = mer.xpos;
            _yPos = mer.ypos;
            return adCell;
        }
        static  NSString *identifier = @"UITableViewCell";
        ActDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell==nil) {
            cell = [[ActDetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        }
        //设置标题
        if (indexPath.row == 0&&indexPath.section!=1) {
            cell.textLabel.textColor = Orange;
            [cell.textLabel setFont:[UIFont systemFontOfSize:20]];
            cell.textLabel.text = _headTitle[indexPath.section];
        }
        return cell;

        

    }else{
        static  NSString *identifier = @"ActDetailCell";
        ActDetailCell *cell = (ActDetailCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell == nil) {
            cell = [[ActDetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
            cell.textLabel.numberOfLines = 0;
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            
        }
        if (indexPath.section==0) {
            static  NSString *detailCellIdentifier = @"DetailCell";
            DetailCell *detailCell = (DetailCell *)[tableView dequeueReusableCellWithIdentifier:detailCellIdentifier];
            if (detailCell == nil) {
                detailCell = [[DetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:detailCellIdentifier];
            }
            [detailCell.merDetail addTarget:self action:@selector(queryMerchant) forControlEvents:UIControlEventTouchUpInside];
            cell = detailCell;
        }
        if (indexPath.section==2) {
            static NSString *tt =@"MerDetailCell";
            MerDetailCell *merDetail = [tableView dequeueReusableCellWithIdentifier:tt];
            if (merDetail==nil) {
                merDetail = [[MerDetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:tt];
            }
            NSStringEncoding *gbkEncoding = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
            merDetail.content.text = [mer.busline base64DecodedString:gbkEncoding];
            [merDetail setIntroductionText:merDetail.content.text];
            cell = merDetail;
        }
        if (indexPath.section==3) {
            static NSString *phoneIdentifier =@"PhoneCell";
            PhoneCell *phoneCell = [tableView dequeueReusableCellWithIdentifier:phoneIdentifier];
            if (phoneCell==nil) {
                phoneCell = [[PhoneCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:phoneIdentifier];
            }
            phoneCell.number.text = mer.contact.phone;
            _telephone = mer.contact.phone;
            [phoneCell.phoneIcon addTarget:self action:@selector(call) forControlEvents:UIControlEventTouchUpInside];
            cell = phoneCell;
        }
        return cell;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    int cellHeight = kCellHeight;
    if (indexPath.section==1) {
        AddressViewCell *address = (AddressViewCell *)[self tableView:_merchantView cellForRowAtIndexPath:indexPath ];
        cellHeight = address.frame.size.height;
    }
    if (indexPath.section==2&&indexPath.row==1) {
        MerDetailCell *mer = (MerDetailCell *)[self tableView:_merchantView cellForRowAtIndexPath:indexPath ];
        cellHeight = mer.frame.size.height;
    }
    
    return cellHeight;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return section==0?20:15;
}
#pragma mark -商家介绍
- (void)queryMerchant
{
    DisMerDetailViewController *merDetail = [[DisMerDetailViewController alloc] init];
    merDetail.intro = _intro;
    [self.navigationController pushViewController:merDetail animated:YES];
}
- (void)queryMap
{
    MyLog(@"地图-xpos:%@,-ypos:%@",_xPos,_yPos);
    MapsViewController *mapViewController = [[MapsViewController alloc]init];
    [self presentViewController:mapViewController animated:NO completion:nil];
    
    CLLocationCoordinate2D coordinate;
    coordinate.longitude = [_xPos doubleValue];
    coordinate.latitude = [_yPos doubleValue];
    [mapViewController addAnnotationViewWithCLLocationCoordinate2D:coordinate andMerchName:self.disCountMerch.merchant.cName];
}
- (void)call
{
    if (_telephone!=nil) {
//        NSString *tel = [NSString stringWithFormat:@"tel://%@",_telephone];
//        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:tel]];
        NSMutableString *tel=[[NSMutableString alloc] initWithFormat:@"tel:%@",_telephone];
        UIWebView *callWebview = [[UIWebView alloc] init];
        [callWebview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:tel]]];
        [self.view addSubview:callWebview];
    }
}

#pragma mark -加载数据
- (void)viewWillAppear:(BOOL)animated
{
    //   NSString *merchMpayDiscountMerchId = @"";
#warning  这里以后会做修改，若merchMpayDiscountMerchId!="050"
#warning  则调用其它后台服务器或其它接口。暂未定
    
    NSString *otherMerchId = @"";
    if (self.disCountMerch) {
        otherMerchId = self.disCountMerch.otherMerchId;
        //这里设置topimage
        if (!ChNil(self.disCountMerch.picPath)) {
            [_topImageView setImageFromUrl:self.disCountMerch.picPath];
        }else{
            _topImageView.image = [UIImage imageNamed:@"load.png"];
        }
    }
    //固定参数
    NSString *type = [NSString stringWithFormat:@"%d",1];
    NSString *v = [NSString stringWithFormat:@"%.1f",1.3];
    NSString *uuid = [NSString uuid];
    NSDictionary *merchDiscount = @{@"id"         : otherMerchId,
                                    @"returnType" : @"json",
                                    @"type"       : type,
                                    @"v"          : v,
                                    @"callType"   : @"iphone",
                                    @"uuid"       : uuid
                                    };
    HttpService  *tempservice = [HttpService  HttpInitPostForm:kMer
                                                          body:merchDiscount
                                                       withHud:YES];
    [tempservice setBytyesHandler:^(NSData *data) {
        //GBK
        NSStringEncoding *gbkEncoding = CFStringConvertEncodingToNSStringEncoding(kCFStringEncodingGB_18030_2000);
        NSString *datas = [[NSString alloc] initWithData:data encoding:gbkEncoding];
        NSDictionary *dict = [datas objectFromJSONString];
        if (dict) {
            MerchantDetail *merDetail= [[MerchantDetail alloc] initWithDict:dict];
            [self.merDetails addObject:merDetail];
            //设置商家折扣价、格标题文字、图标
            _discount.text = [NSString stringWithFormat:@"%@",merDetail.disDescription] ;
            _title.text = merDetail.name;
            //base64解密
            _intro = [merDetail.intro base64DecodedString:gbkEncoding];
            
            if (_discount.text == nil) {
                [SystemDialog alert:@"抱歉,未搜索到数据"];
            }
        }
        //刷新表格
        [_merchantView reloadData];
    }];
    [tempservice startOperation];
    [self getError:tempservice];
}
//网络异常
- (void)getError:(HttpService *)tempservice
{
    [tempservice setErrorHandler:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [SystemDialog alert:kConnectFailure];
        });
    }];
}
@end
