//
//  webViewCell.h
//  Miteno
//
//  Created by wg on 14-5-16.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "ActDetailCell.h"

@interface WebViewCell : ActDetailCell
@property (nonatomic, strong)UILabel *header;
@property (nonatomic, strong)UIImageView *horizontal;//横向
@property (nonatomic, strong)UIButton *claimed;//领取按钮
@property (nonatomic, strong)UIWebView  *web;
@end
