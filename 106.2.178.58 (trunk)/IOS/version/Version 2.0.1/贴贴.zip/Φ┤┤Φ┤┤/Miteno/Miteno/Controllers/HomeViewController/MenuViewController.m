//
//  MenuViewController.m
//  M-Pay
//
//  Created by guorong on 14-2-24.
//  Copyright miteno 2014年. All rights reserved.
//

#import "MenuViewController.h"
#import "AboutViewController.h"
#import "AccountViewController.h"
#import "AssistViewController.h"
//#import "AppManagerController.h"
#import "AppManagementViewController.h"
#import "BasicSettingViewController.h"
#import "HelpViewViewController.h"
#import "MenuViewController.h"
#import "PointViewController.h"
//#import "updateViewController.h"
#import "ClientVersionViewController.h"
#import "MenuChooseViewController.h"
#import "MenuView.h"
#import "AppDelegate.h"
#import "BaseNavigationController.h"
#import "HomeViewController.h"
#import "UIView(Animation).h"
#import "AppDelegate.h"
#define  New(XXX) [[BaseNavigationController alloc]initWithRootViewController:[[XXX##ViewController alloc]init] ]

#define newVersion  @"检查更新"
@interface MenuViewController ()

@property (nonatomic, strong) UIView* clearDeckView;

@property (nonatomic, strong) NSDictionary* dictionay;

@property (nonatomic, strong) NSArray*  nameArray;

@property (nonatomic, strong) UIView   *customView;

@end

@implementation MenuViewController

@synthesize clearDeckView;

@synthesize dictionay;

@synthesize nameArray;

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];

    [self printViewHierarchy:self.navigationController.navigationBar];
    self.navigationController.navigationBar.frame = CGRectMake(0, 20,320, 0);
    [self printViewHierarchy:self.navigationController.navigationBar];
}

- (void)printViewHierarchy:(UIView *)superView
{
    static uint level = 0;
    for(uint i = 0; i < level; i++){
    }
    ++level;
    for(UIView *view in superView.subviews){
        [self printViewHierarchy:view];
    }
    --level;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    if (!IOS7) {
    self.view.backgroundColor = [UIColor blackColor];
    [self.navigationController.navigationBar setHidden:YES];
//    }
    
    [self addCustomView];
    [self LoadSetingPage];
    
    self.viewDeckController.delegate = self;
    
    self.clearDeckView = [[UIView  alloc] init];
    
    UITapGestureRecognizer*tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(closeRightChouTi)];
    [clearDeckView addGestureRecognizer:tap];
}
#pragma --重写状态栏方法
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleDefault;
}
- (BOOL)prefersStatusBarHidden
{
    return NO;
}
- (void)addCustomView
{
    CGFloat y = 0;
    if (IOS7) {
        //y = SIMULATOR?0:20;
        y = 20;
    }
    
    _customView = [[UIView alloc] initWithFrame:CGRectMake(0,y,CGRectGetWidth(self.view.frame), 70)];
    _customView.userInteractionEnabled = YES;
    _customView.backgroundColor = [UIColor grayColor];
    [self.view addSubview:_customView];
    
    UILabel *acc = [[UILabel alloc] initWithFrame:CGRectMake(20,10,CGRectGetWidth(_customView.frame)-160,50)];
    acc.text = [[AppDelegate getApp] userAccout].UserName;
    acc.textColor = [UIColor whiteColor];
    acc.backgroundColor = [UIColor clearColor];
    acc.font = [UIFont fontWithName:@"TrebuchetMS-Bold" size:23];
    acc.adjustsFontSizeToFitWidth = YES;
    [_customView addSubview:acc];
    
    UIButton *exit = [[UIButton alloc] init];
    exit.frame = CGRectMake(CGRectGetWidth(acc.frame)+30, acc.frame.origin.y,70, acc.height);
    [exit setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [exit setTitle:@"退出" forState:UIControlStateNormal];
    [exit setAllStateBg:@"common_card_background.png"];
    [exit addTarget:self action:@selector(exitApplication) forControlEvents:UIControlEventTouchUpInside];
    [_customView addSubview:exit];

    UILongPressGestureRecognizer *longPress =[[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPressExit)];
    longPress.minimumPressDuration = 1.0; //定义按的时间
    [exit addGestureRecognizer:longPress];


}

- (void)exitApplication {
    
    AppDelegate *app = [AppDelegate getApp];
    [app.userAccout LogoutAccount];
    [self.viewDeckController toggleLeftViewAnimated:YES];
}


-(void)longPressExit
{
    AppDelegate *app = [AppDelegate getApp];
    UIWindow *window = app.window;
    [UIView animateWithDuration:1.0f animations:^{
        window.alpha = 0;
        window.frame = CGRectMake(0, window.bounds.size.width, 0, 0);
    } completion:^(BOOL finished) {
        MyLog(@"退出程序");
        exit(0);
    }];
}



-(void)closeRightChouTi
{
    [self.viewDeckController toggleLeftViewAnimated:YES];
}


- (void)viewDeckController:(IIViewDeckController*)viewDeckController didOpenViewSide:(IIViewDeckSide)viewDeckSide animated:(BOOL)animated
{
    CGRect framee=viewDeckController.slidingController.view.frame;
    
    clearDeckView.frame=CGRectMake(framee.origin.x, framee.origin.y, framee.size.width, framee.size.height);
    
    AppDelegate* app = [AppDelegate getApp];
    if(viewDeckController.centerController!=app.HomeNavigation)
    {
        viewDeckController.centerController=app.HomeNavigation;
        viewDeckController.leftController=app.MenuNavigation;
    }
    
    [viewDeckController.slidingController.view endEditing:YES];
    
    dispatch_async(dispatch_get_main_queue(),
^{
    [viewDeckController.slidingController.view addSubview:clearDeckView];
//    [self drawIndicator:(UINavigationController*)viewDeckController.slidingController bFlag:YES];
    

});

    
}

//make item rotate.



- (void)viewDeckController:(IIViewDeckController*)viewDeckController didCloseViewSide:(IIViewDeckSide)viewDeckSide animated:(BOOL)animated
{
    dispatch_async(dispatch_get_main_queue(),
  ^{
      [clearDeckView removeFromSuperview];

      [self BackToHomeController];
    });
}


- (void)BackToHomeController
{
    AppDelegate* app = [AppDelegate getApp];
    if(!app.isLogining)
    {
        UINavigationController* nav = app.HomeNavigation;
        NSArray* array = nav.viewControllers;
        HomeViewController* HVtr = (HomeViewController*)(UIViewController*)array[0];
        [HVtr viewDidAppear:NO];
        [app setMenuNavigation:nil];
    }
}

- (void)exitToHome
{
    AppDelegate *app = [AppDelegate getApp];
    [app.userAccout LogoutAccount];
    [self.viewDeckController toggleLeftViewAnimated:NO];
}


//
- (void)viewDeckController:(IIViewDeckController*)viewDeckController willOpenViewSide:(IIViewDeckSide)viewDeckSide animated:(BOOL)animated
{
    NSLog(@"test will open");
    //    dispatch_async(dispatch_get_main_queue(),
    // ^{
    //     AppDelegate* app = [AppDelegate getApp];
    //     UINavigationController* Nav = (UINavigationController*)viewDeckController.slidingController;
    //     if(app.HomeNavigation==Nav)
    //     {
    //       [self drawAnimation:Nav type:kCounterClockWise];
    //     }
    //   });

}



- (void)viewDeckController:(IIViewDeckController*)viewDeckController willCloseViewSide:(IIViewDeckSide)viewDeckSide animated:(BOOL)animated
{
    NSLog(@"test will close");
//    dispatch_async(dispatch_get_main_queue(),
//  ^{
//       AppDelegate* app = [AppDelegate getApp];
//       UINavigationController* Nav = (UINavigationController*)viewDeckController.slidingController;
//       if(app.HomeNavigation==Nav)
//       {
//          [self drawAnimation:Nav type:kClockWise];
//       }
//    });
}







- (void)LoadSetingPage
{
    self.nameArray = [NSArray arrayWithObjects:@"我的帐户",@"积分查询",@"基卡设置",@"套餐选择",@"应用管理",@"辅助功能",@"帮助",@"检查更新",@"关于",nil];
    
    self.dictionay = [[NSDictionary alloc] initWithObjectsAndKeys:
                      New(Account),@"我的帐户",
                      New(Point),@"积分查询",
                      New(BasicSetting),@"基卡设置",
                      New(MenuChoose),@"套餐选择",
                      New(AppManagement),@"应用管理",
                      New(Assist),@"辅助功能",
                      New(HelpView),@"帮助",
                      New(ClientVersion),newVersion,
                      New(About),@"关于",
                      nil];
    
    MenuView*  menu  = [[MenuView alloc]
                        initWithFrame:CGRectMake(0,CGRectGetMaxY(_customView.frame), ScreenWidth,ScreenHeight)  dic:dictionay array:nameArray bg:kGlobalBg selectedBlock:^(int nIndex)
                        {
                            NSString* keyName = nameArray[nIndex];
                            if (![keyName isEqualToString:newVersion]) {
                                
                                BaseNavigationController* nav = (BaseNavigationController*)dictionay[keyName];
                                
                                self.viewDeckController.centerController=nav;
                                
                                [self.viewDeckController
                                 closeLeftViewAnimated:YES completion:^(IIViewDeckController *controller, BOOL success) {
                                     
                                 }];
                            }else{
                                [self getClientVersion];
                            }
                        }];
        
    [self.view addSubview:menu];
}


@end
