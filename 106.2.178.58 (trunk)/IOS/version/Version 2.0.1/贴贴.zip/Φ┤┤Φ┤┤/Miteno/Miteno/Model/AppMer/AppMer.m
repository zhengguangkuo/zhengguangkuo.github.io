//
//  AppMer.m
//  Miteno
//
//  Created by HWG on 14-3-24.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "AppMer.h"

@implementation AppMer
- (id)initWithDict:(NSDictionary *)dict
{
    if (self = [super initWithDict:dict]) {
        self.appID = dict[@"app_id"];
        self.merchID = dict[@"merch_id"];
    }
    return self;
}
@end
