//
//  UIImageView+DispatchLoad.h
//  M-Pay
//
//  Created by guorong on 14-2-24.
//  Copyright miteno 2014年. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UIImageView (DispatchLoad)
- (void) setImageFromUrl:(NSString*)urlString;

- (void) setImageFromUrl:(NSString*)urlString withHud:(BOOL)hudFlag;

//- (void) setImageFromUrl:(NSString*)urlString withHud:(BOOL)hudFlag animate:(BOOL)bFlag;

- (void) setImageFromUrl:(NSString*)urlString
              completion:(void (^)(void))completion;

- (void) setImageFromUrl:(NSString*)urlString
              completion:(void (^)(void))completion animate:(BOOL)bFlag;

- (void) setImageFromData:(NSData*)cachedata  targetPath:(NSString*)pathName completion:(void (^)(void))block;

- (void) setImageFromData:(NSData *)cachedata targetPath:(NSString *)pathName;

- (void) setImageFromCache:(NSString*)pathName;

@end