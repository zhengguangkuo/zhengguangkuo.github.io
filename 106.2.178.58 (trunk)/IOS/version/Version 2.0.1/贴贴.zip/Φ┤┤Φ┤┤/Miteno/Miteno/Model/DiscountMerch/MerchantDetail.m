//
//  MerchantDetail.m
//  Miteno
//
//  Created by wg on 14-4-2.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "MerchantDetail.h"
#import "Contact.h"
@implementation MerchantDetail
- (id)initWithDict:(NSDictionary *)dict
{
    if (self = [super initWithDict:dict]) {
        self.name = dict[@"name"];
        self.addr = dict[@"addr"];
        self.positiveAppraiseCount = dict[@"positiveAppraiseCount"];
        self.disDescription = dict[@"disDescription"];
        self.ypos = dict[@"ypos"];
        self.xpos = dict[@"xpos"];
        self.busline = dict[@"busline"];
        self.intro = dict[@"intro"];
        NSDictionary *contacts = dict[@"contact"];
        if (contacts) {
            self.contact = [[Contact alloc] initWithDict:contacts];
        }
    }
    return self;
}
@end
