//
//  BasicSettingViewController.m
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "BasicSettingViewController.h"
#import "IIViewDeckController.h"
#import "HttpService.h"
#import "NSString(Additions).h"
#import "NSDictionary(JSON).h"
#import "BasicCard.h"
#import "CardCell.h"
#import "UIButton(addtion).h"
#import "AppDelegate.h"
#import "MenuChooseViewController.h"
#import "AppDelegate.h"


#define  kConfirmBtn    110

#define  kCancelBtn     111


@interface BasicSettingViewController () <UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) NSMutableArray* cardArray;

@property (nonatomic, strong) UITableView* cardTableView;

@end



@implementation BasicSettingViewController

@synthesize cardArray = _cardArray;
@synthesize cardTableView = _cardTableView;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"基卡设置";
        self.view.backgroundColor = [UIColor whiteColor];
        //[self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage scaleToSize:[UIImage imageNamed:@"main_bg"] size:CGSizeMake(320, 640)]]];
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self NavigationViewBackBtn];
    self.cardArray = [[NSMutableArray alloc] init];
    self.cardTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, ZeroY, kScreenBounds.size.width, kScreenBounds.size.height - 0.24*kScreenBounds.size.height) style:UITableViewStylePlain];
    [_cardTableView setDelegate:self];
    [_cardTableView setDataSource:self];
    [_cardTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [_cardTableView setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:_cardTableView];
    
    [self LoadBottomBtn];
}




- (void)LoadBottomBtn
{
    
    UIImage* LightImage = [UIImage imageNamed:@"btn_bg_light"];
    UIButton* okBtn = [UIButton ButtonWithParms:[UIColor whiteColor] title:@"下一步" bgnormal:LightImage imgHighlight:nil target:self action:@selector(NextStep)];
    
    [okBtn setTag:kConfirmBtn];
    [okBtn setFrame:CGRectMake(70, _cardTableView.frame.origin.y + _cardTableView.frame.size.height + 15, 80, 40)];
    [self.view addSubview:okBtn];
    [okBtn setHidden:TRUE];
    
    
    UIButton* noBtn = [UIButton ButtonWithParms:[UIColor whiteColor] title:@"返回" bgnormal:LightImage imgHighlight:nil target:self action:@selector(PreStep)];
    
    [noBtn setTag:kCancelBtn];
    [noBtn setFrame:CGRectMake(170, _cardTableView.frame.origin.y + _cardTableView.frame.size.height + 15, 80, 40)];
    [self.view addSubview:noBtn];
    [noBtn setHidden:TRUE];
}


- (void)ShowBottomButtonsOrNot
{
    UIButton* okBtn = (UIButton*)[self.view viewWithTag:kConfirmBtn];
    UIButton* noBtn = (UIButton*)[self.view viewWithTag:kCancelBtn];
    
    AppDelegate* app = [AppDelegate getApp];
    if(app.userAccout.isFirstLogin)
  {
      [okBtn setHidden:FALSE];
      [noBtn setHidden:FALSE];
      [self NavigationHiddenBack];
  }
}


- (void)NextStep
{
    MenuChooseViewController*  menuVCtr = [[MenuChooseViewController alloc] init];
    [self.navigationController pushViewController:menuVCtr animated:YES];
    [menuVCtr ShowBottomButtonsOrNot];
}


- (void)PreStep
{
    AppDelegate* app = [AppDelegate getApp];
    [app.userAccout setIsFirstLogin:FALSE];

    [self.navigationController popToRootViewControllerAnimated:YES];
}


- (void)backToPrevious
{
    [self.viewDeckController toggleLeftViewAnimated:YES];
}



-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    AppDelegate* app = [AppDelegate getApp];
    if(IsEmptyString(app.userAccout.Mobile))
    [app  RequestForUserInfo:NULL];
    [self RequestList];
}


-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    [self.cardArray removeAllObjects];
    [self.cardTableView reloadData];
}



-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    return [self.cardArray count];
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 130;
}


-(UITableViewCell *)tableView:(UITableView *)tableView
		cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"CardCell";
    
    int row = [indexPath row];
    
    CardCell *cell = (CardCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    BasicCard*  tempobject = self.cardArray[row];
    
    if(cell==nil)
    {
        cell = [[CardCell alloc] initCustom];
    }
    [cell setBasicCard:tempobject];
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
}


-(void)RequestList
{
    NSString*  testURL =  [NSString stringWithFormat:@"%@%@",  WEB_SERVICE_ENV_VAR,Key_Basic_Card_Setting];
    NSLog(@"testURL = %@",testURL);
    
    [self.cardArray removeAllObjects];
    
    HttpService*  tempservice = [HttpService  HttpInitPostForm:testURL
                                                          body:nil
                                                       withHud:YES];
    [tempservice setDelegate:self];
    
    [tempservice  setDataHandler:^(NSString* data)
     {
         NSLog(@"data = %@",data);
         id result = [NSDictionary dictionaryWithString:data];
         if(![(NSNull*)result isKindOfClass:[NSNull class]])
         {
             if([result isKindOfClass:[NSArray class]]){
                 NSMutableArray* array = [[NSMutableArray alloc] initWithArray:result];
                 for(id object in array)
                 {
                     if([object isKindOfClass:[NSDictionary class]])
                     {
                         NSDictionary* dic = (NSDictionary*)object;
                         
                         BasicCard*  tempobject = [[BasicCard alloc] initWithDictionary:dic];
                         [self.cardArray addObject:tempobject];
                     }
                 }
             }
         }
         
         dispatch_async(dispatch_get_main_queue(),
                        ^{
                            [self.cardTableView reloadData];
                        });
         }
     ];
    
    [tempservice startOperation];
}



-(void)RequestLogin
{
    NSString* password1 =  @"123456{mt009}";
    
    NSString* password = [password1 md5];
    
    NSLog(@"password = %@",password);
    
    NSString*  testURL =  [NSString stringWithFormat:@"%@mpayFront/j_spring_security_check",  WEB_SERVICE_ENV_VAR];
    NSLog(@"testURL = %@",testURL);
    NSDictionary* PostDic = [[NSDictionary alloc] initWithObjectsAndKeys:
                             @"mt009",@"j_username",
                             password,@"j_password",
                             nil];
    
    HttpService*  tempservice = [HttpService  HttpInitPostForm:testURL
                                                          body:PostDic
                                                       withHud:NO];
    
    [tempservice  setDataHandler:^(NSString* data)
     {
         NSLog(@"登录成功!");
         NSLog(@"login str = %@",data);
         
         [self RequestList];
     }
     ];
    [tempservice setDelegate:self];
    
    [tempservice startOperation];
    
    
}


-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:YES];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

