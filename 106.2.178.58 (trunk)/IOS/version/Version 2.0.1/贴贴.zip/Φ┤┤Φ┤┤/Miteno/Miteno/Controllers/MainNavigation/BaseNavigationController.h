//
//  BaseNavigationController.h
//  BaseNav
//
//  Created by HWG on 14-1-17.
//  Copyright (c) 2014年 miteno. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BaseNavigationController : UINavigationController

@end
