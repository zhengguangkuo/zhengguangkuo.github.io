//
//  HomeViewController.h
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "RootViewController.h"
#import "UIView(Animation).h"
@interface HomeViewController : RootViewController
@property (nonatomic, strong) NSArray   *  cityData;


- (void)drawIndicator:(BOOL)bFlag;

//- (void)drawAnimator:(ClockWiseType)type;

@end
