//
//  AppManagementViewController.m
//  Miteno
//
//  Created by HWG on 14-3-4.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//MEITAINUOtest123

#import "AppManagementViewController.h"
#import "Dock.h"
#import "UserAppList.h"
#import "AllAppListCell.h"
#import "UserApp.h"
#import "UserAppId.h"
#import "UsermapyApp.h"
#import "AppDelegate.h"
#define kTag 10
#define kAllApplistURL [NSString stringWithFormat:@"%@mpayFront/getAllMpayApps",kBaseURL]       //所有应用列表
#define kUserBindsAppURL [NSString stringWithFormat:@"%@mpayFront/getMpayAppsByUser",kBaseURL]  //用户已绑定应用
#define kBindAppURL  [NSString stringWithFormat:@"%@mpayFront/bindMpayApp",kBaseURL]            //绑定应用
@interface AppManagementViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    Dock            * _dock;                //bar
    UITableView     * _tableView;           //tableview
    NSMutableArray  * _allAppList;          //所有应用
    NSMutableArray  * _userBindingApps;     //用户绑定的应用
    NSMutableArray  * _tempAddapp;          //选定保存临时的数据(绑定)
    NSMutableArray  * _unTempAddapp;        //选定保存临时的数据(解绑)
    //    UIButton        * _current;             //当前按钮
}
@end

@implementation AppManagementViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        //初始化数据
        _allAppList = [NSMutableArray array];
        _userBindingApps = [NSMutableArray array];
        _unTempAddapp = [NSMutableArray array];
        _tempAddapp = [NSMutableArray array];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //设置导航
	[self setNavTheme:0];
    
    //添加Dock
    [self addDock];
    
    //添加tableView、默认选中第一个
    [self addTableViews:0];
    
    //默认加载用户已绑定数据
    [self loadUserBindApp];
}
#pragma mark -导航主题
- (void)setNavTheme:(int)index
{
    self.title = @"应用管理";
    
    //导航左边一个按钮
    UIBarButtonItem *item =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                            andTitle:nil
                                            andImage:[UIImage imageNamed:@"gb_button"]
                                           addTarget:self
                                           addAction:@selector(back)];
    
    UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];
    
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];
    
    //[UIBarButtonItem barButtonItemWithIcon:@"top_bt_bg.png" target:self action:@selector(back)];
    if (index==0) {
        self.navigationItem.rightBarButtonItem =
        [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                                andTitle:@"解绑"
                                                andImage:nil
                                               addTarget:self
                                               addAction:@selector(unBindApp)];
        //[UIBarButtonItem barButtonItemWithBg:@"nav_image_bg.png" title:@"解绑" size:CGSizeMake(70, 35) target:self action:@selector(unBindApp)];
    }else{
        self.navigationItem.rightBarButtonItem =
        [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                                andTitle:@"绑定"
                                                andImage:nil
                                               addTarget:self
                                               addAction:@selector(bindApp)];
        //[UIBarButtonItem barButtonItemWithBg:@"nav_image_bg.png" title:@"绑定" size:CGSizeMake(70, 35) target:self action:@selector(bindApp)];
    }
}
- (void)back{
    [self.viewDeckController toggleLeftViewAnimated:YES];
}
#pragma mark -添加dock
- (void)addDock
{
    CGFloat y = 0;
    if (IOS7) {
        y = SIMULATOR==0?0:64;
    }
    _dock = [[Dock alloc] initWithFrame:CGRectMake(0,y, ScreenWidth, 40)];
    NSString *nor = @"nav_image_bg.png";
    NSString *select = @"business_bg";
//    [_dock addDockBtnWithBgIcon:nor selectIcon:select title:@"已选应用"];
//    [_dock addDockBtnWithBgIcon:nor selectIcon:select title:@"可选应用"];
    [self.view addSubview:_dock];
    
    __unsafe_unretained AppManagementViewController *appMge = self;
    //监听item点击事件
    _dock.itemClickBlock = ^(int index){
        MyLog(@"点击了%d",index);
        [appMge addTableViews:index];
        //加载对应的表格
        index == 0?[appMge loadUserBindApp]:[appMge loadAllApplist];
        [appMge setNavTheme:index];
        //        [appMge performSelector:@selector(itemState:) withObject:@(index)];
    };
}
#pragma mark -解绑
- (void)unBindApp
{
    //判断选定的数组是否为空
    if (_unTempAddapp.count==0) {
        [SystemDialog alert:@"请先选定要解绑的应用"];
    }else{
        //解绑的数组（保存一个对象）
        UserApp *app = [_unTempAddapp lastObject];
        
        NSDictionary *dict = @{@"app_id": app.ID.appId,
                               @"action": @"unBind"};
        HttpService *tempservice = [HttpService HttpInitPostForm:kBindAppURL body:dict withHud:YES];
        [tempservice setDataHandler:^(NSString *data) {
            NSDictionary *dict = [data objectFromJSONString];
            if ([[dict objectForKey:@"respcode"] intValue] == 0) {
                [SystemDialog alert:[dict objectForKey:@"message"]];
                [self loadUserBindApp];
            }
            if ([[dict objectForKey:@"respcode"] intValue] != 0) {
                [SystemDialog alert:[dict objectForKey:@"message"]];
            }
        }];
        [tempservice startOperation];
        [self getError:tempservice];
        [_unTempAddapp removeAllObjects];
    }
}
#pragma mark -绑定
- (void)bindApp{
    
    //判断选定的数组是否为空
    if (_tempAddapp.count==0) {
        [SystemDialog alert:@"请先选定要绑定的应用"];
    }else{
        //绑定数组
        UserAppList *app = [_tempAddapp lastObject];
        NSDictionary *dict = @{@"app_id": app.ID,
                               @"action": @"bind"};
        HttpService *tempservice = [HttpService HttpInitPostForm:kBindAppURL body:dict withHud:YES];
        [tempservice setDataHandler:^(NSString *data) {
            NSDictionary *dict = [data objectFromJSONString];
            if ([[dict objectForKey:@"respcode"] intValue] == 0) {
                [SystemDialog alert:[dict objectForKey:@"message"]];
                [self loadAllApplist];
            }
            if ([[dict objectForKey:@"respcode"] intValue] != 0) {
                [SystemDialog alert:[dict objectForKey:@"message"]];
            }
        }];
        [tempservice startOperation];
        [self getError:tempservice];
        [_tempAddapp removeAllObjects];
    }
}
#pragma mark -添加tableViews
- (void)addTableViews:(int)index
{
    CGFloat y = _dock.height + _dock.origin.y;
    CGFloat h = ScreenHeight - _dock.origin.y;
    _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, y, ScreenWidth, h) style:UITableViewStylePlain];
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _tableView.tag = index;
    [self.view addSubview:_tableView];
    
}
#pragma mark -用户已绑定应用
- (void)loadUserBindApp
{
    NSString *page = @"1";
    NSString *appType = @"3";// 支付应用为0,非支付为3;
    NSDictionary *dict = @{@"page"      : page,
                           @"appType"   : appType,
                           @"city"      :[AppDelegate getApp].userAccout.City_Code
                           };
    HttpService *tempservice = [HttpService HttpInitPostForm:kUserBindsAppURL body:dict withHud:YES];
    [tempservice setDataHandler:^(NSString *data) {
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *results = dicts[@"rows"];
        NSMutableArray  *tempData = [NSMutableArray array];
        for (NSDictionary *dict in results) {
            UserApp *mpayApp = [[UserApp alloc] initWithDict:dict];
            
            [tempData addObject:mpayApp];
        }
        _userBindingApps = tempData;
        
        [_tableView reloadData];
    }];
    [tempservice startOperation];
    [self getError:tempservice];
    
}
#pragma mark -加载所有应用列表数据
- (void)loadAllApplist
{
    AppDelegate* app = [AppDelegate getApp];
    NSString *cityName = [app getCityCode];
    NSString *appType = @"3";   // 支付应用为0,非支付为3;
    NSDictionary *dict = @{@"page": @"1",
                           @"rows":@"10",
                           @"appType":appType,
                           @"city":cityName,
                           };
    
    HttpService *tempservice = [HttpService HttpInitPostForm:kAllApplistURL body:dict withHud:YES];
    [tempservice setDataHandler:^(NSString *data) {
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *results = dicts[@"rows"];
        NSMutableArray  *tempData = [NSMutableArray array];
        for (NSDictionary *dict in results) {
            UserAppList *userAppList = [[UserAppList alloc] initWithDict:dict];\
            //判断是否已经绑定
            if ([userAppList.bind_flag isEqualToString:@"0"]) {
                
                [tempData addObject:userAppList];
            }
        }
        _allAppList = tempData;
        
        [_tableView reloadData];
    }];
    [tempservice startOperation];
    [self getError:tempservice];
}
- (void)getError:(HttpService *)tempservice
{
    [tempservice setErrorHandler:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [SystemDialog alert:kConnectFailure];
        });
    }];
}

#pragma mark -tableViewdelegate And datasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (_tableView.tag == 0) {
        return _userBindingApps.count;
    }else{
        return _allAppList.count;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static  NSString *ID = @"bindAppList";
    AllAppListCell *cell = (AllAppListCell *)[tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"AllAppListCell" owner:self options:nil] lastObject];
    }
    [cell.binding addTarget:self action:@selector(clickBtn:event: ) forControlEvents:UIControlEventTouchUpInside];
    if (_tableView.tag == 0) {
        UserApp *userApp = _userBindingApps[indexPath.row];
        cell.appName.text = userApp.mpayApp.app_name;

        return cell;
    }else{
        //所用应用
        UserAppList *userApp = _allAppList[indexPath.row];
        cell.appName.text = userApp.app_name;
        return cell;
    }
}
- (void)clickBtn:(UIButton *)btn event:(id)event

{
    btn.selected = !btn.isSelected;
    NSSet *touches = [event allTouches];
    UITouch *touch = [touches anyObject];
    CGPoint currentTouchPosition = [touch locationInView:_tableView];
    NSIndexPath *indexPath = [_tableView indexPathForRowAtPoint:currentTouchPosition];
    
    if (btn.selected== YES){
        if (_tableView.tag==0) {
            if (_userBindingApps.count<=0)  return;
            UserAppList *userApp = _userBindingApps[indexPath.row];
            //解绑的临时数组
            [_unTempAddapp addObject:userApp];
            
        }else{
            if (_allAppList.count<=0) return;
            UserApp *app = _allAppList[indexPath.row];
            //添加到临时数组
                [_tempAddapp addObject:app];
        }
        
    }else{
        [_tempAddapp removeAllObjects];
        [_unTempAddapp removeAllObjects];
    }

    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return  kAllAppHeight;
}

@end


//-------------------
/*
 #pragma mark -添加cell后面的checkbox
 - (void)addSelectBtn:(UITableViewCell *)cell{
 //添加复选框
 _share = [[UIButton alloc] initWithFrame:CGRectMake(280, 9.5, 25, 25)];
 UIImage *shareNormal = [UIImage imageNamed:@"checkbox_normal.png"];
 [_share setBackgroundImage:shareNormal forState:UIControlStateNormal];
 UIImage *shareSelected = [UIImage imageNamed:@"checkbox_pressed.png"];
 [_share setBackgroundImage:shareSelected forState:UIControlStateSelected];
 [_share addTarget:self action:@selector(btnClicked:event:) forControlEvents:UIControlEventTouchUpInside];
 _share.adjustsImageWhenHighlighted = NO;
 [cell.contentView addSubview:_share];
 }
 #pragma mark 选中状态改变
 - (void)share:(UIButton *)btn
 {
 _currentBtn = btn;
 
 //按钮状态改变
 btn.selected = !btn.isSelected;
 
 }
 - (void)btnClicked:(id)sender event:(id)event
 {
 NSSet *touches = [event allTouches];
 UITouch *touch = [touches anyObject];
 UIButton *btn = (UIButton *)sender;
 btn.selected = !btn.isSelected;
 CGPoint currentTouchPosition = [touch locationInView:_tableView];
 NSIndexPath *indexPath = [_tableView indexPathForRowAtPoint:currentTouchPosition];
 if(indexPath != nil)
 {
 [self tableView:_tableView accessoryButtonTappedForRowWithIndexPath:indexPath];
 }
 }
 //#pragma mark -accessory delegate
 - (void)tableView:(UITableView *)tableView accessoryButtonTappedForRowWithIndexPath:(NSIndexPath *)indexPath
 {
 //获取点击的行数
 NSLog(@"打印%d",indexPath.row);
 
 NSString *text = _allDatas[indexPath.row];
 //判断数据 添加删除
 if ([_allIndexPaths containsObject:indexPath]) {
 
 [self.selectedData removeObject:text];
 [self.selectedRow removeObject:indexPath];
 
 //            NSLog(@"要删除的数据 ：%@",text);
 }else{
 [self.selectedData addObject:text];
 [self.selectedRow addObject:indexPath];
 //            NSLog(@"要添加的数据 ：%@",text);
 }
 
 
 }
 */
