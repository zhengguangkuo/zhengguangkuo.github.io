//
//  AccountViewController.h
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "RootViewController.h"

@interface UpdateEmailViewController : RootViewController<UITableViewDataSource,UITableViewDelegate,UITextFieldDelegate>


@end
