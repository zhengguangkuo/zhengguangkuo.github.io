//
//  DisCountMerch.m
//  Miteno
//
//  Created by HWG on 14-3-12.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "DisCountMerch.h"
#import "AppMer.h"
@implementation DisCountMerch
- (id)initWithDict:(NSDictionary *)dict
{
    if (self = [super initWithDict:dict]) {
        //商家信息
        self.actName = dict[@"act_name"];
        self.discount = dict[@"discount"];
        self.picPath = dict[@"pic_path"];
        NSDictionary *merchants = dict[@"merchant"];
            self.otherMerchId = dict[@"otherMerchId"];
        if (merchants) {
            self.merchant = [[Merchant alloc] initWithDict:merchants];
        }
        NSDictionary *appMers = dict[@"id"];
        if (appMers) {
            self.appMer = [[AppMer alloc] initWithDict:appMers];
        }
    }
    return self;
}
@end
