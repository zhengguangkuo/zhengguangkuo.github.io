//
//  NewFeatureViewController.h
//  Miteno
//
//  Created by wg on 14-3-28.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "RootViewController.h"

@interface NewFeatureViewController : RootViewController<UIScrollViewDelegate>
@property (nonatomic, copy) void (^startBlock)(BOOL share);
@end
