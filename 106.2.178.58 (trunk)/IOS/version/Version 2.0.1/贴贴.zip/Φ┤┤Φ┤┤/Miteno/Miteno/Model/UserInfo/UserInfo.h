//
//  BasicCard.h
//  M-Pay
//
//  Created by guorong on 14-2-24.
//  Copyright miteno 2014年. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Base.h"

@interface UserInfo : Base

@property  (nonatomic, copy)  NSString* PassWord;

@property  (nonatomic, copy)  NSString* UserName;

@property  (nonatomic, copy)  NSString* Mobile;

@property  (nonatomic, copy)  NSString* Email;

@property  (nonatomic, copy)  NSString* City_Code;

@property  (nonatomic, copy)  NSString* valideMobile;

@property  (nonatomic, assign) BOOL isFirstLogin;


-(void)LogoutAccount;

-(void)LoginAccount:(UserInfo*)account;

-(BOOL)AutoLoginAccount;

@end
