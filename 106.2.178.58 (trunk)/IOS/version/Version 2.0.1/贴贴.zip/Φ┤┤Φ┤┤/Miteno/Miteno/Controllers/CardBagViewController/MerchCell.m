//
//  ImageTableViewCell.m
//  NSOperationTest
//
//  Created by jhwang on 11-10-30.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//
#import "MerchCell.h"
#import "UIImageView+DispatchLoad.h"
#import "Merch.h"
#import "UIView(category).h"


@implementation MerchCell

@synthesize  LeftImage;

@synthesize  titleLabel;

@synthesize  dateLabel;

@synthesize  storeNameLabel;

@synthesize  TimesLabel;

@synthesize  distanceLabel;

@synthesize  FlagImage;

@synthesize  mMerch;

- (id)initCustom
{
    self = [super init];
    if(self)
    {
        self = [[[NSBundle mainBundle] loadNibNamed:@"MerchCell" owner:self options:nil] lastObject];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self setBackgroundColor:[UIColor clearColor]];
        [self.contentView setBackgroundColor:[UIColor clearColor]];
        [self ViewWithBorder:[UIColor clearColor]];
        
        self.LeftImage.layer.borderWidth = 2.0;
        self.LeftImage.layer.borderColor = [[UIColor whiteColor] CGColor];
        
        self.LeftImage.layer.shadowOffset = CGSizeMake(2.0f, 2.0f);
        self.LeftImage.layer.shadowOpacity = 0.5;
        self.LeftImage.layer.shadowRadius = 2.0;
        self.LeftImage.layer.shadowColor = [[UIColor blackColor] CGColor];
    }
    return self;
}


-(void)setMerchObject:(Merch*)object
{
    [self CleanData];
    self.mMerch = object;
    [self.LeftImage setImageFromUrl:mMerch.pic_path withHud:NO];
    [self.FlagImage setImage:nil];
    [self.titleLabel setText:mMerch.act_name];
    [self.dateLabel setText:[NSString stringWithFormat:@"%@-%@",mMerch.start_date,mMerch.end_date]];
    [self.storeNameLabel setText:mMerch.merch_name];
    [self.TimesLabel setText:[NSString stringWithFormat:@"已经发放%d张",  mMerch.issued_cnt]];
    [self.distanceLabel setText:mMerch.distance];
}

-(void)CleanData
{
    [self.LeftImage setImage:[UIImage imageNamed:@"load.png"]];
    [self.FlagImage setImage:nil];
    [self.titleLabel setText:@""];
    [self.dateLabel setText:@""];
    [self.storeNameLabel setText:@""];
    [self.TimesLabel setText:@""];
    [self.distanceLabel setText:@""];
}

@end
