//
//  UIBarButtonItem+Create.m
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "UIBarButtonItem+Create.h"

@implementation UIBarButtonItem (Create)
//+ (UIBarButtonItem *)barButtonItemWithIcon:(NSString *)icon target:(id)target action:(SEL)action
//{
//    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
//    // 设置所有状态下的背景图片
//    CGSize btnSize = [btn setAllStateBg:icon];
//    [btn setImage:[UIImage imageNamed:@"gb_button"] forState:UIControlStateNormal];
//    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
//    btn.bounds = (CGRect){CGPointZero, btnSize};
////    btn.showsTouchWhenHighlighted = YES;
//    return [[UIBarButtonItem alloc] initWithCustomView:btn];
//}
//
//
//+ (UIBarButtonItem *)barButtonItemWithImage:(UIImage *)image target:(id)target action:(SEL)action
//{
//    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
//    // 设置所有状态下的背景图片
//    [btn setBackgroundImage:image forState:UIControlStateNormal];
//    [btn setImage:[UIImage imageNamed:@"gb_button"] forState:UIControlStateNormal];
//    CGSize btnSize = image.size;
//    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
//    btn.bounds = (CGRect){CGPointZero, btnSize};
//    //    btn.showsTouchWhenHighlighted = YES;
//    return [[UIBarButtonItem alloc] initWithCustomView:btn];
//    
//}
//
//+ (UIBarButtonItem *)barButtonItemWithBg:(NSString *)bg title:(NSString *)title size:(CGSize)size target:(id)target action:(SEL)action
//{
//    // 创建按钮
//    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
//    // 按钮文字
//    [btn setTitle:title forState:UIControlStateNormal];
//    btn.titleLabel.font = [UIFont systemFontOfSize:15];
//    // 按钮背景
//    [btn setAllStateBg:bg];
//    // 按钮边框
//    btn.bounds= (CGRect){CGPointZero, size};
//    // 监听器
////    btn.showsTouchWhenHighlighted = YES;
//    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
//    return [[UIBarButtonItem alloc] initWithCustomView:btn];
//}

+ (UIBarButtonItem *)barButtonItemWithBackgroudImage:(UIImage *)bgImage
                                            andTitle:(NSString *)title
                                            andImage:(UIImage *)img
                                           addTarget:(id)target
                                           addAction:(SEL)action
{
    UIButton *btn = [UIButton backButtonWithBackgroudImage:bgImage andTitle:title andImage:img addTarget:target addAction:action];
//    [btn setImageEdgeInsets:UIEdgeInsetsMake(0, -24, 0, 0)];

    return [[UIBarButtonItem alloc] initWithCustomView:btn];
}

+ (UIBarButtonItem *)barButtonItemWithNegativeSpacer
{
    UIBarButtonItem *negativeSpacer = [[UIBarButtonItem alloc]
                                       initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace
                                       target:nil action:nil];
    if (IOS7) {
        negativeSpacer.width = -6;
    } else {
        negativeSpacer.width = 0;
    }
    return negativeSpacer;
}
@end
