//
//  DiscountViewViewController.h
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "RootViewController.h"
#import <CoreLocation/CoreLocation.h>
#import "MapsViewController.h"

@class RegionBar;
@interface DiscountViewViewController : RootViewController<CLLocationManagerDelegate,MapsViewControllerDelegate>
@end
