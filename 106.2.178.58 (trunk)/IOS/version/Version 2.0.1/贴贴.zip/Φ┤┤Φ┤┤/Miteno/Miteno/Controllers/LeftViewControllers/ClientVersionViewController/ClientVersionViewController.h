//
//  ClientVersionViewController.h
//  Miteno
//
//  Created by HWG on 14-3-3.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

//#import "RootViewController.h"
#import <UIKit/UIKit.h>
@interface ClientVersionViewController : UITableViewController

@end
