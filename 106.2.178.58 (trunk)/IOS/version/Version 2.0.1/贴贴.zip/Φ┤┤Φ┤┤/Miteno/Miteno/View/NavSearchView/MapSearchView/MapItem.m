//
//  MapItem.m
//  Miteno
//
//  Created by wg on 14-3-31.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "MapItem.h"
#define kImageRatio 0.6
@implementation MapItem

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // 设置文字属性
        [self setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        self.titleLabel.textAlignment = NSTextAlignmentCenter; // 文字居中
        self.titleLabel.font = [UIFont systemFontOfSize:16];
        
        // 设置图片属性
        self.imageView.contentMode = UIViewContentModeScaleAspectFit;
        self.adjustsImageWhenHighlighted = NO;
        
        // 设置选中时的背景
        [self setBackgroundImage:[UIImage imageNamed:@"tabbar_slider.png"] forState:UIControlStateSelected];
    }
    return self;
}

#pragma mark 重写父类的方法（覆盖父类在高亮时所作的行为）
- (void)setHighlighted:(BOOL)highlighted {}

#pragma mark 返回是按钮内部UILabel的边框
- (CGRect)titleRectForContentRect:(CGRect)contentRect
{
    CGFloat titleX = contentRect.size.width * kImageRatio-45;
    CGFloat titleW = contentRect.size.width - titleX;
    return CGRectMake(titleX, 0,titleW, contentRect.size.height);
}

#pragma mark 返回是按钮内部UIImageView的边框
- (CGRect)imageRectForContentRect:(CGRect)contentRect
{
    return CGRectMake(0, 0, contentRect.size.width * kImageRatio, contentRect.size.height);
}

@end
