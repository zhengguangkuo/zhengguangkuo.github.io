//
//  AttentionViewController.h
//  Miteno
//
//  Created by HWG on 14-3-21.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Act;
@interface AttentionViewController : UITableViewController
@property (nonatomic, strong)Act *act;

@end
