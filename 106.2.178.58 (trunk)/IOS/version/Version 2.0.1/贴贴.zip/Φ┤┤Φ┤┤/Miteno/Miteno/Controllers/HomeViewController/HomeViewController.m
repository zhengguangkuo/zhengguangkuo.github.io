//
//  HomeViewController.m
//  miteno
//
//  Created by HWG on 14-2-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//
#import "AttentionViewController.h"
#import "HomeViewController.h"
#import "LoginViewController.h"
#import "RegisterViewController.h"
#import "DiscountViewViewController.h"
#import "CardBagViewController.h"
#import "AppDelegate.h"
#import "AboutViewController.h"
#import "AreaCode.h"
#import "UIImage(addition).h"
#import "CityView.h"
#import "CityCell.h"


#define kTag 10
@interface HomeViewController ()<CityViewDelegate>
{
    CityView        *   _cityView;            //Modal
    UIButton        *   _currentBtn;
    UIButton        *   _carBtn;
    UIButton        *   _discountBtn;
    AppDelegate     *   _app;
    
    BOOL                _dragBflag;
    NSUserDefaults  *   _userDefaults;
}
@end

@implementation HomeViewController
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self NavigationHiddenBack];
    self.view.backgroundColor = [UIColor whiteColor];
    _userDefaults = [NSUserDefaults standardUserDefaults];
    _dragBflag = FALSE;

    //设置导航主题
    NSInteger *row = [[_userDefaults objectForKey:kSelectRow] integerValue];
    [self setNavTheme:row];
    
    //添加电子卡包
    [self addCards];
    
    //添加折扣优惠
    [self addDiscount];
    
    //添加登陆按钮
    [self addLoginBtn];
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    [self HiddenLoginBtnOrNot];
    [self setNavTheme:[[_userDefaults objectForKey:kSelectRow] integerValue]];
}

#pragma mark -设置是否隐藏登录按钮
- (void)HiddenLoginBtnOrNot
{
    _app = [AppDelegate getApp];
    UIButton* LoginBtn = (UIButton*)[self.view viewWithTag:kTag + 3];
    if(_app.isLogining)
    {
        [LoginBtn setHidden:YES];
    }
    else
    {
        [LoginBtn setHidden:NO];
    }
    [_app setLeftMenuDragState];
}
//显示左视图
- (void)showLeftView
{
    [_app setLeftMenuEnable:YES];
    [_app setLeftMenuDragged];
}
#pragma mark -初始化导航栏主题
- (void)setNavTheme:(int)index
{
    //1.标题
    self.title = @"主菜单";
    if (_app.isLogining) {
        UIBarButtonItem *item =
        [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                                andTitle:nil
                                                andImage:[UIImage imageNamed:@"bt_menu.png"]
                                               addTarget:self
                                               addAction:@selector(showLeftView)];
        
        UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];
        
        self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];

//        [UIBarButtonItem barButtonItemWithIcon:@"top_bt_bg.png" target:self action:@selector(showLeftView)];
//        UIImage* originImage = [UIImage imageNamed:@"top_bt_bg.png"];
//        UIImage* PI_Image = [UIImage RotationImage:originImage  Rotate:180.0];
//        self.navigationItem.leftBarButtonItem =
//        [UIBarButtonItem barButtonItemWithBackgroudImage:PI_Image
//                                                andTitle:nil
//                                                andImage:[UIImage imageNamed:@"gb_button.png"]
//                                               addTarget:self
//                                               addAction:@selector(showLeftView)];
//        
//        [UIBarButtonItem barButtonItemWithImage:PI_Image target:self action:@selector(showLeftView)];
    }else{
        UIBarButtonItem *item =
        [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                                andTitle:@"注册"
                                                andImage:nil
                                               addTarget:self
                                               addAction:@selector(userRegister)];
        UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];

        self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];
        //[UIBarButtonItem barButtonItemWithBg:@"nav_image_bg.png" title:@"注册" size:CGSizeMake(70, 35) target:self action:@selector(userRegister)];
    }
    
//    if (index==0) {
//        AreaCode *area = _cityData[index];
//        self.navigationItem.rightBarButtonItem = [UIBarButtonItem barButtonItemWithBg:@"nav_image_bg.png" title:area.area_name size:CGSizeMake(70, 35) target:self action:@selector(selectedCity)];
//    }else{
//        AreaCode *area = _cityData[index];
//        self.navigationItem.rightBarButtonItem = [UIBarButtonItem barButtonItemWithBg:@"nav_image_bg.png" title:area.area_name size:CGSizeMake(70, 35) target:self action:@selector(selectedCity)];
//    }
    AreaCode *area = _cityData[index];
    UIBarButtonItem *item =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_spinner_bg.png"]
                                            andTitle:[NSString stringWithFormat:@"  %@",area.area_name]
                                            andImage:nil
                                           addTarget:self
                                           addAction:@selector(selectedCity)];
    
    UIButton *button = (UIButton*)item.customView;
    [button setContentHorizontalAlignment:UIControlContentHorizontalAlignmentLeft];

    self.navigationItem.rightBarButtonItem = item;
    
}
- (void)viewWillAppear:(BOOL)animated
{
    NSArray *db = [[DbHelper sharedDbHelper] cityName];
    NSMutableArray *cityData = [NSMutableArray array];
    for (NSDictionary *dict in db) {
        AreaCode *areaCode = [[AreaCode alloc] initWithDict:dict];
        [cityData addObject:areaCode];
    }
    _cityData = cityData;
}


- (void)drawIndicator:(BOOL)bFlag
{
    UIView* tempview = self.navigationItem.leftBarButtonItem.customView;
    [tempview.layer removeAllAnimations];
    
    if(bFlag!=_dragBflag)
    {
//        UIImage* tempImage = nil;
        
        if(_dragBflag)
        {
//            tempImage = [UIImage RotationImage:[UIImage imageNamed:@"top_bt_bg.png"]  Rotate:180.0];
            _dragBflag = FALSE;
            NSLog(@"false");
        }
        else
        {
            
//            tempImage = [UIImage imageNamed:@"top_bt_bg.png"];
            _dragBflag = TRUE;
            NSLog(@"true");
            
            
        }
        
        self.navigationItem.leftBarButtonItem =
        [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                                andTitle:nil
                                                andImage:[UIImage imageNamed:@"bt_menu.png"]
                                               addTarget:self
                                               addAction:@selector(showLeftView)];
        
//        [UIBarButtonItem barButtonItemWithImage:tempImage target:self action:@selector(showLeftView)];
        NSLog(@"drawIndicator");
    }
    
}

//- (void)drawAnimator:(ClockWiseType)type
//{
//    [self.navigationItem.leftBarButtonItem.customView RotiaTion:type];
//}


#pragma mark -选中城市
- (void)selectedCity
{
    _cityView = [[CityView alloc]aboveCtroller:self cityData:_cityData];
    _cityView.delegate = self;
}
#pragma mark cityViewdelegate
- (void)clickResultrow:(int)row
{
    [self setNavTheme:row];
}
- (void)cityCode:(NSString *)cityCode
{
    MyLog(@"获取当前城市编码%@",cityCode);
    [_app.userAccout setCity_Code:cityCode];
}
- (void)cityName:(NSString *)cityName{}

#pragma mark -添加电子卡包
- (void)addCards
{
    // IOS7==YES?ScreenHeight*0.18-kPrinciple:ScreenHeight*0.06
    _carBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    CGFloat y = iPhone5==YES?30:20;
    _carBtn.frame = CGRectMake(ScreenWidth*0.1,SIMULATOR==0?0+y:IOS7Y+y, ScreenWidth*0.8, ScreenHeight*0.315);
    [_carBtn setBackgroundImage:[UIImage imageNamed:@"main_bag.png"] forState:UIControlStateNormal];
    _carBtn.adjustsImageWhenHighlighted = NO;
    _carBtn.tag = kTag + 1;
    //添加监听器
    [_carBtn addTarget:self action:@selector(CardBag) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_carBtn];
}
#pragma mark 进入电子卡包
- (void)CardBag
{
    MyLog(@"go卡包");
    AppDelegate* app = [AppDelegate getApp];
    if(app.isLogining)
    {
        CardBagViewController* cardVcr = [[CardBagViewController alloc] init];
        [self.navigationController pushViewController:cardVcr animated:YES];
    }
    else
    {
        AboutViewController* aboutVcr =[[AboutViewController alloc] init];
        [aboutVcr setBackStyle:UIPopControllerBack];
        [self.navigationController pushViewController:aboutVcr animated:YES];
    }
}

#pragma mark -添加折扣优惠
- (void)addDiscount
{
    MyLog(@"go折扣优惠");
    _discountBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    CGFloat y = iPhone5?30:20;
    _discountBtn.frame = CGRectMake(_carBtn.frame.origin.x, _carBtn.height+_carBtn.origin.y + y, ScreenWidth*0.7, ScreenHeight*0.3);
    
    _discountBtn.frame = CGRectMake(ScreenWidth*0.1, _carBtn.height+_carBtn.origin.y+y, ScreenWidth*0.8, ScreenHeight*0.315);
    
    [_discountBtn setBackgroundImage:[UIImage imageNamed:@"main_sale.png"] forState:UIControlStateNormal];
    [self.view addSubview:_discountBtn];
    _discountBtn.adjustsImageWhenHighlighted = NO;
    _discountBtn.tag = kTag + 2;
    //添加监听器
    [_discountBtn addTarget:self action:@selector(Coupons) forControlEvents:UIControlEventTouchUpInside];
}
#pragma mark 进入折扣优惠
- (void)Coupons
{
    DiscountViewViewController *discount = [[DiscountViewViewController alloc] init];
    [self.navigationController pushViewController:discount animated:YES];
    
}
#pragma mark -添加登录按钮
- (void)addLoginBtn
{
    UIButton *loginBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    CGFloat loginBtnWidth = 100;
    loginBtn.center = CGPointMake(self.view.frame.size.width*0.5,ScreenHeight*0.8);
    CGFloat y = iPhone5==YES?30:20;
    loginBtn.frame = CGRectMake(ScreenWidth/2-loginBtnWidth/2-10, _discountBtn.height+_discountBtn.origin.y+y-20, loginBtnWidth+20, 50);
    
    [loginBtn setBackgroundImage:[UIImage imageNamed:@"button_image_bg.png"] forState:UIControlStateNormal];
    [loginBtn setTitle:@"登录" forState:UIControlStateNormal];
    [loginBtn setTag:kTag + 3];
    
    [loginBtn addTarget:self action:@selector(login) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:loginBtn];
}
//注册
- (void)userRegister
{
    RegisterViewController *regist = [[RegisterViewController alloc] init];
    regist.cityData = self.cityData;
    [self.navigationController pushViewController:regist animated:YES];
}
//登陆
- (void)login
{
    LoginViewController * login = [[LoginViewController alloc] init];
    [self.navigationController pushViewController:login animated:YES];
    
}
@end
