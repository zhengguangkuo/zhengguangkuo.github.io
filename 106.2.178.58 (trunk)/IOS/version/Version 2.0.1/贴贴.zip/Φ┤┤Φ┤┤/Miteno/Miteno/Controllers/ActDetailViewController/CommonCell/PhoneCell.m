//
//  PhoneCell.m
//  Miteno
//
//  Created by wg on 14-4-2.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "PhoneCell.h"
#define kSpaceNumber 15
#define kSpaceIcon   80
@implementation PhoneCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        
        [self initLayout];
    }
    
    return self;
}
- (void)initLayout
{
    CGSize size = self.size;
    _number = [[UILabel alloc] init];
    _number.frame = CGRectMake(kSpaceNumber, 0,size.width/2,size.height);
    _number.backgroundColor = [UIColor clearColor];
    [self addSubview:_number];
    
    _phoneIcon = [[UIButton alloc] init];
    _phoneIcon.frame = CGRectMake(size.width-kSpaceIcon+30,5,size.height-10,size.height-10);
    [_phoneIcon setBackgroundColor:[UIColor clearColor]];
    [_phoneIcon setBackgroundImage:[UIImage imageNamed:@"about_phone_icon.png"] forState:UIControlStateNormal];
    [self addSubview:_phoneIcon];
}
@end
