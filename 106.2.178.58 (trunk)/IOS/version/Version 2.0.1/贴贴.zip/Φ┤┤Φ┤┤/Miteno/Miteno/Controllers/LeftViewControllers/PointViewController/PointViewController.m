//
//  PointViewController.m
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "PointViewController.h"
#import "Credits.h"



@interface PointViewController ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic, strong) NSMutableArray*  pointArray;

@property (nonatomic, strong) UITableView* PointTableView;

-(void)ReuqestPointList;

@end

@implementation PointViewController

@synthesize pointArray;

@synthesize PointTableView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"积分查询";
        self.view.backgroundColor = [UIColor whiteColor];
    }
    return self;
}


-(void)ReuqestPointList
{
    NSString*  testURL =  [NSString stringWithFormat:@"%@%@",  WEB_SERVICE_ENV_VAR,Key_Query_Point];
    NSLog(@"testURL = %@",testURL);
    
    HttpService*  tempservice = [HttpService  HttpInitPostForm:testURL
                body:nil
                withHud:YES];
    [tempservice  setDelegate:self];
    [tempservice  setDataHandler:^(NSString* data)
    {
        NSLog(@"积分数据 = %@",data);
         [self ParseJsonToDictionary:(data) block:^(int Total, NSDictionary *dic)
         {
             [self ParseObject:dic];
         }];
        
        
         dispatch_async(dispatch_get_main_queue(),
        ^{
            if([self.pointArray count]>0)
               [self.PointTableView reloadData];
            else
               [self.view makeToast:@"暂无数据"];
        });
    }
    ];
    [tempservice startOperation];
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self.pointArray removeAllObjects];
    [self  ReuqestPointList];
}


- (void)ParseObject:(NSDictionary*)dic
{
    Credits* tempobject = [[Credits alloc] initWithDictionary:dic];
    
    id creditID = dic[@"id"];
    if(!ChNil(creditID))
    {
        ID* IDobject = [[ID alloc] initWithDictionary:creditID];
        [tempobject setCreditsID:IDobject];
    }

    id Issuer = dic[@"couponIssuer"];
    if(!ChNil(Issuer))
    {
        CouponIssuer* object = [[CouponIssuer alloc] initWithDictionary:Issuer];
        [tempobject setCreditsIssuer:object];
    }
    NSLog(@"int value = %d",tempobject.credits);
    NSLog(@"value id = %@",tempobject.creditsID.user_id);
    NSLog(@"value object = %@",tempobject.creditsIssuer.cname);
    [self.pointArray addObject:tempobject];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self NavigationViewBackBtn];
    self.pointArray = [[NSMutableArray alloc] init];
    self.PointTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 320, 350) style:UITableViewStylePlain];
    [PointTableView setDataSource:self];
    [PointTableView setDelegate:self];
    [PointTableView setBackgroundColor:[UIColor whiteColor]];
    [self.view addSubview:self.PointTableView];

}



-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    return [self.pointArray count];
}


-(UITableViewCell *)tableView:(UITableView *)tableView
		cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString*  groupTableIdentifier = @"PointView";
    UITableViewCell*  tempcell2 = nil;
    tempcell2 = [tableView dequeueReusableCellWithIdentifier:groupTableIdentifier];
    
    if(tempcell2==nil)
    {
        tempcell2 = [[UITableViewCell  alloc]  initWithStyle:UITableViewCellStyleDefault reuseIdentifier:groupTableIdentifier];
        tempcell2.selectionStyle = UITableViewCellSelectionStyleNone;
    
        UILabel*  orgnizeLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 4, 100, 40)];
        [orgnizeLabel setBackgroundColor:[UIColor clearColor]];
        [orgnizeLabel setFont:[UIFont boldSystemFontOfSize:16.0f]];
        [orgnizeLabel setTextColor:[UIColor blackColor]];
        [orgnizeLabel setText:@"暂无机构"];
        [tempcell2.contentView addSubview:orgnizeLabel];
        [orgnizeLabel setTag:1];
        
        
        UILabel*  expireLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 35, 200, 30)];
        [expireLabel setBackgroundColor:[UIColor clearColor]];
        [expireLabel setFont:[UIFont boldSystemFontOfSize:12.0f]];
        [expireLabel setTextColor:[UIColor lightGrayColor]];
        [expireLabel setText:@"暂无有效期"];
        [tempcell2.contentView addSubview:expireLabel];
        [expireLabel setTag:2];

        
        UILabel*  PointLabel = [[UILabel alloc] initWithFrame:CGRectMake(220, 16, 100, 40)];
        [PointLabel setBackgroundColor:[UIColor clearColor]];
        [PointLabel setFont:[UIFont boldSystemFontOfSize:14.0f]];
        [PointLabel setTextColor:[UIColor lightGrayColor]];
        [PointLabel setText:@"暂无积分"];
        [tempcell2.contentView addSubview:PointLabel];
        [PointLabel setTag:3];
    }
    Credits*  cts = self.pointArray[indexPath.row];
    UILabel*  templabel = (UILabel*)[tempcell2 viewWithTag:1];
    [templabel setText:cts.creditsIssuer.cname];
    
    UILabel*  templabel2 = (UILabel*)[tempcell2 viewWithTag:2];
    [templabel2 setText:[NSString stringWithFormat:@"有效期：%@",cts.creditsID.user_id]];
    
    UILabel*  templabel3 = (UILabel*)[tempcell2 viewWithTag:3];
    [templabel3 setText:[NSString stringWithFormat:@"积分：%d",cts.credits]];
    return tempcell2;
}





- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}


//点击返回
- (void)backToPrevious
{
    [self.viewDeckController toggleLeftViewAnimated:YES];
    
}

@end
