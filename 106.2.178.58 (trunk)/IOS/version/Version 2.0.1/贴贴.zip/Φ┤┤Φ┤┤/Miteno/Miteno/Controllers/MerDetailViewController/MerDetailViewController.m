//
//  MerDetailViewController.m
//  Miteno
//
//  Created by HWG on 14-3-20.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "MerDetailViewController.h"

@interface MerDetailViewController ()

@end

@implementation MerDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.view.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
    [self setNavTheme];
    
    
}

#pragma mark -初始化导航栏主题
- (void)setNavTheme
{
    self.title = @"商家详情";
    
    UIBarButtonItem *item =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                            andTitle:nil
                                            andImage:[UIImage imageNamed:@"gb_button"]
                                           addTarget:self
                                           addAction:@selector(back)];
    
    UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];
    
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];
    //[UIBarButtonItem barButtonItemWithIcon:@"top_bt_bg.png" target:self action:@selector(back)];
}
- (void)viewWillAppear:(BOOL)animated
{
    UIWebView *web = [[UIWebView alloc] initWithFrame:[UIScreen mainScreen].applicationFrame];
    self.view = web;
    web.backgroundColor = [UIColor whiteColor];
    NSString *detailMeg = @"";
    if (![self.detailMeg isKindOfClass:[NSNull class]]) {
        detailMeg = self.detailMeg;
    }else{
        
        [SystemDialog alert:@"暂无数据"];
    }
    [web loadHTMLString:detailMeg baseURL:nil];
}

- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}
@end
