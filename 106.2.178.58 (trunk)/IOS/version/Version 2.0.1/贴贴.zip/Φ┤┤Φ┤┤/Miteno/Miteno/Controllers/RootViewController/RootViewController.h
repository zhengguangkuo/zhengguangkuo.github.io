//
//  RootViewController.h
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright wenguang 2014年. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HttpService.h"
#import "NSObject(parse).h"
//#import "Toast+UIView.h"
#import "SystemDialog.h"


@interface RootViewController : UIViewController<ConnectFailureDelegate,UIAlertViewDelegate>

@property  (nonatomic, strong) HttpService*  service;

@property  (nonatomic, strong) NSString    *clientVersion; //版本号

-(void)SetNaviationTitleName:(NSString*)str;

-(void)SetNaviationRightButtons:(NSArray*)buttons;

-(void)NavigationTitleColor:(UIColor*)color;

- (CGFloat)GetNavigationBarPosY;

- (void)backToPrevious;

- (void)NavigationViewBackBtn;

- (void)NavigationHiddenBack;

//- (int)GetCurrentController;

- (UIViewController*)GetPreController;

- (NSString*)Md5Encry:(NSString*)pwd userName:(NSString*)User;

- (void)getClientVersion;

@end
