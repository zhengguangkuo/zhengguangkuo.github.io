//
//  ActDetailViewController.m
//  Miteno
//
//  Created by HWG on 14-3-18.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "ActDetailViewController.h"
#import "DiscountViewViewController.h"
#import "ActDetailCell.h"
#import "Act.h"
#import "ActDetail.h"
#import "DetailCell.h"
#import "PhoneCell.h"
#import "LoginViewController.h"
#import "MerDetailViewController.h"
#import "AddressViewCell.h"
#import "AttentionViewController.h"
#import "MapsViewController.h"
#import "Utilities.h"
#import "AppDelegate.h"
#import "WebViewCell.h"
#import "Toast+UIView.h"
#define kTopImageHeight ScreenHeight*0.35
#define kImageBarHeight 50
#define kSpace 5
#define kClaimedHeight kImageBarHeight-10
#define kDetailURL [NSString stringWithFormat:@"%@mobile/coupon/actView/list",kBaseURL]
#define kclaimedURL [NSString stringWithFormat:@"%@mobile/coupon/couponReceive",kBaseURL]
#define kAttention [NSString stringWithFormat:@"%@mpayFront/careMerchants",kBaseURL]
#define kCellHeight 44
#define kFount  [ UIFont systemFontOfSize:15]
#define kimgBar    0
#define kclaimed   1
#define kWebHeight 44*3


@interface ActDetailViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    UIImageView             *_topImageView;    //顶部图片
    UITableView             *_actDetailView;   //
    NSArray                 *_headTitle;
    NSMutableArray          *_actDetailcoupons;
    NSString                *_telephone;
    LoginViewController     *_login;
    NSString                *_couponIssuerId;
    NSString                *_detailMeg;
    NSString                *_coordinate;       //坐标
}
@property (nonatomic, strong)UIWebView *web;
@end

@implementation ActDetailViewController
@synthesize act;
@synthesize ClaimFlag;



- (void)loadView
{
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:kScreenBounds];
    scrollView.contentSize = CGSizeMake(ScreenWidth, ScreenHeight);
    self.view = scrollView;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
//
        self.ClaimFlag = FALSE;
    }
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    _headTitle = [NSArray arrayWithObjects:@"优惠详情",@"活动规则",@"使用期限",@"商家详情",@"商家地址",@"联系方式", nil];
    
    //设置导航
    [self setNavTheme];
    
    //添加tableview
    [self addTableView];
}
#pragma mark -初始化导航栏主题
- (void)setNavTheme
{
    self.title = @"活动详情";
    
    UIBarButtonItem *item =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                            andTitle:nil
                                            andImage:[UIImage imageNamed:@"gb_button"]
                                           addTarget:self
                                           addAction:@selector(back)];
    UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];
    
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];
    
    self.navigationItem.rightBarButtonItem =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                            andTitle:@"关注"
                                            andImage:[UIImage imageNamed:nil]
                                           addTarget:self
                                           addAction:@selector(attention)];
    //[UIBarButtonItem barButtonItemWithIcon:@"eye.png" target:self action:@selector(attention)];
}
- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark -关注
- (void)attention
{
    if ([[AppDelegate getApp] isLogining] == NO) {
        [SystemDialog alert:@"用户未登录"];
        [self isLogin];
        return;
    }
    NSString *merchId = @"";
    if (self.act.merchId) {
        merchId = self.act.merchId;
    }
    NSDictionary *dict = @{@"actId": merchId};
    
    HttpService  *tempservice = [HttpService  HttpInitPostForm:kAttention
                                                          body:dict
                                                       withHud:YES];
    
    [tempservice setDataHandler:^(NSString *data) {
        NSDictionary *dicts = [data objectFromJSONString];
        if ([[dicts objectForKey:@"respcode"] integerValue]==0) {
//            AttentionViewController *attention = [[AttentionViewController alloc]init];
//            attention.act = self.act;
//            [self.navigationController pushViewController:attention animated:YES];
            /*关注成功*/
            [SystemDialog alert:@"关注成功"];
        }else if ([[dicts objectForKey:@"respcode"] integerValue]==-1){
            [SystemDialog alert:[dicts objectForKey:@"message"]];
            _login = [[LoginViewController alloc] init];
            _login.backController = self;
            [self.navigationController pushViewController:_login animated:YES];
        }else{
            [SystemDialog alert:[dicts objectForKey:@"message"]];
        }
    }];
    
    [self getError:tempservice];
    [tempservice startOperation];
}

#pragma mark -添加imageView
- (void)addImageView
{
    _topImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0,0, ScreenWidth, kTopImageHeight)];
    _topImageView.backgroundColor = [UIColor grayColor];
    _topImageView.userInteractionEnabled = YES;
    if (![self.act.pic_path isKindOfClass:[NSNull class]]) {
        [_topImageView setImageFromUrl:self.act.pic_path];
    }else{
        _topImageView.image = [UIImage imageNamed:@"load.png"];
    }
    [self.view addSubview:_topImageView];
    /**
    UIView *imgBar = [[UIView alloc] initWithFrame:CGRectMake(0, _topImageView.frame.size.height-kImageBarHeight, ScreenWidth, kImageBarHeight)];
    //imgBar.backgroundColor = kGlobalBg;
    [imgBar setTag:kimgBar];
    [_topImageView addSubview:imgBar];
    
    //领取
    CGFloat width = 70;
    UIButton *claimed = [[UIButton alloc] initWithFrame:CGRectMake(imgBar.frame.size.width-width+12,kSpace+10, width-20,kClaimedHeight-10)];
    [claimed setBackgroundImage:[UIImage stretchImageWithName:@"word_botton_orenge.9.png"] forState:UIControlStateNormal];
    [claimed setTitle:@"领取" forState:UIControlStateNormal];
    [claimed addTarget:self action:@selector(clickClaimed) forControlEvents:UIControlEventTouchUpInside];
    [claimed setTag:kclaimed];
    [imgBar addSubview:claimed];
     */
}
#pragma mark -添加tableview
- (void)addTableView
{
    CGFloat y = kTopImageHeight + _topImageView.frame.origin.y;
    _actDetailView= [[UITableView alloc] initWithFrame:CGRectMake(0,y, ScreenWidth, ScreenHeight-kTopImageHeight) style:UITableViewStyleGrouped];
    //    _actDetailView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _actDetailView.sectionHeaderHeight = 10;
    _actDetailView.sectionFooterHeight = 5;
    
    _actDetailView.delegate = self;
    _actDetailView.dataSource = self;
    _actDetailView.contentInset = UIEdgeInsetsMake(0, 0, 60, 0);
    [self.view addSubview:_actDetailView];
}
#pragma mark -tableViewDelegateAndDatasources
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return _headTitle.count;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==4) {
        return 1;
    }
    return 2;
}
#pragma mark -cell delegate
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ActDetail *detail = [_actDetailcoupons lastObject];
    _couponIssuerId = detail.couponIssuerId;
    _detailMeg = detail.detailMeg;

    if (indexPath.row==0) {
        if (indexPath.section==4) {
            static NSString *ID = @"AddressViewCell";
            AddressViewCell *adCell = (AddressViewCell *)[tableView dequeueReusableCellWithIdentifier:ID];
            if (adCell == nil) {
                adCell = [[AddressViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
            }
            adCell.header.text = _headTitle[indexPath.section];
            adCell.content.text = detail.address;
            [adCell setContentText:detail.address];
            [adCell.queryMap addTarget:self action:@selector(queryMap) forControlEvents:UIControlEventTouchUpInside];
            _coordinate = self.act.coordinate;
            return adCell;
        }
        static  NSString *identifier = @"UITableViewCell";
        ActDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell==nil) {
            cell = [[ActDetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        }
        //修改部分
        if (indexPath.row==0&&indexPath.section==0) {
            static NSString *webCellIdentifier = @"webCellIdentifier";
            WebViewCell *webCell = (WebViewCell *)[tableView dequeueReusableCellWithIdentifier:webCellIdentifier];
            if (webCell == nil) {
                webCell = [[WebViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:webCellIdentifier];
                webCell.header.text = _headTitle[indexPath.section];
            }
            if (self.ClaimFlag) {
                webCell.claimed.hidden = YES;
            }
//            [webCell.web loadHTMLString:detail.content baseURL:nil];
            [webCell.claimed addTarget:self action:@selector(clickClaimed) forControlEvents:UIControlEventTouchUpInside];
            return webCell;
        }
   /*
        //设置标题
        if (indexPath.row == 0&&indexPath.section!=4) {
            cell.textLabel.textColor = Orange;
            [cell.textLabel setFont:[UIFont systemFontOfSize:20]];
            cell.textLabel.text = _headTitle[indexPath.section];
        }
   */
        //设置标题
        if (indexPath.row == 0&&indexPath.section!=4&&indexPath.section!=0) {
            cell.textLabel.textColor = Orange;
            [cell.textLabel setFont:[UIFont systemFontOfSize:20]];
            cell.textLabel.text = _headTitle[indexPath.section];
        }
        return cell;

    }else{
        static  NSString *identifier = @"ActDetailCell";
        ActDetailCell *cell = (ActDetailCell *)[tableView cellForRowAtIndexPath:indexPath];
        if (cell == nil) {
            cell = [[ActDetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
            cell.textLabel.numberOfLines = 0;
        }
        CGFloat width = cell.width-20;
        if (IOS7) {
            width = cell.width;
        }
        if (indexPath.section==0) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.web = [[UIWebView alloc] init];
                self.web.backgroundColor = [UIColor whiteColor];
                self.web.frame = CGRectMake(0, 0,width,kWebHeight);
                [self.web loadHTMLString:detail.content baseURL:nil];
                [cell.contentView addSubview:_web];    // *** 将UI操作放到主线程中执行 ***
            });
//
        }
        if (indexPath.section==1) {
            [cell.textLabel setFont:kFount];
            cell.textLabel.text = [NSString stringWithFormat:@"每天最大发行量为%@张;\n每人最多能领用%@张;\n一笔消费最多能使用优惠劵%@张;",detail.dayLimit,detail.personLimit,detail.maxPieces];
        }
        if (indexPath.section==2) {
            
            [cell.textLabel setFont:kFount];
            cell.textLabel.text = [NSString stringWithFormat:@"%@-%@",[NSString processDateMethod:detail.startDate],[NSString processDateMethod: detail.endDate]];
        }
        if (indexPath.section==3) {
            static  NSString *detailCellIdentifier = @"DetailCell";
            DetailCell *detailCell = (DetailCell *)[tableView dequeueReusableCellWithIdentifier:detailCellIdentifier];
            if (detailCell == nil) {
                detailCell = [[DetailCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:detailCellIdentifier];
            }
            [detailCell.merDetail addTarget:self action:@selector(queryDetail) forControlEvents:UIControlEventTouchUpInside];
            cell = detailCell;
        }
        if (indexPath.section==5) {
            static NSString *phoneIdentifier =@"PhoneCell";
            PhoneCell *phoneCell = [tableView dequeueReusableCellWithIdentifier:phoneIdentifier];
            if (phoneCell==nil) {
                phoneCell = [[PhoneCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:phoneIdentifier];
            }
            if (!ChNil(detail.telephone)) {
                
                phoneCell.number.text = detail.telephone;
            }
            _telephone = detail.telephone;
            [phoneCell.phoneIcon addTarget:self action:@selector(call) forControlEvents:UIControlEventTouchUpInside];
            cell = phoneCell;
        }
        return cell;
    }
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 5 &&indexPath.row==1) {
        [self performSelector:@selector(call) withObject:nil];
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    int cellHeight = kCellHeight;
    
    if (indexPath.section==0&&indexPath.row==1) {
        return kWebHeight;
    }
    if (indexPath.section==1&&indexPath.row==1) {
        return kCellHeight * 2;
    }
    if (indexPath.section == 4) {
            AddressViewCell *address = (AddressViewCell *)[self tableView:_actDetailView cellForRowAtIndexPath:indexPath ];
            cellHeight = address.frame.size.height;
    }
    return cellHeight;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return section==0?20:15;
}

#pragma mark -商家详情
- (void)queryDetail
{
    MerDetailViewController *merDetail = [[MerDetailViewController alloc] init];
    merDetail.detailMeg = _detailMeg;
    [self.navigationController pushViewController:merDetail animated:YES];
}
- (void)queryMap
{
    MyLog(@"地图%@",_coordinate);
    
    MapsViewController *mapViewController = [[MapsViewController alloc]init];
    [self presentViewController:mapViewController animated:NO completion:nil];
    [mapViewController addAnnotationView:_coordinate andMerchName:self.act.merch_name];
}
- (void)call
{
    if (_telephone!=nil) {
//        NSString *tel = [NSString stringWithFormat:@"tel://%@",_telephone];
//        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:tel]];
        NSMutableString *tel=[[NSMutableString alloc] initWithFormat:@"tel:%@",_telephone];
        UIWebView *callWebview = [[UIWebView alloc] init];
        [callWebview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:tel]]];
        [self.view addSubview:callWebview];
    }
}
#pragma mark -领取点击事件
- (void)clickClaimed
{

    if ([[AppDelegate getApp] isLogining] == NO) {
        [SystemDialog alert:@"用户未登录"];
        [self isLogin];
        return;
    }
    NSString *actId = @"";
    NSString *couponIssuerId = @"";
    if (self.act.idStr) {
        actId = self.act.idStr;
    }
    else
        return;
    
    if (_couponIssuerId) {
        couponIssuerId = _couponIssuerId;
    }
    else 
        return;
    NSDictionary *dict = @{@"actId"     : actId,
                           @"couponIssuerId"   :_couponIssuerId};
    HttpService  *tempservice = [HttpService  HttpInitPostForm:kclaimedURL
                                                          body:dict
                                                       withHud:YES];
    [tempservice setDataHandler:^(NSString *data) {
        NSDictionary *dicts = [data objectFromJSONString];
        NSString *result = [dicts objectForKey:@"respcode"];
          if ([result integerValue]==-1) {
            [SystemDialog alert:[dicts objectForKey:@"message"]];
            [self isLogin];
        }
        if ([result integerValue]==0) {
            [SystemDialog alert:[dicts objectForKey:@"message"]];
        }
//        if ([[dicts objectForKey:@"respcode"] integerValue]==81) {
//            [SystemDialog alert:[dicts objectForKey:@"message"]];
//        }
        else
        {
             [SystemDialog alert:[dicts objectForKey:@"message"]];
        }

    }];
    
    [self getError:tempservice];
    [tempservice startOperation];
    
}
- (void)isLogin{
    _login = [[LoginViewController alloc] init];
    _login.backController = self;
    [self.navigationController pushViewController:_login animated:YES];
}

#pragma -cellClick
#pragma mark -加载数据
- (void)viewWillAppear:(BOOL)animated
{
    //如果有值 不需要重新加载
    if (_actDetailcoupons.count>0) {
        return;
    }
    NSString *actId = @"";
    NSString *merchId = @"";
    NSLog(@"领取标志ClaimFlag = %d",self.ClaimFlag);
    
    
    //添加imagView
    [self addImageView];

    if (self.act) {
        actId = self.act.idStr;
        merchId = self.act.merchId;
        if(self.act.is_apply)
        {
            NSLog(@"heelllo  world");
            UIView* imabar = [_topImageView viewWithTag:kimgBar];
            UIButton* btn = (UIButton*)[imabar viewWithTag:kclaimed];
            btn.hidden = TRUE;
        }
    }
    NSDictionary *dict = @{@"actId"     : actId,
                           @"merchId"   :merchId};
    HttpService  * tempservice = [HttpService  HttpInitPostForm:kDetailURL
                                                          body:dict
                                                       withHud:YES];
    
    [tempservice setDataHandler:^(NSString *data) {
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *arr = dicts[@"rows"];
        _actDetailcoupons = [NSMutableArray array];
        for (NSDictionary *dict in arr) {
            ActDetail *detail = [[ActDetail alloc] initWithDict:dict];
            [_actDetailcoupons addObject:detail];
        }
        [_actDetailView reloadData];
    }];
    
    [self getError:tempservice];
    [tempservice startOperation];
}
//网络异常
- (void)getError:(HttpService *)tempservice
{
    [tempservice setErrorHandler:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [SystemDialog alert:kConnectFailure];
        });
    }];
}

@end
