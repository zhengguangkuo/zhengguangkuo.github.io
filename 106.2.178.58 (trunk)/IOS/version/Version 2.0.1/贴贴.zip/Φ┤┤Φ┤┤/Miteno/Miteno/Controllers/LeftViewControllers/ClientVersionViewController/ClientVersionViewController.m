//
//  ClientVersionViewController.m
//  Miteno
//
//  Created by HWG on 14-3-3.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//


#import "ClientVersionViewController.h"

#define kClientVersonURL [NSString stringWithFormat:@"%@mobile/coupon/versionReplace",kBaseURL]

@interface ClientVersionViewController ()<UIAlertViewDelegate>
{
    NSString    *_newVersionUrl;
}
@end

@implementation ClientVersionViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"版本更新";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	//导航左边item
    UIBarButtonItem *item =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                            andTitle:nil
                                            andImage:[UIImage imageNamed:@"gb_button"]
                                           addTarget:self
                                           addAction:@selector(back)];

    UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];
    
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];
//    [UIBarButtonItem barButtonItemWithIcon:@"top_bt_bg.png" target:self action:@selector(back)];
    //[self SetNaviationTitleName:@"检查更新"];
}
- (void)back{
       [self.viewDeckController toggleLeftViewAnimated:YES];
}
//获取当前版本号
- (NSString *)currentVersion
{
    //获取本地版本号
      NSDictionary *infoDict = [[NSBundle mainBundle] infoDictionary];
   
        NSString *nowVersion = [infoDict objectForKey:@"CFBundleShortVersionString"];
    
        return nowVersion;
}
- (void)update{
    NSString *currentVersion = [self currentVersion];
    NSDictionary *dict = @{@"versionNo":currentVersion};
    MyLog(@"当前版本号:%@",currentVersion);
   ;
    HttpService  *tempservice = [HttpService  HttpInitPostForm:kClientVersonURL
                                                          body:dict
                                                       withHud:YES];
    [tempservice setDataHandler:^(NSString *data) {
        
        NSDictionary *dicts = [data objectFromJSONString];
        //已是最新版本
        if ([[dicts objectForKey:@"respcode"] integerValue]==0) {
             UIAlertView *alert = [[UIAlertView alloc] initWithTitle:currentVersion message:@"已是最新版本" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:@"取消", nil];
            [alert show];
        }
        //新版本
        if ([[dicts objectForKey:@"respcode"] integerValue]==1) {
            //新版本更新的内容
            //            [SystemDialog alert:[dict objectForKey:@"replaceContent"]];
            
            //最新版本号
//                        [SystemDialog alert:[dict objectForKey:@"newVersionNo"]];
            //新版本下载地址
            NSString *newVersionUrl = [dicts objectForKey:@"linkAddress"];
            _newVersionUrl = newVersionUrl;
            
            NSString *mesg = [NSString stringWithFormat:@"当前版本%@",currentVersion];
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"当前不是最新,是否前往更新?" message:mesg delegate:self cancelButtonTitle:@"确定" otherButtonTitles:@"取消", nil];
            [alert show];
        }
        //版本号不正确
        if ([[dicts objectForKey:@"respcode"] integerValue]==-1) {
            
            [SystemDialog alert:[dict objectForKey:@"message"]];
        }
        
    }];
    [tempservice startOperation];
    [self getError:tempservice];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:_newVersionUrl]];
    }
}
- (void)getError:(HttpService *)tempservice
{
    [tempservice setErrorHandler:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [SystemDialog alert:kConnectFailure];
        });
    }];
}
#pragma mark -tableviewDelegateAndDatasouces
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static  NSString *identifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        UIView *back  = [[UIView alloc] init];
        back .backgroundColor = [UIColor clearColor];
        cell.accessoryView = back;
    }
    cell.textLabel.text = @"版本更新";
    cell.textLabel.font = [UIFont systemFontOfSize:25];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //取消	选中当前行
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    //新版本更新
    [self update];
}

@end
