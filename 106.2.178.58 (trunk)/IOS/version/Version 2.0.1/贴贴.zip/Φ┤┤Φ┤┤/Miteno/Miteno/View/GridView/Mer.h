//
//  Shop.h
//  iGridViewDemo
//
//  Created by HWG on 14-2-17.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Mer : NSObject
@property (nonatomic, copy)NSString *iconURL;
@property (nonatomic, copy)NSString *name;
@property (nonatomic, strong)UIImage *image;
@end
