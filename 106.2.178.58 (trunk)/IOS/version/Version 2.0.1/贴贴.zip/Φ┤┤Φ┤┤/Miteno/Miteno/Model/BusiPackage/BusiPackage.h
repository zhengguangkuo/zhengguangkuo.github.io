//
//  BasicCard.h
//  M-Pay
//
//  Created by guorong on 14-2-24.
//  Copyright miteno 2014年. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Base.h"

@interface BusiPackage : Base

@property (nonatomic, copy)  NSString* ID;
@property (nonatomic, copy)  NSString* pkg_name;
@property (nonatomic, copy)  NSString* busi_code;
@property (nonatomic, copy)  NSString* special_no;
@property (nonatomic, copy)  NSString* detail;
@property (nonatomic, copy)  NSString* bind_flag;

@end

