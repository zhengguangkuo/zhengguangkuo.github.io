//
//  Account.h
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright wenguang 2014年. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Base.h"

@interface MpayUser : Base

@property  (nonatomic, strong)  NSString* user_id;

@property  (nonatomic, strong)  NSString* realname;

@property  (nonatomic, strong)  NSString* sex;

@property  (nonatomic, strong)  NSString* marriage_state;

@property  (nonatomic, strong)  NSString* birthday;

@property  (nonatomic, strong)  NSString* idcard;

@property  (nonatomic, strong)  NSString* telephone;

@property  (nonatomic, strong)  NSString* mobile;

@property  (nonatomic, strong)  NSString* email;

@property  (nonatomic, strong)  NSString* home_addr;

@property  (nonatomic, strong)  NSString* reg_date;

@property  (nonatomic, strong)  NSString* nickname;


@end
