//
//  LoginViewController.h
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "RootViewController.h"
/*
 *  登陆和忘记密码
 */
typedef enum {
    KSignInButtonSignIn = 1010,         //登录
//    KSignInButtonServeTermas,           //服务条款按钮
//    KSignInButtonStandard,              //标准注册按钮
    
    KSignInButtonForgetpassword,        //忘记密码
    kSignUpItemUserNameField,           //账号
    kSignUpItemPasswordField,           //密码
}KSignInButton;
@interface LoginViewController : RootViewController

@property (nonatomic,assign)UIViewController *backController;
@end
