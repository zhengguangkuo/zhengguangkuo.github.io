//
//  HelpViewViewController.m
//  miteno
//
//  Created by HWG on 14-3-3.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "HelpViewViewController.h"
#import "FileManager.h"
@interface HelpViewViewController ()
{
    UIWebView   *_webView;
}
@end

@implementation HelpViewViewController
- (void)loadView{
    _webView = [[UIWebView alloc] initWithFrame:kAppFrame];
    _webView.backgroundColor = [UIColor clearColor];
    self.view = _webView;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        self.title = @"帮助";
        
    }
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    //导航左边item
    UIBarButtonItem *item =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                            andTitle:nil
                                            andImage:[UIImage imageNamed:@"gb_button"]
                                           addTarget:self
                                           addAction:@selector(back)];

    UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];
    
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];
//    [UIBarButtonItem barButtonItemWithIcon:@"top_bt_bg.png" target:self action:@selector(back)];
}
- (void)back
{
    [self.viewDeckController toggleLeftViewAnimated:YES];
}
- (void)viewWillAppear:(BOOL)animated{
    NSString *filePath = [[NSBundle mainBundle]pathForResource:@"help" ofType:@"html"];
    NSString *htmlString = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    [(UIWebView *)self.view loadHTMLString:htmlString baseURL:[NSURL URLWithString:filePath]];
}


@end
