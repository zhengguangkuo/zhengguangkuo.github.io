//
//  SystemDialog+Show.h
//  Toast
//
//  Created by HWG on 14-1-26.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "SystemDialog.h"

@interface SystemDialog (Show)
+ (void)alert:(NSString *)msg;
@end
