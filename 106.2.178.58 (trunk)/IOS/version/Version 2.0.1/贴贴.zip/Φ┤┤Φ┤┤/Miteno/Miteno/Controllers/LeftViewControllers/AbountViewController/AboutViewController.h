//
//  AboutViewController.h
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "RootViewController.h"

typedef enum
{
    UIPopControllerBack,
    UILeftViewDragBack

}UIBackStyle;


@interface AboutViewController : RootViewController

@property  (nonatomic, assign) UIBackStyle backStyle;

@end
