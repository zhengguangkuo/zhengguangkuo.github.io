//
//  AttentionViewController.m
//  Miteno
//
//  Created by HWG on 14-3-21.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "AttentionViewController.h"
#import "Mer.h"
#import "GridCell.h"
#import "Act.h"
#define kIcouURL @"iconURL"
#define kMerName @"merName"
//关注商家列表URL
#define kAttentionURL [NSString stringWithFormat:@"%@mobile/coupon/userCareMerchListByLoginUser/list",kBaseURL]

#define kFileName @"mers.plist"
#define kCurrentName @"currentMers.data"

#define kFilePath [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0] stringByAppendingPathComponent:kFileName]

#define kCurrentPath [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0] stringByAppendingPathComponent:kCurrentName]
@interface AttentionViewController ()<MJRefreshBaseViewDelegate,UITableViewDelegate,UITableViewDataSource>
{
    MJRefreshHeaderView  *  _header;            //上拉
    MJRefreshFooterView  *  _footer;            //下拉
    NSMutableArray       *  _currentDatas;      //当前数组中的数据
}
@property (nonatomic, strong)NSMutableArray *mers;
@end

@implementation AttentionViewController
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setNavTheme];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"leather_bg.png"]];
    self.tableView.backgroundView = imageView;
    //添加下拉刷新和上拉加载更多
//    _header = [[MJRefreshHeaderView alloc] init];
//    self.tableView.delegate = self;
//    self.tableView.dataSource = self;
//    _header.delegate = self;
//    _header.scrollView = self.tableView;
////    [_header beginRefreshing];
//    _footer = [[MJRefreshFooterView alloc] init];
//    _footer.scrollView = self.tableView;
//    _footer.delegate = self;

}
#pragma mark -初始化导航栏主题
- (void)setNavTheme
{
    self.title = @"我关注的商家";
    
    UIBarButtonItem *item =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                            andTitle:nil
                                            andImage:[UIImage imageNamed:@"gb_button"]
                                           addTarget:self
                                           addAction:@selector(back)];

    UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];
    
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];
//    [UIBarButtonItem barButtonItemWithIcon:@"top_bt_bg.png" target:self action:@selector(back)];
}
- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark -tableViewdelegate And datasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return (self.mers.count + kColumn - 1)/kColumn;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static  NSString *identifier = @"Cell";
    GridCell *cell = (GridCell *)[tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[GridCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];

    }
    // 从哪个位置开始截取
    int location = indexPath.row * kColumn;
    // 截取的长度
    int length = kColumn;
    
    if (location + length >= self.mers.count) {
        length = self.mers.count - location;
    }
    
    NSRange range = NSMakeRange(location, length);
    NSMutableArray *ass = [NSMutableArray array];
    NSArray *arr = [NSArray arrayWithContentsOfFile:kFilePath];
    for (NSDictionary *dict  in arr) {
        Mer *mer = [[Mer alloc] init];
        mer.iconURL = [dict objectForKey:kIcouURL];
        mer.name = [dict objectForKey:kMerName];
        [ass addObject:mer];
    }

    NSArray *rowShops = [ass subarrayWithRange:range];
    [cell setRowShops:rowShops];
    
    //点击的item
    cell.blcok = ^(ImageButton *item){
        NSLog(@"点击了----%@",item.titleLabel.text);

        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:item.titleLabel.text message:@"已关注" delegate:self cancelButtonTitle:@"确定" otherButtonTitles:@"取消", nil];
        [alert show];
    };
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return kCellHeight;
}
#pragma mark -代理方法名(上拉、下拉刷新)
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
//    [self loadMerchantsContent];
    if (_header == refreshView) {
        // 下拉
        MyLog(@"关注下拉刷新");
        [self loadMerchantsContent];
    } else {
        // 上拉
        MyLog(@"关注上拉刷新");
//        [self loadUpMerchantsContent];
    }
    [_footer endRefreshing];
    [_header endRefreshing];
}
- (void)loadMerchantsContent
{
    [self.tableView reloadData];
    [_header endRefreshing];

}
//优惠劵列表 上拉加载较大的
- (void)loadUpMerchantsContent
{
    long row = 10;
    int num = 1;

    NSString *page = [NSString stringWithFormat:@"%d",num];
    NSString *rows = [NSString stringWithFormat:@"%ld",row];
    NSDictionary *dict = @{@"page":page,
                           @"rows":rows};
    HttpService  *tempservice = [HttpService  HttpInitPostForm:kAttentionURL
                                                          body:dict
                                                       withHud:YES];
    
    [tempservice setDataHandler:^(NSString *data) {
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *arr = dicts[@"rows"];
        for (NSDictionary *dict in arr) {
        }
        //总条数
//        long totol = [dicts[@"total"] integerValue];
//        if (_coupons.count == totol) {
//            [SystemDialog alert:@"已经没有最新数据..."];
//        }
        
        //刷新表格
        [self.tableView reloadData];
        [_footer endRefreshing];
    }];
    
    [tempservice startOperation];
    [self getError:tempservice];
}
- (void)getError:(HttpService *)tempservice
{
    [tempservice setErrorHandler:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [_footer endRefreshing];
            [_header endRefreshing];
            [SystemDialog alert:kConnectFailure];
        });
    }];
}
- (void)dealloc
{
    [_header free];
    [_footer free];

}
- (void)viewWillDisappear:(BOOL)animated
{
    MyLog(@"当前数组===%d",_currentDatas.count);
    //清空沙盒文件
    [_currentDatas removeAllObjects];
    
}
- (void)viewWillAppear:(BOOL)animated
{
//    Mer *mer = [[Mer alloc] init];
    MyLog(@"是否关注标示%@",self.act.claimFlag);
    /*
    //添加商家
    mer.iconURL = self.act.pic_path;
    mer.name = self.act.merch_name;
    //将字典存入数组
    _currentDatas = [NSMutableArray array];
    [_currentDatas addObject:dict];
    
    //取出沙盒文件
    NSMutableArray *tempArr = [NSMutableArray arrayWithContentsOfFile:kFilePath];
    if (tempArr.count>0) {
        //如果沙盒已经存在文件
        BOOL isHave = YES;
        BOOL isAdd = YES;
        NSMutableArray *arr = [NSMutableArray arrayWithArray:tempArr];
        for (NSDictionary *worn in arr) {
            //遍历当前沙盒中的文件
            if ([[worn objectForKey:kMerName]isEqualToString:[dict objectForKey:kMerName]]) {
                isHave = NO;
                isAdd = NO;
                [SystemDialog alert:@"不能重复添加"];
            }
        }
        if (isAdd==YES) {
            isAdd == YES?[arr addObject:dict]:nil;
            isHave == YES?[SystemDialog alert:@"已添加"]:nil;
            [arr writeToFile:kFilePath atomically:YES];
        }
        self.mers = arr;
    }else{
        //创建沙盒文件
        [_currentDatas writeToFile:kFilePath atomically:YES];
        self.mers = _currentDatas;
    }
    
//    NSString *log = [NSString stringWithFormat:@"当前关注了%d个商家",self.mers.count];
//    [SystemDialog alert:log];
    MyLog(@"当前关注%d个商家",self.mers.count);
    [self.tableView reloadData];
   */
}


@end
