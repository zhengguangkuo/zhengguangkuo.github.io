//
//  Account.m
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright wenguang 2014年. All rights reserved.
//

#import "MpayUser.h"

@implementation MpayUser

@synthesize user_id;

@synthesize realname;

@synthesize sex;

@synthesize marriage_state;

@synthesize birthday;

@synthesize idcard;

@synthesize telephone;

@synthesize mobile;

@synthesize email;

@synthesize home_addr;

@synthesize reg_date;

@synthesize nickname;


@end
