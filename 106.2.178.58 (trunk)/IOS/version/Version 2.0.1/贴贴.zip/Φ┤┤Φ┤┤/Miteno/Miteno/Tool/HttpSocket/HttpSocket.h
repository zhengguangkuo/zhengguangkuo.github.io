//
//  HttpTool.h
//  Miteno
//
//  Created by HWG on 14-3-13.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Foundation/Foundation.h>
#import <CFNetwork/CFNetwork.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import <netinet/in.h>
#import <arpa/inet.h>


@interface HttpSocket : NSObject
{
    NSInputStream    *inStream;
    NSOutputStream   *outStream;
    NSMutableData    *dataBuffer;
    
    BOOL             _hasEstablished;
    id               _currentObject;
    int              _numCondition;
    
    BOOL             _isFirstFourBytes;
    uint             remainingToRead;
}

-(void)requestData:(NSString *)requestString whoRequest:(id)currentObject;

-(void)manageData:(NSData *)receivedData;

-(void)startClient:(NSString*)service portNO:(int)ptn;

@end
