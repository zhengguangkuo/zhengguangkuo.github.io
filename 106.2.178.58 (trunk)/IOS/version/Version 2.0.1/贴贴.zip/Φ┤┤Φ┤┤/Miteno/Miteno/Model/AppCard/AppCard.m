//
//  BasicCard.m
//  M-Pay
//
//  Created by guorong on 14-2-24.
//  Copyright miteno 2014年. All rights reserved.
//

#import "AppCard.h"

@implementation MpayID

@synthesize user_id;
@synthesize app_id;

@end


@implementation MpayApp

@synthesize app_type;
@synthesize app_name;
@synthesize detail;
@synthesize pic_path;
@synthesize instName;

@end


@implementation AppCard

@synthesize ID;
@synthesize app_card_no;
@synthesize mpayApp;
@synthesize isDefault;


@end
