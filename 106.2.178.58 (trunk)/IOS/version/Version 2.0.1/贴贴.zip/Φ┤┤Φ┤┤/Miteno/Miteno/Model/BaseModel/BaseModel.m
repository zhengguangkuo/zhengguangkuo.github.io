//
//  BaseModel.m
//  M-pay(Model)
//
//  Created by HWG on 13-12-5.
//  Copyright (c) 2013年 miteno. All rights reserved.
//

#import "BaseModel.h"

@implementation BaseModel
- (id)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
    }
    return self;
}
@end
