//
//  BasicCard.h
//  M-Pay
//
//  Created by guorong on 14-2-24.
//  Copyright miteno 2014年. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Base.h"

@interface ID : Base

@property (nonatomic, copy)  NSString* user_id;
@property (nonatomic, copy)  NSString* c_iss_id;

@end

@class ID;
@class CouponIssuer;

@interface Credits : Base

@property (nonatomic, strong)  ID* creditsID;
@property (nonatomic, assign)  int credits;
@property (nonatomic, strong)  CouponIssuer* creditsIssuer;

@end


@interface CouponIssuer : Base

@property (nonatomic, copy) NSString* cname;

@end
