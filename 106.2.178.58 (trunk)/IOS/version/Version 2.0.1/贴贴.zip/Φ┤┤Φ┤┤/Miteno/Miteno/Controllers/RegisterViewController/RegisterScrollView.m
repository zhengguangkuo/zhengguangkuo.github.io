//
//  RegisterScrollView.m
//  Miteno
//
//  Created by HWG on 14-2-27.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "RegisterScrollView.h"

@implementation RegisterScrollView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
       [self initial];
    }
    return self;
}
#pragma mark 当RegisterScrollView从xib中创建完毕后会调用这个方法
- (void)awakeFromNib {
    [self initial];
}
#pragma mark 初始化
- (void)initial {
    self.contentSize = self.bounds.size;
    self.showsVerticalScrollIndicator = NO;
    self.scrollEnabled = YES;
    
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self endEditing:YES];
}

@end
