//
//  BasicCard.m
//  M-Pay
//
//  Created by guorong on 14-2-24.
//  Copyright miteno 2014年. All rights reserved.
//

#import "RespInfo.h"

@implementation RespInfo

@synthesize message;

@synthesize respcode;

@end
