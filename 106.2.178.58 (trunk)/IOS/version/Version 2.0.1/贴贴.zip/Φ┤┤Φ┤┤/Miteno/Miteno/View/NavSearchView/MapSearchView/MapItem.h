//
//  MapItem.h
//  Miteno
//
//  Created by wg on 14-3-31.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MapItem : UIButton

@end
