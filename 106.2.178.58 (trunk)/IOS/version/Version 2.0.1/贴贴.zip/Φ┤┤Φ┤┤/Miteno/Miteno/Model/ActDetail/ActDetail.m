//
//  ActDetail.m
//  Miteno
//
//  Created by HWG on 14-3-19.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "ActDetail.h"

@implementation ActDetail
- (id)initWithDict:(NSDictionary *)dict
{
    if (self = [super initWithDict:dict]) {
//        self.picPath = dict[@"pic_path"];
        self.dayLimit = dict[@"day_limit"];
        self.personLimit = dict[@"personal_limit"];
        self.maxPieces = dict[@"max_pieces"];
        self.content = dict[@"content"];
        self.startDate = dict[@"use_start_date"];
        self.endDate = dict[@"use_end_date"];
        self.address = dict[@"address"];
        self.telephone = dict[@"telephone"];
        self.couponIssuerId = dict[@"couponIssuerId"];
        self.detailMeg = dict[@"detail"];
    }
    return self;
}

@end
