//
//  AddressViewCell.h
//  Miteno
//
//  Created by HWG on 14-3-20.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "ActDetailCell.h"
@interface AddressViewCell : ActDetailCell
@property (nonatomic, strong)UILabel *header;
@property (nonatomic, strong)UILabel *content;
@property (nonatomic, strong)UIButton *queryMap;
@property (nonatomic, strong)UIImageView *horizontal;//横向
@property (nonatomic, strong)UIImageView *Vertical;//纵向
-(void)setContentText:(NSString *)text;
@end
