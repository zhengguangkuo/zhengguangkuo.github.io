#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>
#import <Foundation/Foundation.h>


@interface NSObject(parse)


- (void)ParseJsonToDictionary:(NSString*)Json
                        block:(void(^)(int Total, NSDictionary* dic))ParseBlock;

- (void)ParseJsonToMessage:(NSString*)Json block:(void(^)(void))success;

@end
