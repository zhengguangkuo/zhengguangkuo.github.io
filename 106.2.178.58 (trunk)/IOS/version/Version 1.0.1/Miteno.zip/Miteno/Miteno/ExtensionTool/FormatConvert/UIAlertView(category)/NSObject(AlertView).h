
@interface NSObject(AlertView)

- (void)DrawValidBox;

- (void)DrawInputTextBox:(NSString*)title input:(void(^)(NSString* txt))block;

-(void)RequestGetValid:(NSString*)text;
@end
