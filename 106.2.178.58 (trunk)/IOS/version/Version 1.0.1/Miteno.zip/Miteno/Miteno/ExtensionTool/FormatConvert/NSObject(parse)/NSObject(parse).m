#import "NSObject(parse).h"
#import "SystemDialog.h"
#import "NSDictionary(JSON).h"
#import "RespInfo.h"

@implementation NSObject(parse)
- (void)ParseJsonToDictionary:(NSString*)Json
                        block:(void(^)(int Total, NSDictionary* dic))ParseBlock
{
    id result = [NSDictionary dictionaryWithString:Json];
    if(!ChNil(result)&&[result isKindOfClass:[NSDictionary class]])
    {
        id Rows = [result objectForKey:@"rows"];
        id Counts = [result objectForKey:@"total"];
        
        if(!ChNil(Rows)&&[Rows isKindOfClass:[NSArray class]])
        {
            NSMutableArray* array = [[NSMutableArray alloc] initWithArray:Rows];
            for(id object in array)
            {
                NSDictionary* dic = (NSDictionary*)object;
                ParseBlock([Counts longValue], dic);
            }
        }
    }
}


- (void)ParseJsonToMessage:(NSString*)Json block:(void(^)(void))success
{
    id object = [NSDictionary dictionaryWithString:Json];
    NSDictionary* dic = (NSDictionary*)object;
    RespInfo* respObject = [[RespInfo alloc] initWithDictionary:dic];
    
    
    NSLog(@"respObject.message=%@",respObject.message);
    
       if(respObject.respcode!=nil)
    {
        if([respObject.respcode intValue]==0)
        {
            if(success)
                success();
        }

        if(respObject.message==nil)
      {
        if([respObject.respcode intValue]==0)
        {
            [respObject setMessage:@"请求成功"];
        }
        else
        {
            [respObject setMessage:@"请求失败"];
        }
      }
    }
    
    dispatch_async(dispatch_get_main_queue(),
    ^{
        UIView* MyKeyWindow = [[UIApplication sharedApplication] keyWindow];

        [MyKeyWindow makeToast:respObject.message];
    });
}


@end
