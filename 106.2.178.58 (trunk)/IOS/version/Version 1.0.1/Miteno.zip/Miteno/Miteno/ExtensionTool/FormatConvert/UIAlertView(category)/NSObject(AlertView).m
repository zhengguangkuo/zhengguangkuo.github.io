#import "NSObject(AlertView).h"
#import "UIButton(addtion).h"
#import "UIView(category).h"
#import "UIImage(addition).h"
#import "UICustAlertView.h"
#import "Config.h"
#import "HttpService.h"
#import "NSObject(UITextFieldDelegate).h"
#import "NSObject(parse).h"
#import "NSString(Additions).h"
#import "AppDelegate.h"

#define   kValideCode      221

//#define   kTelephoneNo     220

@implementation NSObject(AlertView)

- (void)DrawValidBox
{
    NSUserDefaults  *ud= [NSUserDefaults standardUserDefaults];
    [ud synchronize];
    
    BOOL flag = [ud boolForKey:@"ValideKey"];
    
    if(flag==NO)
  {
    [self initWithValidBox];
  }
}



- (void)DrawInputTextBox:(NSString*)title input:(void(^)(NSString* txt))block
{
    [self initWithInput:title input:block];
}



- (void)initWithInput:(NSString*)title input:(void(^)(NSString* txt))inputblock
{
    UIView* bgview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 40)];
    [bgview setBackgroundColor:[UIColor whiteColor]];
    
    UITextField* input = [[UITextField alloc] initWithFrame:CGRectMake(5, 2, 289, 34)];
    
    input.keyboardType = UIKeyboardTypeDefault;
    input.returnKeyType = UIReturnKeyDefault;
    
    [input setFont:[UIFont systemFontOfSize:15.0f]];
    
    [input setDelegate:self];
    
    input.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;

    [input ViewWithBorder:[UIColor orangeColor]];
    
    [bgview addSubview:input];
    
    
    dispatch_async(dispatch_get_main_queue(),
  ^{
      UICustAlertView*  alertview = [[UICustAlertView alloc]initWithAlertContent:bgview title:title];
        [alertview setYesBlock:
      ^{
          inputblock([input text]);
       }];
   });
}






- (void)initWithValidBox
{
     UIView* bgview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 38)];
     [bgview setBackgroundColor:[UIColor whiteColor]];

//    UITextField* input0 = [[UITextField alloc] initWithFrame:CGRectMake(2, 3, bgview.frame.size.width - 3, 32)];
//    input0.keyboardType = UIKeyboardTypeDefault;
//    input0.returnKeyType = UIReturnKeyDefault;
//    input0.placeholder = @"请输入手机号";
//    [input0 setText:@""];
//    [input0 setTag:kTelephoneNo];
//    [input0 setDelegate:self];
//    input0.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
//    [input0 setFont:[UIFont systemFontOfSize:15.0f]];
//    [input0  ViewWithBorder:[UIColor orangeColor]];
//    [bgview addSubview:input0];

    UITextField* input = [[UITextField alloc] initWithFrame:CGRectMake(2, 3, bgview.frame.size.width - 90, 32)];
     input.keyboardType = UIKeyboardTypeDefault;
     input.returnKeyType = UIReturnKeyDefault;
     input.placeholder = @"请输入验证码";
     [input setText:@""];
     [input setTag:kValideCode];
     [input setDelegate:self];
     input.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
     [input setFont:[UIFont systemFontOfSize:15.0f]];
     [input  ViewWithBorder:[UIColor orangeColor]];
     UIView *lview = [[UIView alloc]
     initWithFrame:CGRectMake(0.0, 0.0, 5.0, 32.0)];
     [input setLeftView:lview];
     input.leftViewMode = UITextFieldViewModeAlways;
     [bgview addSubview:input];
    
    
    
    
     UIButton*  pickButton = [UIButton ButtonWithParms:[UIColor blackColor] title:@"获取" bgnormal:[UIImage generateFromColor:[UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1]] imgHighlight:nil target:self action:@selector(RequestGetValid:)];
    
     [pickButton setFrame:CGRectMake(input.frame.origin.x + input.frame.size.width + 3, input.frame.origin.y, 80 , 32)];
     [pickButton ViewWithBorder:[UIColor lightGrayColor]];
     [bgview addSubview:pickButton];

      AppDelegate* app = [AppDelegate getApp];
      NSString* noStr = app.userAccout.Mobile;
      dispatch_async(dispatch_get_main_queue(),
     ^{
        UICustAlertView*  alertview = [[UICustAlertView alloc]initWithAlertContent:bgview title:@"验证码"];
        [alertview setYesBlock:^{
        [self RequestCheckValid:[input text] teleno:noStr];
        }];
      });
}


-(void)RequestGetValid:(id)sender
{
    AppDelegate* app = [AppDelegate getApp];
    NSString* noStr = app.userAccout.Mobile;
    UIButton*  btn = (UIButton*)sender;
    UIView*  bgView = btn.superview;
    UITextField*  txtfd = (UITextField*)[bgView viewWithTag:kValideCode];
    [txtfd resignFirstResponder];
    
//    UITextField*  txtfd2 = (UITextField*)[bgView viewWithTag:kTelephoneNo];
//    [txtfd2 resignFirstResponder];
    
    
//    UIView* MyKeyWindow = [[UIApplication sharedApplication] keyWindow];
//
//    NSString* teleno = [txtfd2 text];
//    if(IsEmptyString(teleno))
//    {
//        [MyKeyWindow makeToast:@"手机号不能为空!"];
//        return;
//    }
//    else
//    if(![NSString checkPhone:teleno])
//    {
//        [MyKeyWindow makeToast:@"号码格式不正确!"];
//        return;
//    }
    
    NSLog(@"get code");
    NSString*  validCodeURL =  [NSString stringWithFormat:@"%@mpayFront/getCode",  WEB_SERVICE_ENV_VAR];
    
    NSDictionary*  dic = [[NSDictionary alloc] initWithObjectsAndKeys:noStr,@"mobile", nil];
    
    HttpService*  tempservice = [HttpService HttpInitPostForm:validCodeURL
                                                         body:dic
                                                      withHud:YES];
    
    [tempservice  setDataHandler:^(NSString* data)
     {
         NSLog(@"response getcode str = %@",data);
           [self ParseJsonToMessage:data block:^{
           __block AppDelegate* app = [AppDelegate getApp];
           [app.userAccout setValideMobile:app.userAccout.Mobile];
        }];
     }
     ];
    [tempservice setErrorHandler:^(NSError* error) {
        
    }];
    
    [tempservice startOperation];
}




-(void)RequestCheckValid:(NSString*)ValidCode teleno:(NSString*)Teleno
{
    NSString*  validCodeURL =  [NSString stringWithFormat:@"%@mpayFront/checkValidateCode",  WEB_SERVICE_ENV_VAR];
    AppDelegate* app = [AppDelegate getApp];
    NSString* ValideMobile = app.userAccout.valideMobile;

//    if(IsEmptyString(Teleno))
//    {
//        UIView* MyKeyWindow = [[UIApplication sharedApplication] keyWindow];
//        [MyKeyWindow makeToast:@"手机号不能为空!"];
//        return;
//    }
//    else
//    if(![NSString checkPhone:Teleno])
//    {
//        UIView* MyKeyWindow = [[UIApplication sharedApplication] keyWindow];
//        [MyKeyWindow makeToast:@"请输入正确格式的手机号码!"];
//        return;
//    }
    
    
    if(IsEmptyString(ValidCode))
    {
        UIView* MyKeyWindow = [[UIApplication sharedApplication] keyWindow];
        [MyKeyWindow makeToast:@"验证码不能为空!"];
        return;
    }

    if(IsEmptyString(ValideMobile))
    {
        UIView* MyKeyWindow = [[UIApplication sharedApplication] keyWindow];
        [MyKeyWindow makeToast:@"请输入正确的验证码!"];
        return;
    }
    
    
    
    
    NSDictionary*  dic = [[NSDictionary alloc] initWithObjectsAndKeys:ValidCode,@"validateCode",/*Teleno,@"mobile",*/nil];
    
    HttpService*  tempservice = [HttpService HttpInitPostForm:validCodeURL
                                                         body:dic
                                                      withHud:YES];
    
    [tempservice  setDataHandler:^(NSString* data)
     {
          NSLog(@"data = %@",data);
         [self ParseJsonToMessage:data block:^{
         __block  NSUserDefaults  *ud= [NSUserDefaults standardUserDefaults];
            [ud setBool:YES forKey:@"ValideKey"];
         }];
     }
     ];
    [tempservice setErrorHandler:^(NSError* error) {
        UIView* MyKeyWindow = [[UIApplication sharedApplication] keyWindow];
        [MyKeyWindow makeToast:@"网络状况不佳"];
    }];
    
    [tempservice startOperation];
}

@end
