//
//  Config.h
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright wenguang 2014年. All rights reserved.
//

#ifndef __CONFIG_DEF__
#define __CONFIG_DEF__


//#define    kServiceBaseUrl   @"http://192.168.16.27:8092/miteno-mobile/"192.168.16.97:8080app.modepay.cn

//#define kBaseURL   @"http://192.168.16.27:8092/miteno-mobile/"

//#define  kBaseURL   @"http://192.168.16.97:8080/miteno-mobile/"

#define  kBaseURL    @"http://app.modepay.cn/miteno-mobile/"  //手机外网

//#define   kBaseURL  @"http://106.2.168.138:8890/miteno-mobile/"


// IPhone5 screen Adjust for UI
// When Size of Height less than 1136 return
// NO or Return Act Size

//设备信息
//判断是否是IOS7系统
#define IOS7 ([[[UIDevice currentDevice] systemVersion] floatValue]>= 7.0 ? YES : NO)

#define isRetina ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 960), [[UIScreen mainScreen] currentMode].size) : NO)

#define iPhone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)

#define kAppFrame [UIScreen mainScreen].applicationFrame

#define  kScreenBounds    [UIScreen mainScreen].bounds

#define ScreenHeight [[UIScreen mainScreen] bounds].size.height

#define ScreenWidth  [[UIScreen mainScreen] bounds].size.width
#define kPrinciple 64

//#define Selected_City_Code   @"selected_city_code"

//获取当前城市编码
#define kCityCode   @"cityCode"
//设置颜色
#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]
#define Black1      RGBA(73,73,73,1)
#define Black2      RGBA(153,153,153,1)
#define white1      [UIColor whiteColor]
#define white2      RGBA(242,242,242,1)
#define white3      RGBA(200,200,200,1)
#define Background  RGBA(206,206,206,1)
#define Orange      RGBA(235,138,66,1)
#define Blue        RGBA(76,147,241,1)

// 半透明
#define kGlobalBg [UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:0.5]
#define kGrayTabBg  [UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:0];

#define  kConnectFailure   @"网络状况不佳"
#define  kEndMeg           @"数据刷新完毕"
#define  ChNil(XXX)  [(NSNull*)XXX isKindOfClass:[NSNull class]]?YES:NO

#define  IOS7Y (IOS7?(CGFloat)kPrinciple:(CGFloat)0)

#define  ZeroY  (IOS7?(CGFloat)0:(CGFloat)0)

#define  TableExtraHeight (IOS7?(SIMULATOR==0?0:64):(CGFloat)0)

#define  MaxDevicesHeight  566  //iOS5以上 大屏幕高度

#define  kAdjustH (SIMULATOR==0?(64:0))

#define  kAdjustRate  ((CGFloat)(ScreenHeight/MaxDevicesHeight))


//#define  WEB_SERVICE_ENV_VAR   @"http://192.168.16.115:8090/miteno-mobile/"

//#define  WEB_SERVICE_ENV_VAR   @"http://www.nfclive.com.cn/miteno-mobile/"

//#define  WEB_SERVICE_ENV_VAR   @"http://192.168.16.97:8080/miteno-mobile/"

//#define    WEB_SERVICE_ENV_VAR   @"http://192.168.16.27:8092/miteno-mobile/"

#define   WEB_SERVICE_ENV_VAR    @"http://app.modepay.cn/miteno-mobile/"

//#define   WEB_SERVICE_ENV_VAR      @"http://106.2.168.138:8890/miteno-mobile/"

//------------- * * 数据库表 * * ---------
#define kAreaTab @"AREA_CODE"               //区域表
#define kCateTab @"MERCHANT_BUSSINESS_TYPE" //类别表

//------------------ path  method----------------------------//

#define    Key_Secrity_Login     @"mpayFront/j_spring_security_check"


#define    key_Secrity_Regist    @"mpayFront/reg"


#define    Key_Secrity_Check_Validate   @"mpayFront/checkValidateCode"


#define    Key_Secrity_UpdatePwd     @"mpayFront/updateUserPassword"


#define    Key_Secrity_UpdateMobile  @"mpayFront/updateMobile"


#define    Key_Basic_Card_Setting    @"mpayFront/getAllBaseCardOnUser"


#define    Key_Basic_Card_Binding    @"mpayFront/bindBaseCard"


#define    Kye_App_Card_Binded    @"mpayFront/getMpayAppsByUser"


#define    Key_App_Detail         @"mpayFront/mpayUserAppView"


#define    Key_Coupon_Receive     @"mobile/coupon/receiveActListByMerchAct"

//#define    Key_Coupon_Receive     @"mobile/coupon/receiveApplyCoupon/list"

#define    Key_Coupon_Return    @"mobile/coupon/couponReturn"

#define    Key_Coupon_All_List    @"mobile/coupon/actListByMerchAct"


#define    Key_App_Card_All_List  @"mpayFront/getAllMpayApps"


#define    Key_App_Card_Bind      @"mpayFront/bindMpayApp"


#define    Key_App_Card_Default   @"mpayFront/defaultApp"


#define    Key_Query_User_Info    @"mpayFront/mpayUserView"


#define    Key_Query_Point        @"mobile/coupon/creditsView"


#define    Key_Pkg_List           @"mpayFront/getAllPkg"


#define    Key_Pkg_Choose       @"mpayFront/bindBusiPackage"

//------------------ path  method----------------------------//


#endif







