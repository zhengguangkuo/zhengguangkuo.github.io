//
//  Settings.h
//  Miteno
//
//  Created by wg on 14-4-21.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Settings : NSObject

@end
