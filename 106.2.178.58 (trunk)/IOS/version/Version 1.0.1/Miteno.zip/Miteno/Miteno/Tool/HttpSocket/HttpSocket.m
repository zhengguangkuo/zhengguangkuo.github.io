//
//  HttpTool.m
//  Miteno
//
//  Created by HWG on 14-3-13.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "HttpSocket.h"

@implementation HttpSocket

-(void)requestData:(NSString *)requestString whoRequest:(id)currentObject
{

}


-(void)manageData:(NSData *)receivedData
{


}


-(void)startClient:(NSString*)service portNO:(int)ptn
{
    _hasEstablished = NO;
    CFReadStreamRef        readStream = NULL;
    CFWriteStreamRef    writeStream = NULL;
    
    BOOL isSuccess = YES;
    
    @try{
        CFStreamCreatePairWithSocketToHost(kCFAllocatorDefault,
                                           (CFStringRef)CFBridgingRetain(service),
                                           ptn,//服务器接收数据的端口
                                           &readStream,
                                           &writeStream);
        if(readStream && writeStream)
        {
            inStream = (NSInputStream *)CFBridgingRelease(readStream);
            outStream = (NSOutputStream *)CFBridgingRelease(writeStream);
        }

    }
    @catch (NSException *exception) {
        NSLog(@"can not create connection with host!");
        isSuccess = NO;
    }
    @finally
    {
        if(!isSuccess)
        {
            inStream = NULL;
            outStream = NULL;
        }
    }
}

@end
