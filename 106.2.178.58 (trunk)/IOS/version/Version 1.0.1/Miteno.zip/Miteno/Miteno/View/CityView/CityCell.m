//
//  CityCell.m
//  Miteno移动支付
//
//  Created by HWG on 13-11-19.
//  Copyright (c) 2013年 miteno. All rights reserved.
//

#import "CityCell.h"

@implementation CityCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self cellParts];
    }
    return self;
}
- (void)cellParts
{
    _icon = [UIButton buttonWithType:UIButtonTypeCustom];
    _icon.frame = CGRectMake(0, 0, 20, 20);
    [_icon setBackgroundImage:[UIImage imageNamed:@"normal_no_focus.png"] forState:UIControlStateNormal];
    [_icon setBackgroundImage:[UIImage imageNamed:@"normal_with_focus.png"] forState:UIControlStateSelected];
    _icon.adjustsImageWhenHighlighted = NO;
    self.accessoryView = _icon;
//    self.selectionStyle = UITableViewCellSelectionStyleNone;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
