//
//  MapSearchView.h
//  Miteno
//
//  Created by wg on 14-3-31.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol MapSearchViewDelegate <NSObject>

- (void)confirmResult:(NSString *)distance;
@end
@interface MapSearchView : UIView
@property (nonatomic, strong)UIView *bgView;
@property (nonatomic, assign)id <MapSearchViewDelegate>delegate;
- (void)show:(UIViewController *)ctrl;
- (void)dismiss;
@end
