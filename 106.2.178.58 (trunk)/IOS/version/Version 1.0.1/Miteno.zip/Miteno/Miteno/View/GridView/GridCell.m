//
//  GridCell.m
//  iGridViewDemo
//
//  Created by HWG on 14-2-17.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "GridCell.h"
#import "Mer.h"
#import "ImageButton.h"
#import "UIImage+Image.h"
#define kTagPrefix 15

@implementation GridCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        //按钮宽度
        CGFloat btnWidth = self.contentView.bounds.size.width / kColumn;
        for (int i = 0; i < kColumn;  i ++) {
            ImageButton *btn = [[ImageButton alloc] init];
            btn.tag = kTagPrefix + i;
            [btn addTarget:self action:@selector(itemClick:) forControlEvents:UIControlEventTouchUpInside];
            btn.frame = CGRectMake(btnWidth * i+3,5, btnWidth, kCellHeight-10);
            [self.contentView addSubview:btn];
        }

    }
    return self;
}

- (void)setRowShops:(NSArray *)shops
{
    int count = shops.count;
    for (int i = 0; i < kColumn; i ++) {
        ImageButton *btn = (ImageButton *)[self.contentView viewWithTag:kTagPrefix + i];
        
        //设置数据
        if (i < count) {
            btn.hidden = NO;
            Mer *mer = [shops objectAtIndex:i];
            //设置背景上的图片
            dispatch_queue_t queue;
            queue = dispatch_queue_create("com.example.operation", NULL);
            dispatch_async(queue, ^{
                NSString *urlString = mer.iconURL;
                NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:urlString]];
                
                UIImage *imge = [UIImage imageWithData:imageData];
                
                CGSize size = CGSizeMake(80,80);  // 设置尺寸
                UIImageView *im = [[UIImageView alloc] init];
                im.image = [UIImage createRoundedRectImage:imge size:size radius:15];// 设置radius
                dispatch_async(dispatch_get_main_queue(), ^{
                    mer.image = im.image;
                    [btn setImage:mer.image forState:UIControlStateNormal];
                });
                
            });
            [btn setTitle:mer.name forState:UIControlStateNormal];
        }else{
            btn.hidden = YES;
        }

    }
}
- (void)itemClick:(ImageButton *)item
{
    _blcok(item);
}
@end
