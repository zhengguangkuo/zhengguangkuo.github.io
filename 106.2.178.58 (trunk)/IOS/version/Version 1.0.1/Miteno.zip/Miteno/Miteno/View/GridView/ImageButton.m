//
//  ImageButton.m
//  iGridViewDemo
//
//  Created by HWG on 14-2-17.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "ImageButton.h"

#define kImageRatio 0.8     //图片比例

#define kMarginRatio 0.04    //图片之间的距离比例

#define kLabelRatio (1 - kImageRatio - 2 * kMarginRatio)

@implementation ImageButton

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        //设置文字属性
        [self setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        self.titleLabel.font = [UIFont systemFontOfSize:18];
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.adjustsFontSizeToFitWidth = YES;
//        [self setBackgroundImage:[UIImage imageNamed:@"leather_bg.png"] forState:UIControlStateNormal];
        [self setTitleColor:Orange forState:UIControlStateNormal];
        //图片保持原有尺寸
        self.imageView.contentMode = UIViewContentModeScaleAspectFit;
        self.adjustsImageWhenHighlighted = NO;
    }
    return self;
}

#pragma mark 设置文字的位置
- (CGRect)titleRectForContentRect:(CGRect)contentRect {
    return CGRectMake(0, contentRect.size.height * (kImageRatio + kMarginRatio)-10, contentRect.size.width, contentRect.size.height * kLabelRatio+10);
}
#pragma mark 设置图片的位置
- (CGRect)imageRectForContentRect:(CGRect)contentRect {
    return CGRectMake(0, contentRect.size.height * kMarginRatio-5, contentRect.size.width, contentRect.size.height * kImageRatio-5);
}

@end
