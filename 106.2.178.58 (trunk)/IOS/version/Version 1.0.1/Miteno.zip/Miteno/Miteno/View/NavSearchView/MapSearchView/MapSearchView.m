//
//  MapSearchView.m
//  Miteno
//
//  Created by wg on 14-3-31.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "MapSearchView.h"
#import "MapTableViewCell.h"
#import "MapItem.h"
#define kAlertMapW 300
#define KalertMapH 44*8+kRemainder
#define kRemainder 10
#define kCellRow 15
@interface MapSearchView ()<UITableViewDataSource,UITableViewDelegate,UIGestureRecognizerDelegate>
{
    UITableView     *_mapTab;
    UIButton        *_currentBtn;
    NSString        *_currentDistance;
    
}
@end
@implementation MapSearchView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.bounds = CGRectMake(0, 0, kAlertMapW, KalertMapH);
        self.center = CGPointMake(ScreenWidth/2, ScreenHeight/2);
        [self initCoustomViews];
    }
    return self;
}
- (void)show:(UIViewController *)ctrl
{
    [ctrl.view addSubview:self];
    _bgView = [[UIView alloc] init];
    _bgView.frame = [UIScreen mainScreen].applicationFrame;
    [_bgView setBackgroundColor:kGlobalBg];
    [ctrl.view.window insertSubview:_bgView atIndex:ctrl.view.window.subviews.count];
    [ctrl.view.window insertSubview:self aboveSubview:_bgView];
    //添加手势
    UITapGestureRecognizer *singleRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSwipeFrom:)];
    singleRecognizer.delegate = self;
    singleRecognizer.numberOfTouchesRequired = 1;
    [_bgView addGestureRecognizer:singleRecognizer];
}

- (void)initCoustomViews
{
    //添加tableview
    _mapTab = [[UITableView alloc] init];
    _mapTab.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height-44);
    _mapTab.scrollEnabled = NO;
    _mapTab.separatorStyle = UITableViewCellSeparatorStyleNone;
    _mapTab.contentSize = CGSizeMake(0, 0);
    _mapTab.delegate = self;
    _mapTab.dataSource = self;
    [self addSubview:_mapTab];
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}
#pragma mark -cell delegate
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static  NSString *identifier = @"Cell";
    MapTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell = [[MapTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    //设置数据
    NSString *distance = [NSString stringWithFormat:@"%dm",1000*(indexPath.row+1)];
    [cell.item setTitle:distance forState:UIControlStateNormal];
    cell.item.tag = indexPath.row+kCellRow;
    [cell.item addTarget:self action:@selector(selectedRow:)forControlEvents:UIControlEventTouchUpInside];
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 44;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 44+kRemainder;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *_headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, _mapTab.width, 44)];
    _headerView.backgroundColor = [UIColor blackColor];;
    
    // 用来显示标题
    UILabel *_headerLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, _mapTab.width, 44)];
    _headerLabel.backgroundColor = [UIColor clearColor];
    _headerLabel.textColor = [UIColor whiteColor];
    _headerLabel.font = [UIFont fontWithName:@"Arial" size:18];
    _headerLabel.text = @"请选择附近的商家:";
    [_headerView addSubview:_headerLabel];

    return _headerView;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    UIImageView *footerView = [[UIImageView alloc] initWithFrame:CGRectMake(0,0,_mapTab.width,kRemainder+44)];
    footerView.userInteractionEnabled = YES;
    footerView.image = [UIImage stretchImageWithName:@"common_card_middle_background_highlighted.png"];
    UIButton *confirm = [UIButton buttonWithType:UIButtonTypeCustom];
    //
    confirm.frame = CGRectMake(0,5, footerView.width/2+10, 44);
    [confirm setTitle:@"确定" forState:UIControlStateNormal];
    [confirm setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [confirm addTarget:self action:@selector(clickConfirm) forControlEvents:UIControlEventTouchUpInside];
    [confirm setBackgroundImage:[UIImage imageNamed:@"common_card_middle_background.png"] forState:UIControlStateNormal];
    
    UIButton *cancel = [UIButton buttonWithType:UIButtonTypeCustom];
    cancel.frame = CGRectMake(confirm.size.width-15,confirm.origin.y,confirm.width,44);
    [cancel setBackgroundColor:[UIColor clearColor]];
    [cancel setTitle:@"取消" forState:UIControlStateNormal];
    [cancel setBackgroundImage:[UIImage imageNamed:@"common_card_middle_background.png"] forState:UIControlStateNormal];
    [cancel setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [cancel addTarget:self action:@selector(clickCancel) forControlEvents:UIControlEventTouchUpInside];
    [footerView addSubview:confirm];
    [footerView addSubview:cancel];
    
    return footerView;
}
#pragma mark -确定
- (void)clickConfirm
{
    [_delegate confirmResult:_currentDistance];
    [self clickCancel];
}
#pragma mark -取消
- (void)clickCancel
{
    [UIView animateWithDuration:0.2 animations:^{
        [_bgView removeFromSuperview];
        [self removeFromSuperview];
    }];
    
}
- (void)selectedRow:(UIButton *)btn
{
    _currentBtn.selected = NO;
    
    btn.selected = YES;
    
    _currentBtn = btn;

    _currentDistance = btn.titleLabel.text;
}
- (void)dismiss
{
    [self clickCancel];
}
- (void)handleSwipeFrom:(UITapGestureRecognizer*)recognizer {
    
    [self clickCancel];
    //底下是刪除手势的方法
    [_bgView removeGestureRecognizer:recognizer];
}
@end
