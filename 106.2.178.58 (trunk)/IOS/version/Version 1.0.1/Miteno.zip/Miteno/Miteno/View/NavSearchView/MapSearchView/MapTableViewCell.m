//
//  MapTableViewCell.m
//  Miteno
//
//  Created by wg on 14-3-31.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "MapTableViewCell.h"
#import "MapItem.h"
@implementation MapTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self addSubviews];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}
- (void)setFrame:(CGRect)frame
{
    frame.origin.x = kMapSpace;
    frame.size.width -= 6*kMapSpace;
    [super setFrame:frame];
}
- (void)addSubviews
{
    self.item = [MapItem buttonWithType:UIButtonTypeCustom];
    self.item.bounds = CGRectMake(0, 0,140, 30);
    self.item.center = CGPointMake(self.width/2, self.height/2);
    UIImage *image = [UIImage imageNamed:@"normal_no_focus.png"];
    [self.item setImage:image forState:UIControlStateNormal];
    [self.item setImage:[UIImage imageNamed:@"normal_with_focus.png"] forState:UIControlStateSelected];
    [self.contentView addSubview:self.item];
}
@end
