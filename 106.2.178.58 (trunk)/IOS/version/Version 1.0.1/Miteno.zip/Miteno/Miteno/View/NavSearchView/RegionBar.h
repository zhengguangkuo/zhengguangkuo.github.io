//
//  RegionBar.h
//  Miteno
//
//  Created by HWG on 14-3-13.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ShareTableView;
typedef enum {
    kRegionButtonRegion = 110,
    kRegionButtonCategory
}kRegionButton;

@interface RegionBar : UIView<UIGestureRecognizerDelegate>
@property (nonatomic, strong) UIButton      * regionBtn;   //leftBtn
@property (nonatomic, strong) UIButton      * cateBtn; //rightBtn

@property (nonatomic, copy) void (^itemClickBlock)(UIButton *btnDock);     //监听标签dock点击事件

@end
