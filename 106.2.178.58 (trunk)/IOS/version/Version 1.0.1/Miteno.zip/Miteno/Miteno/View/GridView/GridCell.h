//
//  GridCell.h
//  iGridViewDemo
//
//  Created by HWG on 14-2-17.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kColumn 3          //设置每行的个数

#define kCellHeight 130      //cell行的高度
#import "ImageButton.h"

@interface GridCell : UITableViewCell

//设置这行的所有数据
- (void)setRowShops:(NSArray *)shops;
@property (nonatomic, copy) void (^blcok) (ImageButton *);
@end
