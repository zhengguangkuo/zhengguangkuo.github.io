//
//  NavItemView.m
//  Miteno
//
//  Created by wg on 14-4-12.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "NavItemView.h"

@implementation NavItemView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        [self addNavRightViews];
    }
    return self;
}
//导航rightItem
- (void)addNavRightViews
{
    CGFloat w = 30;
    CGFloat h = 30;
   _mapItem = [UIButton buttonWithType:UIButtonTypeCustom];
    _mapItem.frame = CGRectMake(0, 0, w, h);
    _mapItem.tag = kSignInButtonMap;
    [_mapItem setImage:[UIImage stretchImageWithName:@"Location.png"] forState:UIControlStateNormal];
    _textItem = [UIButton buttonWithType:UIButtonTypeCustom];
    _textItem.frame = CGRectMake(w+5, 0, w, h);
    _textItem.tag = kSignInButtonContent;
    [_textItem setImage:[UIImage imageNamed:@"Search.png"] forState:UIControlStateNormal];
    _areaItem = [UIButton buttonWithType:UIButtonTypeCustom];
    _areaItem.frame = CGRectMake(2*w+15, 0, w, h);
    _areaItem.tag = kSignInButtonRegion;
    
    [_areaItem setImage:[UIImage imageNamed:@"List.png"] forState:UIControlStateNormal];
    [self addSubview:_mapItem];
    [self addSubview:_textItem];
    [self addSubview:_areaItem];
}
@end
