//
//  CityCell.h
//  Miteno移动支付
//
//  Created by HWG on 13-11-19.
//  Copyright (c) 2013年 miteno. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CityCell : UITableViewCell
@property (strong, nonatomic)  UILabel      * cityName;   //城市名称
@property (strong, nonatomic)  UIButton     * icon;
@end
