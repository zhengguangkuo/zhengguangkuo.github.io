//
//  CityView.h
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import <UIKit/UIKit.h>

#define kSelectRow  @"selectRow"    
@protocol CityViewDelegate <NSObject>
@optional
- (void)cityCode:(NSString *)cityCode;                          //获取对应的编码
- (void)clickResultrow:(int)row;                                //获取行号
- (void)cityName:(NSString *)cityName;                          //获取城市名
//- (void)setCityIconBtnCenter;
@end
@interface CityView : UIView
@property (nonatomic, strong) UIView    * bgView;              
@property (nonatomic, strong) NSArray   * cityData;
@property (nonatomic, assign) id<CityViewDelegate>  delegate;
- (id)aboveCtroller:(UIViewController *)ctrl cityData:(NSArray *)cityData;

@end
