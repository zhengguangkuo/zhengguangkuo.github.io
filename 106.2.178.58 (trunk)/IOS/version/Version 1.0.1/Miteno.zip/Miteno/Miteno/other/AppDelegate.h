//
//  AppDelegate.h
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright wenguang 2014年. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseNavigationController.h"
#import "UserInfo.h"
#import "BMapKit.h"

@class UserInfo;
@class MpayUser;

@interface AppDelegate : UIResponder<UIApplicationDelegate>
{
    BMKMapManager *_mapManager;
}

@property (strong, nonatomic) UIWindow * window;

@property  (nonatomic, strong) BaseNavigationController* HomeNavigation;

@property  (nonatomic, strong) BaseNavigationController* MenuNavigation;

@property  (nonatomic, assign) BOOL isLogining;

@property  (nonatomic, strong) UserInfo* userAccout;
@property  (nonatomic, strong) IIViewDeckController* DeckController;

@property  (nonatomic, strong)  MpayUser* Account;

+ (AppDelegate*)getApp;

- (void)setLeftMenuDragState;

- (void)setLeftMenuEnable:(BOOL)bFlag;

- (void)setLeftMenuDragged;

- (NSString*)getCityCode;

- (void)RequestForUserInfo:(void(^)(void))finishBlock;





@end
