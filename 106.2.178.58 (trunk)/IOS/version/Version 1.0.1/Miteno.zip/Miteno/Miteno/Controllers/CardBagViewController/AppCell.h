//
//  ImageTableViewCell.h
//  NSOperationTest
//
//  Created by jhwang on 11-10-30.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@class AppCard;


@interface AppCell : UITableViewCell{

}
@property (strong, nonatomic) AppCard* mCard;

@property (weak, nonatomic) IBOutlet UIImageView *imageView;

- (id)initCustom;

- (void)SetCardObject:(AppCard*)card;

@end
