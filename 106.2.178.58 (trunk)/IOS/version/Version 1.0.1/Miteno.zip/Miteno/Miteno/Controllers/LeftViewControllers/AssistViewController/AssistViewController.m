//
//  AssistViewController.m
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "AssistViewController.h"

@interface AssistViewController ()

@end

@implementation AssistViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
           self.view.backgroundColor = [UIColor whiteColor];
           self.title = @"辅助功能";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    //[self SetNaviationTitleName:@"辅助功能"];
    //导航左边一个按钮
    UIBarButtonItem *item =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                            andTitle:nil
                                            andImage:[UIImage imageNamed:@"gb_button"]
                                           addTarget:self
                                           addAction:@selector(back)];
    
    UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];
    
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];

//    [UIBarButtonItem barButtonItemWithIcon:@"top_bt_bg.png" target:self action:@selector(back)];
	// Do any additional setup after loading the view.
}

//点击返回
- (void)back
{
    [self.viewDeckController toggleLeftViewAnimated:YES];
    
}

@end
