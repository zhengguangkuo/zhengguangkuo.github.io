//
//  RegisterViewController.m
//  Miteno移动支付
//
//  Created by HWG on 13-11-18.
//  Copyright (c) 2013年 miteno. All rights reserved.
//

#import "RegisterViewController.h"
#import "CityView.h"
#import "HomeViewController.h"
#import "UIKeyboardViewController.h"
#import "AreaCode.h"
#import "Utilities.h"
#import "AppDelegate.h"
//注册
#define kRegisterURL [NSString stringWithFormat:@"%@mpayFront/reg",kBaseURL]
//获取验证码
#define kCodeURL  [NSString stringWithFormat:@"%@mpayFront/getCode",kBaseURL]
#define CenterY self.evrifyCode.center.y
#define CenterX self.phone.center.x

@interface RegisterViewController ()<CityViewDelegate,UITextFieldDelegate,UIKeyboardViewControllerDelegate>
{
    CityView                    *   _cityView;
    UIButton                    *   _share;
    UIButton                    *   _currentBtn;
    UIKeyboardViewController    *   _keyBoardController; //keyBoardTool
    NSUserDefaults              *   _userDefaults;
    NSString                    *   _regex;
}

- (BOOL)matchPhoneNum:(NSString *)phoneNum;
@end

@implementation RegisterViewController
#pragma mark -生命周期方法。
- (void)viewWillAppear:(BOOL)animated{
    //设置键盘
   _keyBoardController=[[UIKeyboardViewController alloc] initWithControllerDelegate:self];
//	[_keyBoardController addToolbarToKeyboard];
}
#pragma mark -生命周期方法。
- (void)loadCityData{
    //不同push
    if (_cityData ==nil) {
        NSArray *db = [[DbHelper sharedDbHelper] cityName];
        NSMutableArray *cityData = [NSMutableArray array];
        for (NSDictionary *dict in db) {
            AreaCode *areaCode = [[AreaCode alloc] initWithDict:dict];
            [cityData addObject:areaCode];
        }
        _cityData = cityData;
    }
}
//-(void)viewDidLayoutSubviews
//{
//    if (isRetina) {
//        self.cityIcon.center = CGPointMake(self.cityIcon.center.x, CenterY-275);
//        self.cityLabel.center = CGPointMake(self.cityLabel.center.x, CenterY-275);
//        self.phone.center = CGPointMake(CenterX, CenterY-225);
//        self.phoneLabel.center = CGPointMake(self.phoneLabel.center.x, CenterY-225);
//        self.passWord.center = CGPointMake(CenterX, CenterY-175);
//        self.passWordLabel.center = CGPointMake(self.passWordLabel.center.x, CenterY-175);
//        self.verifyPassword.center = CGPointMake(CenterX, CenterY-125);
//        self.verifyPassWordLabel.center = CGPointMake(self.verifyPassWordLabel.center.x, CenterY-125);
//        self.email.center = CGPointMake(CenterX, CenterY-75);
//        self.emailLabel.center = CGPointMake(self.emailLabel.center.x, CenterY-75);
//        self.evrifyCode.center = CGPointMake(self.evrifyCode.center.x, CenterY-25);
//        self.codeLabel.center = CGPointMake(self.codeLabel.center.x, CenterY);
//        self.getCode.center = CGPointMake(self.getCode.center.x, CenterY);
//        self.promptLabel.center=CGPointMake(self.promptLabel.center.x, self.promptLabel.center.y-40);
//        self.yesBtn.center = CGPointMake(self.yesBtn.center.x, self.yesBtn.center.y-75);
//        self.noBtn.center = CGPointMake(self.noBtn.center.x, self.noBtn.center.y-75);
//    }
//
//}
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.registerView.contentSize = self.view.frame.size;
    self.registerView.scrollEnabled = YES;
    [self loadCityData];
    MyLog(@"cityCode:%@",[AppDelegate getApp].userAccout.City_Code);
    _userDefaults = [NSUserDefaults standardUserDefaults];
    NSInteger *row = [[_userDefaults objectForKey:kSelectRow] integerValue];
    [self setNavTheme:row];
    
    self.phone.delegate = self;
    
    _regex=@"(^[a-zA-Z\u4e00-\u9fa5]{1}[\\u4E00-\\u9FA5\\uF900-\\uFA2D\\w]{1,15}$)";
    
    //判断密码是否匹配
    _regex = @"(^[\\w]{6,16}$)";
    //城市选择背景
    [_cityIcon setAllStateBg:@"choosebar_press_down_highlight.png"];
}
#pragma mark -初始化导航栏主题
- (void)setNavTheme:(int)index
{
    self.title = @"用户注册";
    //导航左边item
    UIBarButtonItem *item =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                            andTitle:nil
                                            andImage:[UIImage imageNamed:@"gb_button"]
                                           addTarget:self
                                           addAction:@selector(back)];
    
    UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];
    
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];
    //[UIBarButtonItem barButtonItemWithIcon:@"top_bt_bg.png" target:self action:@selector(back)];
    if (index==0) {
        AreaCode *area = _cityData[index];
        [self.cityIcon setTitle:area.area_name forState:UIControlStateNormal];
    }else{
        AreaCode *area = _cityData[index];
        [self.cityIcon setTitle:area.area_name forState:UIControlStateNormal];
    }

}
- (void)back
{
    NSMutableArray *navArray = [NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    UIViewController *homeViewCtrl = [navArray objectAtIndex:0];
    [self.navigationController popToViewController:homeViewCtrl animated:YES];
}
#pragma mark 选择城市
- (IBAction)changeCityIcon:(id)sender
{
    _cityView = [[CityView alloc] aboveCtroller:self cityData:_cityData];
    _cityView.delegate = self;
}
- (void)clickResultrow:(int)row{
    [self setNavTheme:row];
}
- (void)cityCode:(NSString *)cityCode
{
//    _cityCode = cityCode;

}
- (void)cityName:(NSString *)cityName
{
//    [self.cityIcon setTitle:cityName forState:UIControlStateNormal];
}
-(void)setCityIconBtnCenter
{
//        self.cityIcon.center = CGPointMake(self.cityIcon.center.x, CenterY-250);
    
}
#pragma mark-初始化数据
#pragma mark -确定
- (IBAction)certainBtn:(id)sender
{
    //    [self initStandardView];
    //判断账号是否匹配
//    NSString *regex=@"(^[a-zA-Z\u4e00-\u9fa5]{1}[\\u4E00-\\u9FA5\\uF900-\\uFA2D\\w]{1,15}$)";
    /*
    if([_userName.text isEqualToString:@""]||_userName.text==nil){
        [SystemDialog alert:@"请输入账号"];
        return;
    }
    if (![_userName.text isMatchedByRegex:regex]) {
        [SystemDialog alert:@"账号应为4-16位英文、数字或中文！且首字母不能为数字！"];
        return;
    }else{
        int addLength = 0;                              //字符串中的汉字个数
        NSString *temp = nil;
        regex = @"^([\u4e00-\u9fa5]$)";
        int nowLength = _userName.text.length;      //当前长度
        
        //遍历账号 每拿到一个汉字就将账号的长度+1
        for (int i = 0; i < nowLength ; i++) {
            temp = [_userName.text substringWithRange:NSMakeRange(i, 1)];
            //判断字符是否是汉字
            if ([temp isMatchedByRegex:regex]) {
                addLength++;
            }
        }
        nowLength += addLength;
        if (nowLength < 4 || nowLength > 16) {
            [SystemDialog alert:@"账号应为4-16位英文、数字或中文！且首字母不能为数字！"];
            return;
        }
        
    }
     */
    //判断手机号
//    NSString * regexPhone = @"^((13[0-9])|(147)|(15[^4,\\D])|(18[0,5-9]))\\d{8}$";
//    if (_phone.text==nil||[_phone.text isEqualToString:@""]) {
//        [SystemDialog alert:@"请输入手机号！\n"];
//        return;
//    }
//    
//    if (![_phone.text isMatchedByRegex:regexPhone]) {
//        [SystemDialog alert:@"手机号格式不正确！\n"];
//        return;
//    }
    if (![self matchPhoneNum:_phone.text]) {
        return;
    }
    //判断密码是否匹配
//    regex = @"(^[\\w]{6,16}$)";
//    if(_passWord.text==nil||[_passWord.text isEqualToString:@""]){
//        [SystemDialog alert:@"请输入密码"];
//        return;
//    }
//    if (![_passWord.text isMatchedByRegex:regex]) {
//        [SystemDialog alert:@"密码应为6-16位数字或字母！"];
//        return;
//    }
    if (![self comparePassWord]) {
        return;
    }
    //判断确认密码
//    if (_verifyPassword.text==nil||[_verifyPassword.text isEqualToString:@""]) {
//        [SystemDialog alert:@"请输入确认密码！"];
//        return;
//    }
//    if (![_verifyPassword.text isMatchedByRegex:regex]) {
//        [SystemDialog alert:@"确认密码应为6-16位数字或字母！"];
//        return;
//    }
//    if (![_passWord.text isEqualToString:_verifyPassword.text]) {
//        [SystemDialog alert:@"两次密码输入不一致，请重新输入！"];
//        return;
//    }
    if (![self compareVerifyPassword]) {
        return;
    }
    //判断邮箱
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    if (_email.text==nil||[_email.text isEqualToString:@""]) {
//        [SystemDialog alert:@"请输入您的邮箱！\n"];
//        return;
    }
    if (![_email.text isMatchedByRegex:emailRegex]) {
//        [SystemDialog alert:@"邮箱格式不正确！\n"];
//        return;
    }
    
    //判断验证码
    if (_evrifyCode.text==nil||[_evrifyCode.text isEqualToString:@""]) {
        [SystemDialog alert:@"请获取验证码"];
        return;
    }
//    if (_evrifyCode.text.length!=4) {
//        [SystemDialog alert:@"请输入正确的验证码"];
//        return;
//    }
    //加密格式
    NSString *appendPassWord = [NSString stringWithFormat:@"%@{%@}",_passWord.text,_phone.text];
    //md5加密
    NSString *md5PassWord = [appendPassWord md5Encrypt];
//    NSString *cityName = [_cityIcon titleForState:UIControlStateNormal];
//    NSString *cityCode = [[DbHelper sharedDbHelper] queryCityCode:cityName];
    NSString *cityCode = [AppDelegate getApp].userAccout.City_Code;
    NSDictionary *dict = @{@"User_id":_phone.text,
                           @"password":md5PassWord,
                           @"mobile":_phone.text,
                           @"email":_email.text,
                           @"city":cityCode,
                           @"valid_code":_evrifyCode.text};
    NSLog(@"注册信息:%@",dict);
    
    //请求服务
    [self requestServer:kRegisterURL dict:dict];
}
#pragma mark -获取验证码
- (IBAction)getCode:(id)sender
{
    if ([self matchPhoneNum:_phone.text]) {
        [self.view endEditing:YES];
        [SystemDialog alert:@"请求已发送..."];
        [self performSelector:@selector(request) withObject:nil afterDelay:3.7];
//        if (_evrifyCode.text==nil) {
//            //        [SystemDialog alert:@"请输入验证码"];
//        }else{
//            [SystemDialog alert:@"请求已发送..."];
//            [self performSelector:@selector(request) withObject:nil afterDelay:3.7];
//        }
    }
}
- (void)request{

    //判断手机号
//    if ([self matchPhoneNum:_phone.text]) {
        NSDictionary *dict = @{@"mobile":_phone.text};
        //发送请求
        [self requestServer:kCodeURL dict:dict];
//    };
}
//请求服务
- (void)requestServer:(NSString *)url dict:(NSDictionary *)registerDatas
{
    HttpService *tempservice = [HttpService  HttpInitPostForm:url
                                                         body:registerDatas
                                                      withHud:YES];
    [tempservice  setDataHandler:^(NSString *data)
     {
         NSLog(@"regist data = %@",data);
         NSDictionary *dict = [data objectFromJSONString];
//         //注册成功
//         if ([[dict objectForKey:@"respcode"] integerValue]==0) {
//             [SystemDialog alert:[dict objectForKey:@"message"]];
//             NSLog(@"get the message after successful registration:%@",[dict objectForKey:@"message"]);
//             if ([Utilities isEmpty:[dict objectForKey:@"message"]]) {
//                 [SystemDialog alert:@"注册成功！"];
//             }
//         }
//         //注册失败
//         if ([[dict objectForKey:@"respcode"] integerValue]!=0) {
//             [SystemDialog alert:[dict objectForKey:@"message"]];
//         }
         BOOL isSuccess = [Utilities isEmpty:[dict objectForKey:@"message"]];

         if ([[dict objectForKey:@"respcode"] integerValue]==0 && isSuccess) {
             
             [SystemDialog alert:@"注册成功！"];
             
         } else {
             [SystemDialog alert:[dict objectForKey:@"message"]];
         }
     }];
    
    [self getError:tempservice];
    [tempservice startOperation];
}
//网络异常
- (void)getError:(HttpService *)tempservice
{
    [tempservice setErrorHandler:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [SystemDialog alert:kConnectFailure];
        });
    }];
}
#pragma mark -取消
- (IBAction)cancelBtn:(id)sender
{
    [self back];
}

- (IBAction)textFiledEditEnd:(id)sender {
    [self matchPhoneNum:self.phone.text];
}

- (IBAction)textFieldEditChanged:(id)sender {
}

- (IBAction)passWordTextFiledEditEnd:(id)sender {
    [self comparePassWord];
}

- (IBAction)verifyPasswordTextFieldEditChanged:(id)sender {
    [self compareVerifyPassword];
}

-(BOOL)comparePassWord
{
    
    if(_passWord.text==nil||[_passWord.text isEqualToString:@""]){
        SystemDialog *dialog = [[SystemDialog alloc]initWithText:@"请输入密码"];
        if (_keyBoardController.isKeyboardVisible) {
            [dialog setFrame:CGRectMake(dialog.frame.origin.x,ScreenHeight/2-20,dialog.frame.size.width,dialog.frame.size.height)];
        }
        [dialog show];
        
        return NO;
    }
    if (![_passWord.text isMatchedByRegex:_regex]) {
        SystemDialog *dialog = [[SystemDialog alloc]initWithText:@"密码应为6-16位数字或字母！"];
        if (_keyBoardController.isKeyboardVisible) {
            [dialog setFrame:CGRectMake(dialog.frame.origin.x,ScreenHeight/2-20,dialog.frame.size.width,dialog.frame.size.height)];
        }
        [dialog show];
        
        
        return NO;
    }
    return YES;
    
}
-(BOOL)compareVerifyPassword
{
    
    //判断确认密码
    if (_verifyPassword.text==nil||[_verifyPassword.text isEqualToString:@""]) {
        SystemDialog *dialog = [[SystemDialog alloc]initWithText:@"请输入确认密码！"];
        if (_keyBoardController.isKeyboardVisible) {
            [dialog setFrame:CGRectMake(dialog.frame.origin.x,ScreenHeight/2-20,dialog.frame.size.width,dialog.frame.size.height)];
        }
        [dialog show];
        
        return NO;
    }
    if (![_verifyPassword.text isMatchedByRegex:_regex]) {
        SystemDialog *dialog = [[SystemDialog alloc]initWithText:@"确认密码应为6-16位数字或字母！"];
        if (_keyBoardController.isKeyboardVisible) {
            [dialog setFrame:CGRectMake(dialog.frame.origin.x,ScreenHeight/2-20,dialog.frame.size.width,dialog.frame.size.height)];
        }
        [dialog show];
        
        return NO;
    }
    if (![_passWord.text isEqualToString:_verifyPassword.text]) {
        SystemDialog *dialog = [[SystemDialog alloc]initWithText:@"两次密码输入不一致，请重新输入！"];
        if (_keyBoardController.isKeyboardVisible) {
            [dialog setFrame:CGRectMake(dialog.frame.origin.x,ScreenHeight/2-20,dialog.frame.size.width,dialog.frame.size.height)];
        }
        [dialog show];
        
        return NO;
    }
    
    return YES;
}

- (IBAction)pn:(id)sender {
}
- (void)dealloc
{
    MyLog(@"dealloc%@",self.cityData);
}

- (BOOL)matchPhoneNum:(NSString *)phoneNum
{
    //判断手机号
    if (_phone.text==nil||[_phone.text isEqualToString:@""]) {
        SystemDialog *dialog = [[SystemDialog alloc]initWithText:@"请输入手机号！\n"];
        if (_keyBoardController.isKeyboardVisible) {
            [dialog setFrame:CGRectMake(dialog.frame.origin.x,ScreenHeight/2-20,dialog.frame.size.width,dialog.frame.size.height)];
        }
        [dialog show];
        return NO;
    }
    NSString * regexPhone = @"^((13[0-9])|(147)|(15[^4,\\D])|(18[0,5-9]))\\d{8}$";
    
    if (![_phone.text isMatchedByRegex:regexPhone]) {
        SystemDialog *dialog = [[SystemDialog alloc]initWithText:@"手机号格式不正确！\n"];
        if (_keyBoardController.isKeyboardVisible) {
            [dialog setFrame:CGRectMake(dialog.frame.origin.x,ScreenHeight/2-20,dialog.frame.size.width,dialog.frame.size.height)];
        }
        [dialog show];
        return NO;
    }
 
    return YES;
}
@end
