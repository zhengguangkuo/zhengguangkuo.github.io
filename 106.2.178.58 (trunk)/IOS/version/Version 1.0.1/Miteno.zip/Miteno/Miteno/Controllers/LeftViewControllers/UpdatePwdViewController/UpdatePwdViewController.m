//
//  AccountViewController.m
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "UpdatePwdViewController.h"
#import "UIView(category).h"
#import "NSObject(UITextFieldDelegate).h"
#import "UIButton(addtion).h"
#import "MpayUser.h"
#import "NSString(Additions).h"
#import "AppDelegate.h"
//#import "AccountViewController.h"
#import "MenuViewController.h"




@interface UpdatePwdViewController ()<UITextFieldDelegate,UITableViewDataSource,UITableViewDelegate>

@property  (nonatomic, strong)  UITableView*  PwdTableView;

@property  (nonatomic, strong)  NSMutableArray* dataArray;

@end


@implementation UpdatePwdViewController

@synthesize PwdTableView;

@synthesize dataArray;

//@synthesize Account;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"修改密码";
        self.view.backgroundColor = [UIColor whiteColor];
        self.dataArray = [[NSMutableArray alloc] initWithObjects:@"原密码",@"新密码",@"确认密码",nil];
//        self.Account = [[MpayUser alloc] init];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self  NavigationViewBackBtn];

    UITapGestureRecognizer*tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(ResignKeyBoard)];
    [self.view addGestureRecognizer:tap];


    self.PwdTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, 320, 300 + TableExtraHeight) style:UITableViewStylePlain];
    [PwdTableView setDataSource:self];
    [PwdTableView setDelegate:self];
    [PwdTableView setScrollEnabled:NO];
    [PwdTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [PwdTableView setBackgroundColor:[UIColor clearColor]];
    [self.view addSubview:self.PwdTableView];
    
    UIImage* LightImage = [UIImage imageNamed:@"btn_bg_light"];
    UIButton*  okBtn = [UIButton ButtonWithParms:[UIColor whiteColor] title:@"确认" bgnormal:LightImage imgHighlight:nil target:self action:@selector(requestUpdatePwd)];
    [okBtn setFrame:CGRectMake(ScreenWidth/2 - 60, self.PwdTableView.frame.origin.y + PwdTableView.frame.size.height + 10, 120, 40)];
    [self.view addSubview:okBtn];
}


- (void)viewDidAppear:(BOOL)animated
{
    [super  viewDidAppear:YES];
    dispatch_async(dispatch_get_main_queue(),
    ^{
      UITextField* tfld = [self FiledForCell:0];
      [tfld becomeFirstResponder];
     });
}


- (void)ResignKeyBoard
{
    [[self FiledForCell:0] resignFirstResponder];
    
    [[self FiledForCell:1] resignFirstResponder];
    
    [[self FiledForCell:2] resignFirstResponder];
}





- (void)requestUpdatePwd
{
    NSString* oldPwd1 = [self FieldTextForCell:0];

    NSString* newPwd1 = [self FieldTextForCell:1];
    
    NSString* newPwd2 = [self FieldTextForCell:2];
    
    NSLog(@"oldpwd1 = %@",oldPwd1);
    
    
     if(IsEmptyString(oldPwd1)||IsEmptyString(newPwd1)||IsEmptyString(newPwd2))
   {
      [self.view makeToast:@"密码不能为空!"];
      return;
   }
    
     if(![NSString checkEqual:newPwd1 dest:newPwd2])
   {
      [self.view makeToast:@"新密码输入不一致!"];
      return;
   }
    
    AppDelegate* app = [AppDelegate getApp];
    
    NSString* oldPwd = [self Md5Encry:[self FieldTextForCell:0] userName:app.Account.user_id];
    
    NSString* newPwd = [self Md5Encry:newPwd1 userName:app.Account.user_id];
    
    NSString*  testURL =  [NSString stringWithFormat:@"%@%@",  WEB_SERVICE_ENV_VAR,Key_Secrity_UpdatePwd];
    NSLog(@"testURL = %@",testURL);
    
    NSDictionary* dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         oldPwd,@"originalpwd",
                         newPwd,@"newpwd",
 //                        Account.email,@"email",
                         nil];

    HttpService*  tempservice = [HttpService  HttpInitPostForm:testURL
                    body:dic
                    withHud:YES];
    
    [tempservice  setDataHandler:^(NSString* data)
     {
         NSLog(@"data = %@",data);
         
         [self ParseJsonToMessage:data block:^{
             
            dispatch_async(dispatch_get_main_queue(),
        ^{
             [self ResetPassWord:newPwd];
//             AccountViewController* AVCtr = (AccountViewController*)[self GetPreController];
//             [AVCtr setRefreshFlag:YES];
            AppDelegate* app = [AppDelegate getApp];
            [app.userAccout LogoutAccount];
            
            MenuViewController* MVC = (MenuViewController*)app.MenuNavigation.viewControllers[0];
            [MVC exitToHome];

         });
         
         }];
         
     }
     ];
     [tempservice startOperation];
}



- (void)ResetPassWord:(NSString*)pwd
{
    AppDelegate* app = [AppDelegate getApp];
    [app.userAccout setPassWord:pwd];
}


- (NSString*)FieldTextForCell:(int)Section
{
    UITextField* Field = [self FiledForCell:Section];
    [Field resignFirstResponder];
    return [Field text];
}


- (UITextField*)FiledForCell:(int)Section
{
    NSIndexPath* Path = [NSIndexPath indexPathForRow:0 inSection:Section];
    UITableViewCell* cell = [PwdTableView cellForRowAtIndexPath:Path];
    UITextField* Field = (UITextField*)[cell viewWithTag:5];
    return Field;
}



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [self.dataArray count];
}

-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    return 1;
}


-(UITableViewCell *)tableView:(UITableView *)tableView
		cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString*  groupTableIdentifier = @"PwdTable";
    UITableViewCell*  tempcell2 = nil;
    tempcell2 = [tableView dequeueReusableCellWithIdentifier:groupTableIdentifier];
    
    if(tempcell2==nil)
    {
        tempcell2 = [[UITableViewCell  alloc]  initWithStyle:UITableViewCellStyleDefault reuseIdentifier:groupTableIdentifier];
        tempcell2.selectionStyle = UITableViewCellSelectionStyleNone;

        UITextField* input = [[UITextField alloc] initWithFrame:CGRectMake(8, 8, 300, 40)];
        input.secureTextEntry = YES;
        input.keyboardType = UIKeyboardTypeDefault;
        input.returnKeyType = UIReturnKeyDefault;
        [input setDelegate:self];
        input.leftViewMode=UITextFieldViewModeAlways;
        input.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 3, 40)];

        
        input.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        [input setFont:[UIFont systemFontOfSize:15.0f]];
        [input  ViewWithBorder:[UIColor orangeColor]];
        [tempcell2.contentView addSubview:input];
        [input setTag:5];
    }
    
    return tempcell2;
	
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
 	UIView*  tempview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 36)];
    tempview.backgroundColor = [UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1];
    UILabel* titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(4, 2, 150, 32)];
    [titleLabel setFont:[UIFont systemFontOfSize:14.0f]];
    [titleLabel setTextColor:[UIColor blackColor]];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [tempview addSubview:titleLabel];
    
    NSString* titleStr = self.dataArray[section];
    
    [titleLabel setText:titleStr];
    
    return tempview;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 36.0f;
}

@end
