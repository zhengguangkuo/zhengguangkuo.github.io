//
//  AppManagementViewController.h
//  Miteno
//
//  Created by HWG on 14-3-4.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "RootViewController.h"

@interface AppManagementViewController : RootViewController

@end
