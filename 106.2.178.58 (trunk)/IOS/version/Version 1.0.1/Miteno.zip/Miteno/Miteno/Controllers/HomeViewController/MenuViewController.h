//
//  MenuViewController.h
//  M-Pay
//
//  Created by guorong on 14-2-24.
//  Copyright miteno 2014年. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RootViewController.h"
#import "IIViewDeckController.h"


@interface MenuViewController : RootViewController<IIViewDeckControllerDelegate>

- (void)exitToHome;

@end
