//
//  DiscountMerchantCell.m
//  Miteno
//
//  Created by HWG on 14-3-11.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "DiscountMerchantCell.h"

@implementation DiscountMerchantCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
- (void)awakeFromNib{
    
    // 1.默认背景
    UIImageView *bg = [[UIImageView alloc] init];
    bg.image = [UIImage stretchImageWithName:@"elebusiness_list_bg.png"];
    self.backgroundView = bg;
    
    // 2.选中背景
    //    UIImageView *selectedBg = [[UIImageView alloc] init];
    //    selectedBg.image = [UIImage stretchImageWithName:@"common_card_background_highlighted.png"];
    //   self.selectedBackgroundView = selectedBg;
    
}
@end
