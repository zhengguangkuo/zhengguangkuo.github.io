//
//  MerchantViewController.h
//  Miteno
//
//  Created by HWG on 14-3-23.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "RootViewController.h"
@class DisCountMerch;
@interface MerchantViewController : RootViewController
@property (nonatomic, strong)DisCountMerch *disCountMerch;

@end
