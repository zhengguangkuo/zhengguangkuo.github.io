//
//  MerDetailViewController.h
//  Miteno
//
//  Created by HWG on 14-3-20.
//  Copyright (c) 2014年 wenguang. All rights reserved.
// 优惠劵商家详情

#import "RootViewController.h"
@interface MerDetailViewController : RootViewController
@property (nonatomic,copy) NSString *detailMeg;
@end
