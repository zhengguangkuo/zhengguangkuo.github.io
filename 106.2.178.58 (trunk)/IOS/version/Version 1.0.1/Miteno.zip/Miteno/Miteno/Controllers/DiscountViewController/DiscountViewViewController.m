//
//  DiscountViewViewController.m
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//
#import <QuartzCore/QuartzCore.h>
#import "DiscountViewViewController.h"
#import "NavItemView.h"
#import "Dock.h"
#import "CycleScrollView.h"
#import "CouponCell.h"
#import "DiscountMerchantCell.h"
#import "TopContent.h"
#import "UIImageView+DispatchLoad.h"
#import "Act.h"
#import "DisCountMerch.h"
#import "SearchView.h"
#import "MapSearchView.h"
#import "RegionBar.h"
#import "ShareTableView.h"
#import "ActDetailViewController.h"
#import "MerchantViewController.h"
#import "DbHelper.h"
#import "AreaCode.h"
#import "ShareTableView.h"
#import "AppDelegate.h"
#import "Utilities.h"
#import "MapsViewController.h"
#import "MerchantDet.h"
#import "BMKGeometry.h"
#import "NSTimer+Addition.h"
#import "DisMerViewController.h"

#define kBillboardHeight 150
#define KcellHeight      88
#define kTopNumber       1      //设置广告栏滚动的个数 kTopNumber > 2;
#define kSearhContent @"搜素内容不能为空"
#define kEndMore     @"已经是最后一页了..."
#define kshowMeg      @"未搜索到任何数据"
#define kLeftMeg    @"leftMegBar"
#define kRightMeg   @"rightMegBar"
//头部图片
#define kHeadIconURL [NSString stringWithFormat:@"%@mobile/coupon/getTopContent",kBaseURL]
//优惠劵列表（未登录）
#define kCouponListURL [NSString stringWithFormat:@"%@mobile/coupon/actListByMerchAct",kBaseURL]
//折扣商家列表
#define kMerchListURL [NSString stringWithFormat:@"%@mobile/coupon/merchMpayDiscountList/list",kBaseURL]
//优惠劵搜素
#define kCouponSearchURL [NSString stringWithFormat:@"%@mobile/coupon/queryRequirementActByMerchAct/list",kBaseURL]
//折扣商家搜素
#define kMerchSearchURL [NSString stringWithFormat:@"%@mobile/coupon/queryMerchMpayDiscountByRequirement/list",kBaseURL]
//距离范围内查询附近商户--未登陆
#define kMerchSearchByDistanceURL [NSString stringWithFormat:@"%@mobile/coupon/getNearMerchant/list",kBaseURL]
#define kMerchSearchByDistanceLoginURL [NSString stringWithFormat:@"%@mobile/coupon/getNearMerchantByLogin/list",kBaseURL]


@interface DiscountViewViewController ()<UITableViewDelegate,UITableViewDataSource,MJRefreshBaseViewDelegate,SearchViewDelegate,ShareTableViewDelegate,MapSearchViewDelegate>
{
    NavItemView          *  _itemView;          //导航rightItem
    Dock                 *  _dock;              //bar
    UITableView          *  _tableView;         //列表
    NSMutableArray       *  _headImages;        //所有头部图片
    MJRefreshHeaderView  *  _header;            //上拉
    MJRefreshFooterView  *  _footer;            //下拉
    NSMutableArray       *  _coupons;           //所有优惠劵
    NSMutableArray       *  _discountMerchs;    //折扣商家优惠信息
    MapSearchView        *  _mapSearch;         //地图search
    SearchView           *  _searchView;        //文字搜索
    RegionBar            *  _regionBar;         //区域、类别
    ShareTableView       *  _shareView;         //菜单
    int                     _stateSave;         //记录状态
    UIView               *  _tabBg;             //table背景
    BOOL                    _complete;
    BOOL                    _isShowMeg;
    
    MapsViewController          * _mapController;
    CLLocationManager           * _locatitonManager;
    CLLocationCoordinate2D        _userCoordinate;
    BOOL                          _isDiscount;
    /*
     优化
     */
    BOOL                _searchCouponData;
    BOOL                _searchDisData;
    NSInteger           _currentPageCou;
    long                _totalRowsCou;
    long                _totalrowsDis;
    NSInteger           _currentPageDis;
    BOOL                _isLoadMoreLeft;
    BOOL                _isLoadMoreRight;
    NSString          * _area;
    NSString          * _merchName;
    NSString          * _lv2Category;
    NSUserDefaults    * _userDefaults;
    BOOL                _clearnArchive;
    
    __block NSMutableDictionary *_dictionaryForMerchantId;
}

@property (nonatomic) __block NSInteger totalCount;
//广告栏
@property (nonatomic, strong) CycleScrollView *cycleView;
//获取头部图片加载完毕的数据
@property (nonatomic, copy) void (^blockHeadImages)(NSMutableArray *images);
@property (nonatomic, strong) ShareTableView *shareView;          //tabview

- (CLLocationDistance) getCLLocationDistance:(CLLocationCoordinate2D)merchantCoordinate;
- (void)getUserLocation;
@end

@implementation DiscountViewViewController
#pragma mark -生命周期
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {

//        _headImages = [NSMutableArray array];
        _coupons = [NSMutableArray array];
        _discountMerchs = [NSMutableArray array];
        _isLoadMoreLeft = NO;
        _isLoadMoreRight = NO;
        _searchCouponData = NO;
        _searchDisData = NO;
        _currentPageCou = 1;
        _currentPageDis = 1;
        _area = @"";
        _merchName = @"";
       _lv2Category = @"";
        _userDefaults = [NSUserDefaults standardUserDefaults];
        _clearnArchive = NO;
        //退出清理数据
        [_userDefaults removeObjectForKey:kRightMeg];
        [_userDefaults removeObjectForKey:kLeftMeg];
        [_userDefaults removeObjectForKey:kLeftRegionRow];
        [_userDefaults removeObjectForKey:kRightRegionRow];
        [_userDefaults removeObjectForKey:kLeftCateRow];
        [_userDefaults removeObjectForKey:kRightCateRow];

    }
    return self;
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    AppDelegate* app = [AppDelegate getApp];
    [app setLeftMenuEnable:NO];
    
    if (_complete==YES) {

        //开启timer
         [_cycleView.scrollView setContentOffset:CGPointMake(_cycleView.scrollView.frame.size.width, 0)];
        if (self.totalCount > 1) {
            [_cycleView.animationTimer setFireDate:[NSDate distantPast]];
        }

    }
  
//    if (_complete==YES) {
//
//        //开启timer
//        [_cycleView.animationTimer setFireDate:[NSDate distantPast]];
//        
//    }
    //item状态恢复
    _stateSave = 0;
}
- (void)viewDidDisappear:(BOOL)animated
{
    //关闭
    [_cycleView.animationTimer setFireDate:[NSDate distantFuture]];
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self getUserLocation];
    //设置导航
    [self setNavTheme];
    
    //添加dock
    [self addDock];
    
    //添加广告栏
    [self addBillboards];
    
    //加载广告栏
    [self loadTopContent];
    
    //添加tableView
    [self addTableViews:0];
    
    //添加下拉刷新和上拉加载更多
    _header = [[MJRefreshHeaderView alloc] init];
    _header.delegate = self;
    [_header beginRefreshing];
    _header.scrollView = _tableView;
    
    _footer = [[MJRefreshFooterView alloc] init];
    _footer.scrollView = _tableView;
    _footer.delegate = self;
    
//    _mapController = [[MapsViewController alloc]init];
//    _mapController.delegate = self;
    
    _dictionaryForMerchantId = [[NSMutableDictionary alloc]init];

}
#pragma mark 设置导航栏
- (void)setNavTheme
{
    self.title = @"折扣优惠";
    
    UIBarButtonItem *item =
    [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                            andTitle:nil
                                            andImage:[UIImage imageNamed:@"gb_button"]
                                           addTarget:self
                                           addAction:@selector(back)];
    
    UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];
    
    self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];
    //    [UIBarButtonItem barButtonItemWithBg:@"top_bt_bg.png" title:nil size:CGSizeMake(58, 34) target:self action:@selector(back)];
    
    _itemView = [[NavItemView alloc] init];
    _itemView.frame = CGRectMake(0, 15, 100, 30);
    [_itemView.mapItem addTarget:self action:@selector(selectInsideItem:) forControlEvents:UIControlEventTouchUpInside];
    [_itemView.textItem addTarget:self action:@selector(selectInsideItem:) forControlEvents:UIControlEventTouchUpInside];
    [_itemView.areaItem addTarget:self action:@selector(selectInsideItem:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:_itemView];
}
#pragma mark 添加dock
- (void)addDock
{
    CGFloat dockY =  0;
    if (IOS7) {
        dockY = SIMULATOR?64:0;
    }
    _dock = [[Dock alloc] initWithFrame:CGRectMake(0,dockY, ScreenWidth, kDockHeight)];
    NSString *nor = @"nav_image_bg.png";
    NSString *select = @"business_bg";
    [_dock addDockBtnWithBgIcon:nor selectIcon:select title:@"优惠劵"];
    [_dock addDockBtnWithBgIcon:nor selectIcon:select title:@"折扣商家"];
    [self.view addSubview:_dock];

    __unsafe_unretained DiscountViewViewController *discount =self;
    __block BOOL *tmpDiscount = YES;
    //监听item点击事件
    _dock.itemClickBlock = ^(int index){
        //切换city
        if (discount->_isShowMeg==FALSE) {
            [SystemDialog alert:kshowMeg];
            return ;
        }
        discount-> _header.hidden = NO;
        discount-> _footer.hidden = NO;
        
        [discount addTableViews:index];
        
        if (index == 1) {
            //复位刷新状态 清空数组
             discount-> _currentPageDis = 1;
             discount-> _isLoadMoreRight = NO;
            [discount->_discountMerchs removeAllObjects];
            [discount loadDiscountMerch];
            tmpDiscount = YES;
        }else{
            discount->_currentPageCou = 1;
            discount-> _isLoadMoreLeft = NO;
            [discount->_coupons removeAllObjects];
            [discount loadCouponContent];
            tmpDiscount = NO;
        }
    };
    _isDiscount = tmpDiscount;
}
#pragma mark -添加广告栏 并显示image
- (void)addBillboards
{
    NSMutableArray *headContent = [NSMutableArray array];
    CGFloat y = _dock.frame.origin.y;
    //添加广告栏
    self.cycleView = [[CycleScrollView alloc] initWithFrame:CGRectMake(0,_dock.height+y, ScreenWidth,kBillboardHeight) animationDuration:3.0f];
    [self.view addSubview:_cycleView];
    //监听加载完毕后取出头部图片
    __block CycleScrollView *cycle = self.cycleView;
    DiscountViewViewController *dis = self;
    self.blockHeadImages = ^(NSMutableArray *tops){
//        for (int i = 0; i<2; i++) {
//            UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, kBillboardHeight)];
//            if (i < tops.count) {
//                TopContent *top = tops[i];
//                [imageView setImageFromUrl:top.image_path];
//            }else{
//                imageView.image = [UIImage imageNamed:@"load.png"];
//            }
//            [headContent addObject:imageView];
//        }
        
        dis.totalCount = [tops count];
        
        UIImageView *imageView;
        for (TopContent *top in tops) {
            imageView = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, ScreenWidth, kBillboardHeight)];
            [imageView setImageWithURL:[NSURL URLWithString:top.image_path] placeholderImage:[UIImage imageNamed:@"load.png"]];
            
            [headContent addObject:imageView];
        }
        
        [cycle setDataForView:[tops count]];
        //获取第pageIndex个位置的contentView
        dis.cycleView.fetchContentViewAtIndex = ^UIView *(NSInteger pageIndex){
            return headContent[pageIndex];
        };
        //返回图片显示的页数
        dis.cycleView.totalPagesCount = ^NSInteger(void){
            return headContent.count;
        };
        dis.cycleView.TapActionBlock = ^(NSInteger index){
            MyLog(@"点击了第%d张",index);
        };
    };
}

#pragma mark 添加tableview
- (void)addTableViews:(int)index
{
    CGFloat h = SIMULATOR?64:0;
    UIImageView *imv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"leather_bg.png"]];
    
    if ([[AppDelegate getApp].userAccout.City_Code isEqualToString:@"110000"]) {
        _isShowMeg = TRUE;
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0,_cycleView.origin.y+_cycleView.height, ScreenWidth, ScreenHeight-_cycleView.frame.size.height-_dock.height-64) style:UITableViewStylePlain];

        _tableView.backgroundView = imv;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.tag = index;
        _header.beginRefreshingBlock = ^(MJRefreshBaseView *view){};
        _header.scrollView = _tableView;
        _footer.beginRefreshingBlock = ^(MJRefreshBaseView *view){};
        _footer.scrollView =  _tableView;
        [self.view addSubview:_tableView];
    }else{
        imv.frame = CGRectMake(0,_cycleView.origin.y+_cycleView.height, ScreenWidth, ScreenHeight-_cycleView.frame.size.height-_dock.height-h);
        [self.view addSubview:imv];
    }
    
}
#pragma mark -导航栏按钮点击事件
- (void)back{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark 监听item的点击事件
- (void)selectInsideItem:(id)sender
{
    UIButton *btn = (UIButton *)sender;
    if (_stateSave == 0) {
        //恢复原始状态
        btn.selected = NO;
    }
    btn.selected = !btn.isSelected;
    
    switch (btn.tag) {
        case kSignInButtonMap:{
            if (_stateSave==2||_stateSave==3) {
                btn.selected = YES;
            }
            _stateSave = 1;
            [self removeAllViews];
            [self clickSearchMap];                  //地图
        }
            break;
        case kSignInButtonContent:{
            if (_stateSave==1||_stateSave==3||_stateSave==4) {
                btn.selected = YES;
            }
            _stateSave = 2;
            [self removeAllViews];
            btn.selected==YES?[self clickSearchContent]:[_searchView removeFromSuperview];  //内容搜
        }
            break;
        case kSignInButtonRegion:{
            if (_stateSave==1||_stateSave==2||_stateSave==4) {
                btn.selected = YES;
            }
            _stateSave = 3;
            [self removeAllViews];
            btn.selected==YES?[self clickCitySearch]:[_regionBar removeFromSuperview];   //类型搜索
        }
            break;
        default:
            break;
    }
}
//删除所有添加的view
- (void)removeAllViews
{
    [_regionBar removeFromSuperview];
    [_searchView removeFromSuperview];
    [_shareView removeFromSuperview];
}
#pragma mark -mapSearch
- (void)clickSearchMap
{
    _mapSearch = [[MapSearchView alloc] init];
    _mapSearch.delegate = self;
    [_mapSearch show:self];
}

//mapSearchDelegate
- (void)confirmResult:(NSString *)distance
{
    MyLog(@"selected:%@",distance);
    if (!distance) {
        [SystemDialog alert:@"搜索范围不能为空！"];
        return;
    }
    if (!_mapController) {
        _mapController = [[MapsViewController alloc]init];
        _mapController.delegate = self;
    }
    
//    _mapController.centerCoordinate = _userCoordinate;
    //    [self.navigationController pushViewController:_mapController animated:nil];
    [self presentViewController:_mapController animated:NO completion:nil];
    
    //_isShowMeg:yes-->BeiJing,no-->ShangHai
    if (_isShowMeg) {
        [self getNearMerchantsWithDistance:[distance doubleValue]];
    }
}
#pragma mark -ContentSearch
- (void)clickSearchContent
{
    //添加搜索条
    CGFloat y = 0;
    if (IOS7) {
        y = SIMULATOR==0?0:64;
    }
    _searchView = [[SearchView alloc] initWithFrame:CGRectMake(0,y,ScreenWidth, 44)];
    _searchView.delegate = self;
    [self.view addSubview:_searchView];
}
// ContentSearchDelegate
- (void)searchContent:(UITextField *)field{
    _stateSave = 4;
    NSString* inputString = [field text];
    if (ChNil(inputString)||IsEmptyString(inputString)) {
        [SystemDialog alert:kSearhContent];
    }else{
        if (_isShowMeg==FALSE) {
            [SystemDialog alert:kshowMeg];
            return;
        }
        //        _header.hidden = YES;
        //        _footer.hidden = YES;
        //恢复数据，清空所有数组
        _currentPageCou = 1;
        _currentPageDis = 1;
        [_coupons removeAllObjects];
        [_discountMerchs removeAllObjects];
        _tableView.tag ==0 ?[self couponSearch:field.text catePara:0]:[self discountSearch:field.text catePara:0];
    }
}
#pragma mark -regionTypeSearch
- (void)clickCitySearch
{
    __unsafe_unretained DiscountViewViewController *dis = self;
    CGFloat y = 0;
    if (IOS7) {
        y = SIMULATOR==0?0:64;
    }
    _regionBar = [[RegionBar alloc] initWithFrame:CGRectMake(0,y, ScreenWidth, 44)];
    if ([_userDefaults objectForKey:kLeftMeg]!=nil) {
        [_regionBar.regionBtn setTitle:[_userDefaults objectForKey:kLeftMeg] forState:UIControlStateNormal];
    }else{
        [_regionBar.regionBtn setTitle:@"区域" forState:UIControlStateNormal];
    }
    if ([_userDefaults objectForKey:kRightMeg]!=nil) {
        [_regionBar.cateBtn setTitle:[_userDefaults objectForKey:kRightMeg] forState:UIControlStateNormal];
    }else{
        [_regionBar.cateBtn setTitle:@"类别" forState:UIControlStateNormal];
    }
    [self.view addSubview:_regionBar];
    _regionBar.itemClickBlock = ^(UIButton *btn){
        [dis addShareViews:btn];
    };
}
//表格搜索
- (void)addShareViews:(UIButton *)btnDock
{   //接收block参数 regionbar
    if (btnDock.selected==YES) {
        [_shareView hideDropDown:_regionBar];
    }else{
        [_shareView setHidden:YES];
//        _header.hidden = YES;
//        _footer.hidden = YES;
        CGFloat shareH = ScreenHeight-_regionBar.height-(SIMULATOR==0?0:64);
            _shareView = [[ShareTableView alloc] showDropDown:_regionBar height:shareH index:btnDock.tag];
            _shareView.delegate = self;
    }
}
//表格shareViewDelegate
- (void)clickResultText:(NSString *)text codeLevel:(NSString *)codeLevel flagTag:(int)flagTag
{
//    NSString *areaText = @"";
//    NSString *cateText = @"";
    if (flagTag == kRegionButtonRegion) {
        _regionBar.regionBtn.selected = YES;
            [_userDefaults setObject:text forKey:kLeftMeg];
        [_regionBar.regionBtn setTitle:text forState:UIControlStateNormal];
//        areaText = text;
    }else{
        _regionBar.cateBtn.selected = YES;
            [_userDefaults setObject:text forKey:kRightMeg];
        [_regionBar.cateBtn setTitle:text forState:UIControlStateNormal];
//        cateText = text;
    }
    [_shareView removeFromSuperview];
    
    if (_tableView.tag == 0) {
        //恢复数据 清空数组
        _currentPageCou = 1;
        [_coupons removeAllObjects];
        [self couponSearch:codeLevel catePara:flagTag];
    }else{
        //恢复数据 清空数组
        _currentPageDis = 1;
        [_discountMerchs removeAllObjects];
        [self discountSearch:codeLevel catePara:flagTag];
    }
}
#pragma mark -tableViewdelegate And datasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    MyLog(@"_tableView.tag : %d , _discountMerchs.count :%d",_tableView.tag,_discountMerchs.count);
    return _tableView.tag==0?_coupons.count:_discountMerchs.count;
}
#pragma mark -cell delegate
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    if (_tableView.tag == 0) {
        //优惠劵
        static  NSString *identifier = @"CouponCell";
        CouponCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell == nil) {
            cell = [[[NSBundle mainBundle]loadNibNamed:@"CouponCell" owner:self options:nil] lastObject];
        }

        if (!_coupons.count)             return cell;
        
        Act *act = _coupons[indexPath.row];
        
        cell.merchantMessage.text = act.merch_name;
        cell.cname.text = act.act_name;
        NSString *date = [NSString stringWithFormat:@"%@-%@",act.start_date,act.end_date];
        cell.deadline.text = date;
        cell.issueCount.text = [NSString stringWithFormat:@"已经发放%d张",act.issued_cnt];
        if (![act.pic_path isKindOfClass:[NSNull class]]) {
            [cell.icon setImageFromUrl:act.pic_path];
        };
        //商家坐标
        if (!ChNil(act.coordinate)) {
            CLLocationCoordinate2D coordinate = [Utilities stringToCLLocationCoordinate2D:act.coordinate];
            CLLocationDistance distance = [self getCLLocationDistance:coordinate];
            cell.distance.text = [NSString stringWithFormat:@"%.3fkm",distance];//act.coordinate;
        }
        return cell;
    }else{
        //折扣商家
        static  NSString *identifier = @"DiscountStore";
        DiscountMerchantCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        if (cell == nil) {
            cell = [[[NSBundle mainBundle]loadNibNamed:@"DiscountMerchantCell" owner:self options:nil] lastObject];
        }
        if (!_discountMerchs.count)             return cell;
        DisCountMerch *merch = _discountMerchs[indexPath.row];
        if (![merch.picPath isKindOfClass:[NSNull class]]) {
            
            [cell.icon setImageFromUrl:merch.picPath];
        }
        CGFloat discount = [merch.discount floatValue];
        cell.merchantDiscount.text = [NSString stringWithFormat:@"%.1f折",discount*10] ;
        cell.merchantName.text = merch.merchant.cName;
        cell.distance.text = [NSString stringWithFormat:@"%f",merch.merchant.distance];
        return cell;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return KcellHeight;
}
//push vc
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self removeAllViews];
    if (_tableView.tag == 0) {
        if (_coupons.count>0) {
        ActDetailViewController *actDetail = [[ActDetailViewController alloc] init];
            
            actDetail.act = _coupons[indexPath.row];
            [self.navigationController pushViewController:actDetail animated:YES];
        }
    }else{
        if (_discountMerchs.count>0) {
            MerchantViewController *merchantVc = [[MerchantViewController alloc] init];
            merchantVc.disCountMerch= _discountMerchs[indexPath.row];
            [self.navigationController pushViewController:merchantVc animated:YES];
            
        }
    }
}
#pragma mark -代理方法名(上拉、下拉刷新)
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    if (_header == refreshView) { // 下拉
        if (_tableView.tag == 0) {
            //加载优惠劵列表
            [self loadCouponContent];
        }else{ //加载折扣商家
            [self loadDiscountMerch];
        }
    } else { // 上拉
        if (_tableView.tag == 0) {
            [self loadUpCouponContent];
        }else{//加载折扣商家
            [self loadUpDiscountMerch];
        }
    }
}
- (void)dealloc
{
    [_header free];
    [_footer free];

}
#pragma mark -requestData
//头部图片
- (void)loadTopContent
{
    if (!_headImages) {
        _headImages = [NSMutableArray array];
    }
    HttpService  *tempservice = [HttpService  HttpInitPostForm:kHeadIconURL
                                                          body:nil
                                                       withHud:NO];
    [tempservice setDataHandler:^(NSString *data) {
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *arr = dicts[@"rows"];
        for (NSDictionary *dict in arr) {
            
            TopContent *top = [[TopContent alloc] initWithDict:dict];
            [_headImages addObject:top];
        }
        if (_headImages) {
            self.blockHeadImages(_headImages);
            _complete = YES;
        }
    }];
    [tempservice startOperation];
    [self getError:tempservice];
}

//优惠劵列表 下拉加载最小的
- (void)loadCouponContent
{
    //如果没有最新数据停止刷新
    if (_isLoadMoreLeft==YES) {
        [self performSelector:@selector(endLoadData:) withObject:kEndMeg afterDelay:0.5f];
        return;
    }
    if (_currentPageCou>1) {
        _currentPageCou = 1;
    }
    NSDictionary *dict = @{@"page":[NSNumber numberWithInteger:1]};
    HttpService  *tempservice = [HttpService  HttpInitPostForm:kCouponListURL
                                                          body:dict
                                                       withHud:YES];
    
    [tempservice setDataHandler:^(NSString *data) {
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *arr = dicts[@"rows"];
        NSMutableArray *coupons = [NSMutableArray array];
        for (NSDictionary *dict in arr) {
            Act *act = [[Act alloc] initWithDict:dict];
            [coupons addObject:act];
        }
        _coupons = coupons;
        //优惠劵总条数
        long total = [dicts[@"total"] integerValue];
        MyLog(@"优惠劵列表:total = %ld",total);
        _totalRowsCou = total;
        //刷新表格
        [_tableView reloadData];
        [_header endRefreshing];
        if (_coupons.count==0) {
            [_header setHidden:YES];
            [_footer setHidden:YES];
            [SystemDialog alert:kshowMeg];
        }else{
        [SystemDialog alert:kEndMeg];
        }
        }];
    
    [tempservice startOperation];
    [self getError:tempservice];
}
//优惠劵列表 上拉加载较大的
- (void)loadUpCouponContent
{
    //最后一页 停止刷新
    if (_coupons.count >= _totalRowsCou) {
        _isLoadMoreLeft = YES;
        [self performSelector:@selector(endLoadData:) withObject:kEndMore afterDelay:0.5f];
        return;
    }
    _currentPageCou+=1;
    NSString *URL =  _searchCouponData?kCouponListURL:kCouponSearchURL;

    NSDictionary *dict = @{@"page":[NSNumber numberWithInt:_currentPageCou],
                           @"merchName":_merchName,
                           @"area":_area,
                           @"lv2Category":_lv2Category};
    HttpService  *tempservice = [HttpService  HttpInitPostForm:URL                                                                                                       body:dict withHud:YES];
    
    [tempservice setDataHandler:^(NSString *data) {
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *arr = dicts[@"rows"];
        NSMutableArray *coupons = [NSMutableArray array];
        for (NSDictionary *dict in arr) {
            Act *act = [[Act alloc] initWithDict:dict];
            [coupons addObject:act];
        }
        [_coupons addObjectsFromArray:coupons];
        MyLog(@"加载更多-%d",_coupons.count);
        //刷新表格
        [_tableView reloadData];
        [_footer endRefreshing];

    }];

    [tempservice startOperation];
    [self getError:tempservice];
}
//折扣商家 下拉加载最小的
- (void)loadDiscountMerch{
    
    //如果没有最新数据停止刷新
    if (_isLoadMoreRight==YES) {
        [self performSelector:@selector(endLoadData:) withObject:kEndMeg afterDelay:1.5f];
        return;
    }
    //未加载完所有时 重新加载
    if (_currentPageDis>1) {
        _currentPageDis = 1;
    }
    NSDictionary *dict = @{@"page":@"1"};
    HttpService  *tempservice = [HttpService  HttpInitPostForm:kMerchListURL
                                                          body:dict
                                                       withHud:YES];
    [tempservice setDataHandler:^(NSString *data) {
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *arr = dicts[@"rows"];
        NSMutableArray *newMerch = [NSMutableArray array];
        for (NSDictionary *dict in arr) {
            DisCountMerch *merch = [[DisCountMerch alloc] initWithDict:dict];
            [newMerch addObject:merch];
        }
        _discountMerchs = newMerch;
        
        //折扣商家总条数
        long total = [dicts[@"total"] integerValue];
        MyLog(@"折扣商家列表:total = %ld",total);
        _totalrowsDis = total;
        //隐藏上拉、下拉
        [self hiddrenRefresh:_discountMerchs];
        //刷新表格
        [_tableView reloadData];
        [_header endRefreshing];
        if (_discountMerchs.count == 0) {
            _header.hidden = YES;
            _footer.hidden = YES;
            [SystemDialog alert:kshowMeg];
        }else{
            _discountMerchs.count==0?:[SystemDialog alert:kEndMeg];
        }
        
    }];
    [tempservice startOperation];
    [self getError:tempservice];
    
}
//折扣商家 上拉加载较大的
- (void)loadUpDiscountMerch{
    //最后一页 停止刷新
    if (_discountMerchs.count >= _totalrowsDis) {
        _isLoadMoreRight = YES;
        [self performSelector:@selector(endLoadData:) withObject:kEndMore afterDelay:0.5f];
        return;
    }
    NSString *URL =  _searchDisData?kMerchListURL:kCouponSearchURL;
    _currentPageDis+=1;
    NSDictionary *dict = @{@"page":[NSNumber numberWithInt:_currentPageDis],};
    HttpService  *tempservice = [HttpService  HttpInitPostForm:URL
                                                          body:dict
                                                       withHud:YES];
    [tempservice setDataHandler:^(NSString *data) {
        
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *arr = dicts[@"rows"];
        NSMutableArray *newMerch = [NSMutableArray array];
        for (NSDictionary *newDict in arr) {
            DisCountMerch *merch = [[DisCountMerch alloc] initWithDict:newDict];
            [newMerch addObject:merch];
        }
        [_discountMerchs addObjectsFromArray:newMerch];
        //刷新表格
        [_tableView reloadData];
        [_footer endRefreshing];
        
    }];
    [tempservice startOperation];
    [self getError:tempservice];
}
//************************ 整合代码 ********************************
#pragma mark -搜索
//按距离搜素商家
- (void)getNearMerchantsWithDistance:(double)distance
{
    long row = 10;
    int num = 1;
    if (_discountMerchs.count) {
        int current = _discountMerchs.count/row;
        num = current + 1;
    }
    NSString *page = [NSString stringWithFormat:@"%d",num];
    NSString *rows = [NSString stringWithFormat:@"%ld",row];
    NSString *point = [Utilities CLLocationCoordinate2DToString:_userCoordinate];
    NSString *actOrdisFlag = _isDiscount ? @"actMer" : @"disMer";
    NSDictionary *dict = @{@"page":page,
                           @"rows":rows,
                           @"point":point,
                           @"merchantDistance":[NSString stringWithFormat:@"%f",distance],
                           @"actOrDisFlag":actOrdisFlag};//actMer/disMer
    BOOL isLogin = [AppDelegate getApp].isLogining;
    NSString *url = isLogin ? kMerchSearchByDistanceLoginURL : kMerchSearchByDistanceURL;
    HttpService  *tempservice = [HttpService  HttpInitPostForm:url
                                                          body:dict
                                                       withHud:YES];
    
    [tempservice setDataHandler:^(NSString *data) {
        MyLog(@"json 字符串：%@",data);
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *arr = dicts[@"rows"];

        NSMutableArray *annotations = [[NSMutableArray alloc]init];
        for (NSDictionary *newDict in arr) {
            MerchantDet *merch = [[MerchantDet alloc] initWithDictionary:newDict];
            if (ChNil(merch.coordinate)) {
                continue;
            }
            NSArray *array = [[NSArray alloc]initWithObjects:merch.coordinate,merch.cName, nil];
            [annotations addObject:array];

            [_dictionaryForMerchantId setObject:merch forKey:merch.coordinate];
        }
        [_mapController addAnnotationViews:annotations center:_userCoordinate];
    }];
    [tempservice startOperation];
    [self getError:tempservice];
}
//优惠劵搜索
- (void)couponSearch:(NSString *)coupon catePara:(int)catePara
{
    _header.hidden = YES;
    _searchCouponData = YES;
    if (_stateSave==4) {
        //文字搜索
        _merchName = coupon;
    }else{
        //区域、类别
        if (catePara == kRegionButtonRegion) {
            _area = coupon;
        }else{
            _lv2Category = coupon;
        }
    }
    NSDictionary *dict = @{@"merchName"  : _merchName,
                           @"area"       : _area,
                           @"lv2Category": _lv2Category};
    
    HttpService  *tempservice = [HttpService  HttpInitPostForm:kCouponSearchURL
                                                          body:dict
                                                       withHud:YES];
    [tempservice setDataHandler:^(NSString *data) {
        
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *arr = dicts[@"rows"];
        NSMutableArray *newMerch = [NSMutableArray array];
        for (NSDictionary *newDict in arr) {
            Act *act = [[Act alloc] initWithDict:newDict];
            [newMerch addObject:act];
        }
        _coupons = newMerch;
        //总条数
        long total = [dicts[@"total"] integerValue];
        //总条目改变
        _totalRowsCou = total;
        [self getResultRows:_totalRowsCou];
        
        [_tableView reloadData];
        [_footer endRefreshing];
        
    }];
    [tempservice startOperation];
    [self getError:tempservice];
}
//折扣商家搜索
- (void)discountSearch:(NSString *)discount catePara:(int)catePara
{
    _searchDisData = YES;
    if (_stateSave == 2||_stateSave == 4) {
        //文字搜索
        _merchName = discount;
    }else{
        if (catePara == kRegionButtonRegion) {
            _area = discount;
        }else{
            _lv2Category = discount;
        }
    }
    NSDictionary *dict = @{@"merchName"  : _merchName,
                           @"area"       : _area,
                           @"lv2Category": _lv2Category};
    HttpService  *tempservice = [HttpService  HttpInitPostForm:kMerchSearchURL
                                                          body:dict
                                                       withHud:YES];
    [tempservice setDataHandler:^(NSString *data) {
        
        NSDictionary *dicts = [data objectFromJSONString];
        NSArray *arr = dicts[@"rows"];
        NSMutableArray *newMerch = [NSMutableArray array];
        for (NSDictionary *newDict in arr) {
            DisCountMerch *merch = [[DisCountMerch alloc] initWithDict:newDict];
            [newMerch addObject:merch];
        }
        _discountMerchs = newMerch;
        
        //总条数
        long total = [dicts[@"total"] integerValue];
        //总条数改变
        _totalrowsDis = total;
        [self getResultRows:_totalrowsDis];
        [_tableView reloadData];
        [_footer endRefreshing];
        
    }];
    [tempservice startOperation];
    
}

//toast
- (void)getResultRows:(long)total
{
    [_footer setHidden:YES];
    //总条数
    NSString *result = [NSString stringWithFormat:@"搜素到%ld个结果",total];
    NSString *mesg = total==0?@"未搜索到结果":result;
    if (total==0) {
//        [_header setHidden:YES];
        [_footer setHidden:YES];
    }else{
//        [_header setHidden:NO];
        [_footer setHidden:NO];
    }
    [SystemDialog alert:mesg];
}
- (void)hiddrenRefresh:(NSMutableArray *)data
{
    if (data==nil) {
        [_header setHidden:YES];
        [_footer setHidden:YES];
    }
}
//结束刷新
- (void)endLoadData:(NSString *)meg
{
    [_footer endRefreshing];
    [_header endRefreshing];
    [SystemDialog alert:meg];
}
- (void)getError:(HttpService *)tempservice
{
    [tempservice setErrorHandler:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [_footer endRefreshing];
            [_header endRefreshing];
            [SystemDialog alert:kConnectFailure];
        });
    }];
}

- (CLLocationDistance) getCLLocationDistance:(CLLocationCoordinate2D)merchantCoordinate
{
    CLLocationDistance dis = BMKMetersBetweenMapPoints(BMKMapPointForCoordinate(_userCoordinate), BMKMapPointForCoordinate(merchantCoordinate));
    return dis/1000.0;
}

- (void)getUserLocation
{
    if (!_locatitonManager) {
        _locatitonManager = [[CLLocationManager alloc]init];
    }
    if ([CLLocationManager locationServicesEnabled]) {
        _locatitonManager.delegate = self;
        _locatitonManager.desiredAccuracy = kCLLocationAccuracyBest;
        _locatitonManager.distanceFilter = 10.0f;
        [_locatitonManager startUpdatingLocation];
    }
}

#pragma location manager methods
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    CLLocation *location = [locations lastObject];
    _userCoordinate = BMKCoorDictionaryDecode(BMKBaiduCoorForWgs84(location.coordinate));
    [_locatitonManager stopUpdatingLocation];
    NSLog(@"userLocationCoordinate:%f,%f",_userCoordinate.latitude,_userCoordinate.longitude);
}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    //弹回shareview
    [_shareView hideDropDown:_regionBar];
    _regionBar.regionBtn.selected = YES;
    _regionBar.cateBtn.selected = YES;
}

#pragma MapsViewController delegate methods
- (void)clickPaopaoView:(BMKAnnotationView *)view
{
    
    if (([view.annotation coordinate].latitude == _mapController.mapView.userLocation.coordinate.latitude) &&
        ([view.annotation coordinate].longitude == _mapController.mapView.userLocation.coordinate.longitude)) {
        return;
    }
    
    DisMerViewController *dis = [[DisMerViewController alloc]init];
    [view.annotation coordinate];
    MerchantDet *merchant = [_dictionaryForMerchantId objectForKey:[Utilities CLLocationCoordinate2DToString:[view.annotation coordinate]]];
    dis.merchantDet = merchant;
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:dis];
    [_mapController presentViewController:nav animated:NO completion:nil];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    if (self.view.window == nil) {
        self.view = nil;
    }
}
@end

