//
//  ImageTableViewCell.m
//  NSOperationTest
//
//  Created by jhwang on 11-10-30.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//
#import "CardCell.h"
#import "NSObject(UITextFieldDelegate).h"
#import "BasicCard.h"
#import "UIImage(addition).h"
#import "UIImageView+DispatchLoad.h"
#import "UICustAlertView.h"
#import "UIView(category).h"
#import "HttpService.h"
#import "Config.h"
#import "SystemDialog+Show.h"
#import "NSDictionary(JSON).h"
#import "RespInfo.h"
#import "NSObject(AlertView).h"
#import "NSObject(parse).h"
#import "AppDelegate.h"


@class RootViewController;

@interface CardCell()


@property  (nonatomic, strong) BasicCard*  basic_object;

@end



@implementation CardCell
@synthesize ImageView;
@synthesize NameLabel;
@synthesize NumLabel;
@synthesize LockButton;
@synthesize Line;
@synthesize basic_object;

enum{
    BasicCardBind,
    BasicCardUnbind
};


-(id)initCustom
{
    self = [super init];
    if(self)
    {
        self = [[[NSBundle mainBundle] loadNibNamed:@"CardCell" owner:self options:nil] lastObject];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
       UIImage*  tempImage = [UIImage UIImageScretchImage:@"bt_bg"];
        [self.LockButton  setBackgroundImage:tempImage forState:UIControlStateNormal];
        [self.LockButton addTarget:self action:@selector(ClickEvent) forControlEvents:UIControlEventTouchUpInside];
        [self setBackgroundColor:[UIColor clearColor]];
        [self.contentView setBackgroundColor:[UIColor clearColor]];
    }
    return self;
}


-(void)setBasicCard:(BasicCard*)object
{
    self.basic_object = object;
    
    [NameLabel setText:@""];
    [NumLabel setText:@""];
    [ImageView setImage:[UIImage imageNamed:@"load.png"]];
    
    if(object.card_name)
        [NameLabel setText:object.card_name];

    if(object.card_no)
        [NumLabel  setText:object.card_no];
    
    if(object.pic_path)
    [ImageView setImageFromUrl:object.pic_path];

    [self.LockButton setTitle:@"" forState:UIControlStateNormal];
    
    if([object.bind_flag isEqualToString:@"0"])
    {
        [self.LockButton setTitle:@"绑定" forState:UIControlStateNormal];
        self.NumLabel.hidden = TRUE;
    }
    else
    if([object.bind_flag isEqualToString:@"1"])
    {
        [self.LockButton setTitle:@"解绑" forState:UIControlStateNormal];
        self.NumLabel.hidden = FALSE;
    }

}


-(void)ClickEvent
{
   NSUserDefaults  *ud = [NSUserDefaults standardUserDefaults];
   [ud synchronize];
   BOOL flag = [ud boolForKey:@"ValideKey"];
   
   if(flag==YES)
{
       if([self.LockButton.titleLabel.text
         isEqualToString:@"绑定"])
  {
      [self drawinputBox];
  }
     else
  {
      [self UnBind];
  }
}
    else
      [self DrawValidBox];

}


-(void)drawinputBox
{
    [self DrawInputTextBox:self.basic_object.input_tip input:^(NSString *txt) {
        [self BindCard:txt];
    }];
}



-(void)BindCard:(NSString*)card
{
     if(![basic_object.bind_flag isEqualToString:@"1"])
   {
      [self requestBindingBasicCard:card];
   }
}


-(void)UnBind
{
     if([basic_object.bind_flag isEqualToString:@"1"])
   {
      [self requestBindingBasicCard:self.basic_object.card_no];
   }
}


-(void)requestBindingBasicCard:(NSString*)cardNumber
{
    NSString*  testURL =  [NSString stringWithFormat:@"%@%@",  WEB_SERVICE_ENV_VAR,Key_Basic_Card_Binding];
    NSLog(@"testURL = %@",testURL);
    
       NSString* actionName = nil;
       NSInteger activeID;

       if(ChNil(cardNumber)||ChNil(basic_object.card_type))
    {
        return;
    }
    
       if(IsEmptyString(cardNumber))
    {
       [self makeToast:@"输入号码不能为空!"];
       return;
    }
    
    
       if([basic_object.bind_flag isEqualToString:@"1"]) //已绑定
    {
       actionName = @"unBind";
       activeID = BasicCardUnbind;
    }
       else
    {
       actionName = @"bind";
       activeID = BasicCardBind;
    }
    
    NSDictionary*  dic = [NSDictionary dictionaryWithObjectsAndKeys:
            cardNumber,@"card_no",
            basic_object.card_type,@"card_type",
            actionName,@"action",
        
        nil];
    
    HttpService*  tempservice = [HttpService  HttpInitPostForm:testURL
        body:dic
        withHud:YES];
    
    [tempservice setActiveMethodID:activeID];
    
    [tempservice  setReceiveHandler:^(NSString* data, NSInteger activateID)
     {
         [self ParseJsonToMessage:data block:^{
             [self SetCardValue:activateID cardNo:cardNumber];
         
         __block NSUserDefaults  *ud= [NSUserDefaults standardUserDefaults];
         [ud setBool:NO forKey:@"ValideKey"];

          __block AppDelegate* app = [AppDelegate getApp];
          [app.userAccout setValideMobile:@""];
       }];
         
     }
     ];
    
    [tempservice setErrorHandler:^(NSError* error)
    {
        dispatch_async(dispatch_get_main_queue(),
      ^{
          [self makeToast:@"网络状况不佳"];
       });
     }];
    
    [tempservice startOperation];
}


- (void)SetCardValue:(NSInteger)activateID cardNo:(NSString*)cardnum
{
   if(activateID==BasicCardBind)
  {
     [self.basic_object setBind_flag:@"1"];
     [self.basic_object setCard_no:cardnum];
  }
   else
  {
     [self.basic_object setBind_flag:@"0"];
     [self.basic_object setCard_no:NULL];
  }
     [self setBasicCard:self.basic_object];
}

@end
