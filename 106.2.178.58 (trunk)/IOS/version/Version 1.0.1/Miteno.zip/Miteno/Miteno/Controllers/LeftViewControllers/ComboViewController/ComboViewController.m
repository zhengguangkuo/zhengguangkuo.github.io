//
//  ComboViewController.m
//  Mpay
//
//  Created by HWG on 13-12-25.
//  Copyright (c) 2013年 miteno. All rights reserved.
//

#import "ComboViewController.h"
#define kSectionHeight 15
@interface ComboViewController ()
{
    UIButton *_share;           //cell里面的按钮
    UIButton *_currentBtn;      //当前选中的
}

- (void)back;
@end

@implementation ComboViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.title = @"套餐选择";
        self.view.backgroundColor = [UIColor whiteColor];
        //1.设置导航栏
        UIBarButtonItem *item =
        [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                                andTitle:nil
                                                andImage:[UIImage imageNamed:@"gb_button"]
                                               addTarget:self
                                               addAction:@selector(back)];

        UIBarButtonItem *negativeSpacer = [UIBarButtonItem barButtonItemWithNegativeSpacer];
        
        self.navigationItem.leftBarButtonItems = [NSArray arrayWithObjects:negativeSpacer,item, nil];
//        [UIBarButtonItem barButtonItemWithIcon:@"backButton.png" target:self action:@selector(back)];
        
        self.navigationItem.rightBarButtonItem =
        [UIBarButtonItem barButtonItemWithBackgroudImage:[UIImage imageNamed:@"top_bt_bg.png"]
                                                andTitle:@"订制"
                                                andImage:nil
                                               addTarget:self
                                               addAction:@selector(custom)];
//        [UIBarButtonItem barButtonItemWithBg:@"nav_image_bg.png" title:@"订制" size:CGSizeMake(70, 35) target:self action:@selector(custom)];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)back
{
    [self.viewDeckController toggleLeftViewAnimated:YES];
}
#pragma mark click定制
- (void)custom
{
    
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}

#pragma mark -每一行的cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static  NSString *ID = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:ID];
        cell.textLabel.font = [UIFont systemFontOfSize:20];
    }
    
    _share = [UIButton buttonWithType:UIButtonTypeCustom];
    
    [_share setBackgroundImage:[UIImage imageNamed:@"dot_black.png"] forState:UIControlStateNormal];
    [_share setBackgroundImage:[UIImage imageNamed:@"dot_orenge.png"] forState:UIControlStateSelected];
    _share.bounds = CGRectMake(0, 0, kSectionHeight, kSectionHeight);
    _share.tag = 10+indexPath.row;
    
    //    [_share addTarget:self action:@selector(share:) forControlEvents:UIControlEventTouchUpInside];
    // 高亮状态下不要改变图片颜色
    _share.adjustsImageWhenHighlighted = NO;
    
    cell.accessoryView = _share;
    
    NSString *message;
    switch (indexPath.row) {
        case 0:
            message = @"联通套餐0";
            break;
        case 1:
            message = @"联通套餐1";
            break;
        case 2:
            message = @"联通套餐2";
            break;
        case 3:
            message = @"联通套餐3";
            break;
            //        case 4:
            //            message = @"联通套餐4";
            //            break;
            //        case 5:
            //            message = @"联通套餐5";
            //            break;
            //        case 6:
            //            message = @"联通套餐6";
            //            break;
            //        case 7:
            //            message = @"联通套餐7";
            //            break;
            //        case 8:
            //            message = @"联通套餐8";
            //            break;
            //        case 9:
            //            message = @"联通套餐9";
            //            break;
            //        case 10:
            //            message = @"联通套餐10";
            //            break;
        default:
            break;
    }
    cell.textLabel.text = message;
    return cell;
}
//2.选中某一行Cell
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIButton *btn = (UIButton *)[tableView viewWithTag:(indexPath.row+10)];
    [self share:btn];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}
- (void)share:(UIButton *)btn{
    // 1.让当前的取消选中
    _currentBtn.selected = NO;
    
    btn.selected = YES;
    
    // 3.让新的变为当前选中
    _currentBtn = btn;
    
}

@end
