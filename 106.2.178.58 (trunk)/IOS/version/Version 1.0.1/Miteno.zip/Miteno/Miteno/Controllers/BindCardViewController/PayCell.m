//
//  ImageTableViewCell.m
//  NSOperationTest
//
//  Created by jhwang on 11-10-30.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//
#import "PayCell.h"
#import "PayCard.h"
#import "UIImageView+DispatchLoad.h"
#import "UIView(category).h"
#import "UIImage(addition).h"
#import "NSObject(AlertView).h"
//#import "RespInfo.h"
//#import "NSDictionary(JSON).h"
#import "SystemDialog.h"
#import "NSObject(parse).h"

@implementation PayCell

@synthesize LeftImageView;

@synthesize EnterNameLabel;

@synthesize CardNameLabel;

@synthesize  BindBtn;

@synthesize mPayCard;


enum{
    AppCardBind,
    AppCardUnbind
};



- (id)initCustom
{
    self = [super init];
    if(self)
    {
        self = [[[NSBundle mainBundle] loadNibNamed:@"PayCell" owner:self options:nil] lastObject];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        [self setBackgroundColor:[UIColor clearColor]];
        [self.contentView setBackgroundColor:[UIColor clearColor]];
        [self ViewWithBorder:[UIColor lightGrayColor]];
        
        UIImage*  tempImage = [UIImage UIImageScretchImage:@"bt_bg"];
        [self.BindBtn  setBackgroundImage:tempImage forState:UIControlStateNormal];
        [self.BindBtn addTarget:self action:@selector(ClickEvent) forControlEvents:UIControlEventTouchUpInside];
        [self setBackgroundColor:[UIColor clearColor]];
        [self.contentView setBackgroundColor:[UIColor clearColor]];
        
        self.LeftImageView.layer.masksToBounds = NO;
        self.LeftImageView.layer.borderWidth = 2.0;
        self.LeftImageView.layer.borderColor = [[UIColor clearColor] CGColor];
        self.LeftImageView.layer.cornerRadius = 7.0;
        
        self.LeftImageView.layer.shadowOffset = CGSizeMake(2.0f, 2.0f);
        self.LeftImageView.layer.shadowOpacity = 0.5;
        self.LeftImageView.layer.shadowRadius = 2.0;
        self.LeftImageView.layer.shadowColor = [[UIColor blackColor] CGColor];
    }
    return self;
}


- (void)SetPayCardObject:(PayCard*)card
{
    self.mPayCard = card;
    [self CleanData];
    [self.LeftImageView setImageFromUrl:mPayCard.pic_path];
    [self.CardNameLabel setText:mPayCard.app_name];
    [self.EnterNameLabel setText:mPayCard.instName ];
    
    NSString* stateName = nil;
    if([mPayCard.bind_flag isEqualToString:@"1"])
         stateName = @"解绑";
     else
         stateName = @"绑定";
  
     [self.BindBtn setTitle:stateName forState:UIControlStateNormal];
}


- (void)CleanData
{
    [self.LeftImageView setImage:[UIImage imageNamed:@"load.png"]];
    [self.CardNameLabel setText:@""];
    [self.EnterNameLabel setText:@""];
    [self.BindBtn setTitle:@"" forState:UIControlStateNormal];
}


-(void)ClickEvent
{
    //NSLog(@"click button");
    NSUserDefaults  *ud = [NSUserDefaults standardUserDefaults];
    [ud synchronize];
    BOOL flag = [ud boolForKey:@"ValideKey"];
    
    if(flag==YES)
    {
        if([self.BindBtn.titleLabel.text
            isEqualToString:@"绑定"])
        {
            [self drawinputBox];
        }
        else
        {
            [self UnBind];
        }
    }
    else
        [self DrawValidBox];

}


-(void)drawinputBox
{
    [self DrawInputTextBox:@"请输入卡号:"
        input:^(NSString *txt)
    {
        [self BindCard:txt];
    }];
}


-(void)BindCard:(NSString*)card
{
    if(![mPayCard.bind_flag isEqualToString:@"1"])
    {
       [self RequestBindAppCard:card];
    }
}


-(void)UnBind
{
    if([mPayCard.bind_flag isEqualToString:@"1"])
    {
       [self RequestBindAppCard:self.mPayCard.app_card_no];
    }
}


- (void)RequestBindAppCard:(NSString*)app_card_no
{
    NSString*  testURL =  [NSString stringWithFormat:@"%@%@",  WEB_SERVICE_ENV_VAR,Key_App_Card_Bind];
    NSLog(@"testURL = %@",testURL);
    
    NSString* actionName = nil;
    NSInteger activeID;
    
    if([mPayCard.bind_flag isEqualToString:@"1"]) //已绑定
    {
        actionName = @"unBind";
        activeID = AppCardUnbind;
    }
    else
    {
        actionName = @"bind";
        activeID = AppCardBind;
    }
    NSLog(@"mpcard.id = %@",mPayCard.ID);
    
    
    if(!ChNil(app_card_no)&&!ChNil(mPayCard.ID))
{
    NSDictionary*  dic = [NSDictionary dictionaryWithObjectsAndKeys:
                          app_card_no,@"app_card_no",
                          actionName,@"action",
                          mPayCard.ID,@"app_id",
                          nil];
    
    HttpService*  tempservice = [HttpService  HttpInitPostForm:testURL
                                                          body:dic
                                                       withHud:YES];
    
    [tempservice setActiveMethodID:activeID];
    
    [tempservice  setReceiveHandler:^(NSString* data, NSInteger activateID)
     {
         NSLog(@"bind data = %@",data);
         [self ParseJsonToMessage:data block:^{
             [self BindOperation:activateID appNO:app_card_no];
             
         __block  NSUserDefaults  *ud= [NSUserDefaults standardUserDefaults];
             [ud setBool:NO forKey:@"ValideKey"];

             [[NSNotificationCenter defaultCenter]postNotificationName:@"CellClick" object:nil];
         }];
     }
     ];
    
    [tempservice setErrorHandler:^(NSError* error)
     {
         dispatch_async(dispatch_get_main_queue(),
        ^{
            [self makeToast:@"网络状况不佳"];
         });
     }];
    
    [tempservice startOperation];
}
    
    
}


- (void)BindOperation:(NSInteger)ActivateID appNO:(NSString*)app_card_no
{
    if(ActivateID==AppCardBind)
{
    [self.mPayCard setBind_flag:@"1"];
    [self.mPayCard setApp_card_no:app_card_no];
}
    else
{
    [self.mPayCard setBind_flag:@"0"];
    [self.mPayCard setApp_card_no:NULL];
}

    [self SetPayCardObject:self.mPayCard];
}

@end
