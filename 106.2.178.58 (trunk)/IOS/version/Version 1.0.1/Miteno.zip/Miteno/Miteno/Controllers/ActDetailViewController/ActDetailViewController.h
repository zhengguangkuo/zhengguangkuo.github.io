//
//  ActDetailViewController.h
//  Miteno
//
//  Created by HWG on 14-3-18.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "RootViewController.h"
@class Act;
@interface ActDetailViewController : RootViewController
@property (nonatomic, strong)Act *act;
@property (nonatomic, assign)BOOL ClaimFlag;
@end
