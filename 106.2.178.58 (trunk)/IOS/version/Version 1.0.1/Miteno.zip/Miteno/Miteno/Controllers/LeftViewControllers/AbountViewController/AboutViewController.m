//
//  AboutViewController.m
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "AboutViewController.h"
#import "IIViewDeckController.h"
#import "FileManager.h"

@interface AboutViewController ()

@end

@implementation AboutViewController
@synthesize backStyle;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"业务介绍";
        self.backStyle = UILeftViewDragBack;
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    //[self SetNaviationTitleName:@"关于"];
    [self NavigationViewBackBtn];
    
    UITextView* textView = [[UITextView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    textView.font = [UIFont systemFontOfSize:15.0f];
    
    [textView  setBackgroundColor:[UIColor whiteColor]];
    [self.view  addSubview:textView];
    [textView setTextColor:[UIColor blackColor]];
    [textView setText:[FileManager readResource:@"about" type:@"txt"]];
    [textView setEditable:NO];
    
}


-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
}


//点击返回
- (void)backToPrevious
{
    if(self.backStyle==UILeftViewDragBack)
      [self.viewDeckController toggleLeftViewAnimated:YES];
    else
      if(self.backStyle==UIPopControllerBack)
      [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
