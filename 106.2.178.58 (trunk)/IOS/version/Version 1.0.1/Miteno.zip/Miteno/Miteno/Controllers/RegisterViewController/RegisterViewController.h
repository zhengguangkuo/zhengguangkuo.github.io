//
//  RegisterViewController.h
//  Miteno移动支付
//
//  Created by HWG on 13-11-18.
//  Copyright (c) 2013年 miteno. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegisterViewController : UIViewController<UITextFieldDelegate>

@property (strong, nonatomic) IBOutlet UITextField *userName;
@property (strong, nonatomic) IBOutlet UITextField *passWord;
@property (strong, nonatomic) IBOutlet UITextField *verifyPassword;
@property (strong, nonatomic) IBOutlet UITextField *phone;
@property (strong, nonatomic) IBOutlet UITextField *email;
@property (strong, nonatomic) IBOutlet UITextField *evrifyCode;
@property (weak, nonatomic) IBOutlet UIButton *getCode;
@property (weak, nonatomic) IBOutlet UIButton *yesBtn;
@property (weak, nonatomic) IBOutlet UIButton *noBtn;
@property (weak, nonatomic) IBOutlet UILabel *cityLabel;
@property (weak, nonatomic) IBOutlet UILabel *phoneLabel;
@property (weak, nonatomic) IBOutlet UILabel *passWordLabel;
@property (weak, nonatomic) IBOutlet UILabel *verifyPassWordLabel;
@property (weak, nonatomic) IBOutlet UILabel *emailLabel;
@property (weak, nonatomic) IBOutlet UILabel *codeLabel;
@property (weak, nonatomic) IBOutlet UITextView *promptLabel;

@property (strong, nonatomic) IBOutlet UIScrollView *registerView;
@property (weak, nonatomic) IBOutlet UIButton *cityIcon;//选择城市
@property (nonatomic, strong) NSArray   *  cityData;
//4个按钮的点击事件

- (IBAction)changeCityIcon:(id)sender;
- (IBAction)getCode:(id)sender;
- (IBAction)certainBtn:(id)sender;
- (IBAction)cancelBtn:(id)sender;
- (IBAction)textFiledEditEnd:(id)sender;
- (IBAction)textFieldEditChanged:(id)sender;
- (IBAction)passWordTextFiledEditEnd:(id)sender;
- (IBAction)verifyPasswordTextFieldEditChanged:(id)sender;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;

@end
