//
//  AccountViewController.m
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "AccountViewController.h"
#import "UpdatePwdViewController.h"
#import "UpdateMobileViewController.h"
#import "UpdateEmailViewController.h"
#import "MpayUser.h"
#import "AppDelegate.h"
//#import "UserInfo.h"


#define  AddObject(XXX) [self.ValueArray addObject:   (XXX==nil?@"":XXX)]


@interface AccountViewController ()<UITableViewDelegate,UITableViewDataSource>

@property  (nonatomic, strong)  UITableView*  UserTableView;

//@property  (nonatomic, strong)  NSMutableArray* UserArray;
//
@property  (nonatomic, strong)  NSMutableArray*  ValueArray;

@end



@implementation AccountViewController

@synthesize UserTableView;

//@synthesize UserArray;

@synthesize ValueArray;

@synthesize refreshFlag;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"我的账户";
        self.view.backgroundColor = [UIColor whiteColor];
//        self.UserArray = [[NSMutableArray alloc] init];
        self.ValueArray = [[NSMutableArray alloc] init];
        self.refreshFlag = YES;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self NavigationViewBackBtn];
    self.UserTableView = [[UITableView alloc] initWithFrame:kScreenBounds style:UITableViewStylePlain];
    [UserTableView setDataSource:self];
    [UserTableView setDelegate:self];
    [UserTableView setScrollEnabled:NO];
    [UserTableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [UserTableView setBackgroundColor:[UIColor whiteColor]];
    
    [self.view addSubview:self.UserTableView];
    // Do any additional setup after loading the view.
}


- (void)viewDidAppear:(BOOL)animated
{
    [super  viewDidAppear:YES];
    if(refreshFlag)
    {
      [self.ValueArray removeAllObjects];
      AppDelegate* app = [AppDelegate getApp];
      __block MpayUser* Account = app.Account;
      [app RequestForUserInfo:^{
          NSLog(@"self.user_id = %@",app.userAccout.UserName);
          NSLog(@"self.mobile = %@",app.userAccout.Mobile);
          NSLog(@"self.email = %@",app.userAccout.Email);
          NSLog(@"account.user_id = %@",app.Account.user_id);
          
          AddObject(Account.user_id);
          AddObject(@"********");
          AddObject(Account.mobile);
          AddObject(Account.email);
          [self.UserTableView reloadData];

      }];
      self.refreshFlag = NO;
    }
}



//- (void)RequestForUserInfo
//{
//    [self.UserArray removeAllObjects];
//    [self.ValueArray removeAllObjects];
//    
//    NSString*  testURL =  [NSString stringWithFormat:@"%@%@",  WEB_SERVICE_ENV_VAR,Key_Query_User_Info];
//    
//    HttpService*  tempservice = [HttpService  HttpInitPostForm:testURL
//                        body:nil
//                    withHud:YES];
//    
//    [tempservice setDelegate:self];
//    
//    [tempservice  setDataHandler:^(NSString* data)
//    {
//        NSLog(@"data = %@",data);
//        [self ParseJsonToDictionary:data block:^(int Total, NSDictionary *dic) {
//            if([self.UserArray count]==0)
//          {
//            __block MpayUser* object = [[MpayUser alloc] initWithDictionary:dic];
//            [self.UserArray addObject:object];
//            self.Account = self.UserArray[0];
//            AddObject(Account.user_id);
//            AddObject(@"********");
//            AddObject(Account.mobile);
//            AddObject(Account.email);
//            __block AppDelegate* app = [AppDelegate getApp];
//            [app.userAccout setEmail:Account.email];
//            [app.userAccout setMobile:Account.mobile];
//          }
//        }];
//        NSLog(@"self.account.name = %@",self.Account.user_id);
//        
//        dispatch_async(dispatch_get_main_queue(),
//      ^{
//          [self.UserTableView reloadData];
//      });
//    }
//    ];
//    [tempservice startOperation];
//}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 4;
}

-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    return 1;
}


-(UITableViewCell *)tableView:(UITableView *)tableView
		cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString*  groupTableIdentifier = @"GroupTable";
    UITableViewCell*  tempcell2 = nil;
    tempcell2 = [tableView dequeueReusableCellWithIdentifier:groupTableIdentifier];
    
    int n = indexPath.section;
    
    if(tempcell2==nil)
    {
        tempcell2 = [[UITableViewCell  alloc]  initWithStyle:UITableViewCellStyleDefault reuseIdentifier:groupTableIdentifier];
        tempcell2.selectionStyle = UITableViewCellSelectionStyleNone;
        UILabel* titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(7, 2, 300, 40)];
        [titleLabel setFont:[UIFont systemFontOfSize:14.0f]];
        [titleLabel setTextColor:[UIColor blackColor]];
        [titleLabel setBackgroundColor:[UIColor clearColor]];
        [tempcell2.contentView addSubview:titleLabel];
    
        [titleLabel setTag:2];
    
        if(n>0)
      {
        UIImage* image = [UIImage imageNamed:@"bianji_1"];
        UIImageView*  imageview = [[UIImageView alloc] initWithImage:image];
        [imageview  setSize:image.size];
        [imageview  setCenter:CGPointMake(300, 30)];
        [tempcell2.contentView addSubview:imageview];
        [imageview setTag:3];
      
      }
    
    }
    
        if([self.ValueArray count]>0)
    {
        UILabel* tempLabel = (UILabel*)[tempcell2.contentView viewWithTag:2];
        int n = indexPath.section;
        NSLog(@"self.ValueArray count = %d",[self.ValueArray count]);
        NSLog(@"n = %d",n);
        id value = self.ValueArray[n];
        if(value!=nil)
      {
        [tempLabel setText:[NSString stringWithFormat:@"%@",value]];
      }
    }
    
    return tempcell2;
	
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    int n = indexPath.section;
    if(n!=3)
       return 60;
    else
       return 200;
    
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
 	UIView*  tempview = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 36)];
    tempview.backgroundColor = [UIColor colorWithRed:0.8 green:0.8 blue:0.8 alpha:1];
    UILabel* titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(4, 2, 150, 32)];
    [titleLabel setFont:[UIFont systemFontOfSize:14.0f]];
    [titleLabel setTextColor:[UIColor blackColor]];
    [titleLabel setBackgroundColor:[UIColor clearColor]];
    [tempview addSubview:titleLabel];
    
    NSString* titleStr = nil;
    switch (section) {
       case 0:
    {
        titleStr = @"用户名";
    }
        break;
       case 1:
    {
        titleStr = @"密码";
    }
        break;
       case 2:
    {
        titleStr = @"手机号码";
    }
        break;
       case 3:
    {
        titleStr = @"电子邮箱";
    }
        break;
        
    default:
        break;
    }
    
    [titleLabel setText:titleStr];
    
    return tempview;
}



- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 36.0f;
}



-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    int nSection = indexPath.section;
    switch (nSection)
    {
          case 0:
       {
           
       }
          break;
            
          case 1:
       {
           self.refreshFlag = NO;
           UpdatePwdViewController* temp = [[UpdatePwdViewController alloc] init];
           //AppDelegate* app = [AppDelegate getApp];
           //[temp setAccount:app.Account];
           [self.navigationController pushViewController:temp animated:YES];
       }
          break;
            
          case 2:
       {
           self.refreshFlag = NO;
           UpdateMobileViewController* temp = [[UpdateMobileViewController alloc] init];
           [self.navigationController pushViewController:temp animated:YES];
       }
          break;
            
        case 3:
       {
           self.refreshFlag = NO;
           UpdateEmailViewController* temp = [[UpdateEmailViewController alloc] init];
           [self.navigationController pushViewController:temp animated:YES];
       }
          break;
            
        
        default:
            break;
    }
}


//点击返回
- (void)backToPrevious
{
    self.refreshFlag = YES;
    [self.viewDeckController toggleLeftViewAnimated:YES];
    
}

@end
