//
//  ActDetailCell.h
//  Miteno
//
//  Created by HWG on 14-3-18.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import <UIKit/UIKit.h>
#define kActDetailSpace 15
@interface ActDetailCell : UITableViewCell
@end
