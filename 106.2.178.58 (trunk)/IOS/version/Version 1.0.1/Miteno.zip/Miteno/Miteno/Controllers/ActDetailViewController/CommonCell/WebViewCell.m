//
//  webViewCell.m
//  Miteno
//
//  Created by wg on 14-5-16.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "webViewCell.h"
#define kClaimedSpace 25    //设置与左边缘距离
@implementation WebViewCell

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        //        self.selectionStyle = UITableViewCellSelectionStyleGray;
        [self addChildViews];
        self.bounds = CGRectMake(0, 0, 290, 88);
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}
- (void)addChildViews
{
    CGSize size = self.frame.size;
    
    _header = [[UILabel alloc] init];
    _header.textColor = Orange;
    [_header setFont:[UIFont systemFontOfSize:20]];
    _header.backgroundColor = [UIColor clearColor];
    _header.frame= CGRectMake(15, 0,size.width-100,44);
    [self addSubview:_header];
    
    _claimed = [UIButton buttonWithType:UIButtonTypeCustom];
    _claimed.frame = CGRectMake(0,0,80, 40);
    _claimed.center = CGPointMake(self.width-kClaimedSpace-25,self.height/2);
    [_claimed setBackgroundImage:[UIImage stretchImageWithName:@"word_botton_orenge.png"] forState:UIControlStateNormal];
    [_claimed setTitle:@"领取" forState:UIControlStateNormal];
    [self addSubview:_claimed];
    
    _horizontal = [[UIImageView alloc] init];
//    _horizontal.backgroundColor = [UIColor blackColor];
    _horizontal.frame = CGRectMake(10, _header.frame.size.height,self.width-30, 0.5);
    _horizontal.backgroundColor = white3;
//    [self addSubview:_horizontal];
    
//    dispatch_async(dispatch_get_main_queue(), ^{
//        self.web = [[UIWebView alloc] init];
//        self.web.backgroundColor = [UIColor redColor];
//        self.web.frame = CGRectMake(_header.frame.origin.x,_horizontal.frame.size.height+_header.height,self.frame.size.width-30,44*3);
//        [self.web loadHTMLString:detail.content baseURL:nil];
//        [self addSubview:_web];    // *** 将UI操作放到主线程中执行 ***
//    });

}
@end
