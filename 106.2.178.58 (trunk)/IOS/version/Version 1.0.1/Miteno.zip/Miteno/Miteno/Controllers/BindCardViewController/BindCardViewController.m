//
//  BasicSettingViewController.m
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//
#import "BindCardViewController.h"
#import "PayCard.h"
#import "PayCell.h"
#import "NSObject(Refresh).h"
#import "CardBagViewController.h"
#import "AppDelegate.h"


#define kBindCardPageMax     4

@interface BindCardViewController ()

@property  (nonatomic, assign)  int AppTotal;

@property  (nonatomic, assign)  int AppCurPage;

@property  (nonatomic, strong)  UITableView*  AppTable;

@property  (nonatomic, strong)  NSMutableArray* AppArray;

@property  (nonatomic, assign)  BOOL RefreshFlag;

@end


@implementation BindCardViewController

@synthesize AppTotal;

@synthesize AppCurPage;

@synthesize AppArray;

@synthesize AppTable;

@synthesize RefreshFlag;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"新卡绑定";
        self.view.backgroundColor = [UIColor whiteColor];
        self.AppArray = [[NSMutableArray alloc] init];
        self.AppTotal = 0;
        self.AppCurPage = 1;
        self.RefreshFlag = FALSE;
    }
    return self;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self NavigationViewBackBtn];
    
    NSLog(@"screenHeight - IOS7Y = %f",ScreenHeight - IOS7Y);
    self.AppTable = [[UITableView alloc] initWithFrame:CGRectMake(0, ZeroY, ScreenWidth, ScreenHeight) style:UITableViewStylePlain];
    [AppTable setDelegate:self];
    [AppTable setDataSource:self];
    [AppTable setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [AppTable setBackgroundColor:[UIColor clearColor]];
    [self.view addSubview:AppTable];
    
    [self RefreshData:AppTable
     up:
    ^{
        [self RequestCards:UIRefreshUp];
     }
     down:
    ^{
        [self RequestCards:UIRefreshDown];
     }];

    [[NSNotificationCenter defaultCenter]
     addObserver:self selector:@selector(ClickButton:) name:@"CellClick" object:nil];
}


-(void)ClickButton:(NSNotification*)notification
{
   if(!self.RefreshFlag)
   {
       self.RefreshFlag = TRUE;
   }
}


-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:YES];
    [self  RequestList];
}


- (void)RequestList
{
      [self RequestCards:UIRefreshStart];
    
}


- (void)RequestCards:(UIRefreshStyle)style
{
    NSLog(@"total = %d",AppTotal);
    if(![self CheckRefresh:self.AppCurPage total:AppTotal pageMax:kBindCardPageMax style:style])return;
    
    NSString*  testURL =  [NSString stringWithFormat:@"%@%@",  WEB_SERVICE_ENV_VAR,Key_App_Card_All_List];
    
    int curPage = [self RefreshIndex:style curr:self.AppCurPage];

    AppDelegate* app = [AppDelegate getApp];
    NSString* city_code = [app getCityCode];
    
    NSDictionary* dic = [NSDictionary dictionaryWithObjectsAndKeys:
        [NSString stringWithFormat:@"%d",curPage],@"page",
        [NSString stringWithFormat:@"%d",kBindCardPageMax],@"rows",
        @"0",  @"appType",
        city_code, @"city",      //城市编码
        nil];
    
    [self.AppArray removeAllObjects];
    
    HttpService*  tempservice = [HttpService  HttpInitPostForm:testURL
           body:dic
        withHud:YES];
    
    [tempservice setDelegate:self];
    
    [tempservice  setDataHandler:^(NSString* data)
     {
         NSLog(@"data = %@",data);
         [self ParseJsonToDictionary:data block:^(int Total, NSDictionary *dic) {
             __block PayCard* object = [[PayCard alloc] initWithDictionary:dic];
             NSLog(@"paycard.name = %@",object.app_name);
             
             NSLog(@"paycard.no = %@",object.app_card_no);
             
             NSString* AppID = [NSString stringWithFormat:@"%@",dic[@"id"]];
             [object setID:AppID];
             
             if(self.AppTotal==0&&Total>0)
                 self.AppTotal = Total;
             
             
             [self.AppArray addObject:object];
             
         }];
         
         self.AppCurPage = [self NewCurrIndex:self.AppCurPage total:AppTotal pageMax:kBindCardPageMax style:style];
         
         dispatch_async(dispatch_get_main_queue(),
        ^{
             [self.AppTable reloadData];
         });
     }
     ];
    [tempservice setErrorHandler:^(NSError* error)
     {
         dispatch_async(dispatch_get_main_queue(),
      ^{
         [self.view makeToast:@"网络状况不佳"];
       });
     }];
    [tempservice startOperation];
}


-(NSInteger)tableView:(UITableView *)tableView
numberOfRowsInSection:(NSInteger)section
{
    return [self.AppArray count];
    //return 10;
}


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 132;
}


-(UITableViewCell *)tableView:(UITableView *)tableView
		cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"ListPay";
    
    int Row = [indexPath row];
    
    PayCell *cell = (PayCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    PayCard*  tempobject = self.AppArray[Row];
    
    if(cell==nil)
    {
        cell = [[PayCell alloc] initCustom];
    }
    [cell SetPayCardObject:tempobject];
    return cell;
}


- (void)backToPrevious
{
    if(self.RefreshFlag)
{
    self.RefreshFlag = FALSE;
    CardBagViewController*  VCtr = (CardBagViewController*)[self GetPreController];
    [VCtr setCardRefreshFlag:FALSE];
}
    [self.navigationController  popViewControllerAnimated:YES];
}



-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
}


-(void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:YES];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

