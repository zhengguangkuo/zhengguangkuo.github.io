//
//  AccountViewController.m
//  Miteno
//
//  Created by HWG on 14-3-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "UpdateMobileViewController.h"
#import "UIView(category).h"
#import "UIButton(addtion).h"
#import "UIImage(addition).h"
#import "NSString(Additions).h"
#import "TextStyle.h"
#import "AccountViewController.h"
#import "Utilities.h"



#define  Introduce_Text   @"    点击\"获取\"按钮将发送验证码到您上方所填的手机，收到后请将验证码填入上方空白处。"

@interface UpdateMobileViewController ()<UITextFieldDelegate>

@end



@implementation UpdateMobileViewController


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = @"修改号码";
        self.view.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self  NavigationViewBackBtn];

    UITapGestureRecognizer*tap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(ResignKeyBoard)];
    [self.view addGestureRecognizer:tap];

    
    UILabel* mobileLabel = [[UILabel alloc] initWithFrame:CGRectMake(6, TableExtraHeight + 15, 80, 30)];
    [mobileLabel setBackgroundColor:[UIColor clearColor]];
    [mobileLabel setTextColor:[UIColor blackColor]];
    [mobileLabel setText:@"新手机号码"];
    [mobileLabel setFont:[UIFont systemFontOfSize:14.0f]];
    [self.view addSubview:mobileLabel];

    UITextField* input = [[UITextField alloc] initWithFrame:CGRectMake(80, mobileLabel.frame.origin.y, 223, 30)];
    input.keyboardType = UIKeyboardTypeDefault;
    input.returnKeyType = UIReturnKeyDefault;
    [input setTag:3];
    [input setDelegate:self];
    input.leftViewMode=UITextFieldViewModeAlways;
    input.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 3, 30)];

    input.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [input setFont:[UIFont systemFontOfSize:14.0f]];
    [input  ViewWithBorder:[UIColor lightGrayColor]];
    [self.view addSubview:input];

    UILabel* tempLabel = [[UILabel alloc] initWithFrame:CGRectMake(6, TableExtraHeight + 65, 80, 30)];
    [tempLabel setBackgroundColor:[UIColor clearColor]];
    [tempLabel setTextColor:[UIColor blackColor]];
    [tempLabel setText:@"输入验证码"];
    [tempLabel setFont:[UIFont systemFontOfSize:14.0f]];
    [self.view addSubview:tempLabel];

    
    UITextField* input2 = [[UITextField alloc] initWithFrame:CGRectMake(80, tempLabel.frame.origin.y, 160, 30)];
    input2.keyboardType = UIKeyboardTypeDefault;
    input2.returnKeyType = UIReturnKeyDefault;
    [input2 setTag:4];
    [input2 setDelegate:self];
    input2.leftViewMode=UITextFieldViewModeAlways;
    input2.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 3, 30)];
    [input2 setFont:[UIFont systemFontOfSize:14.0f]];
    [input2  ViewWithBorder:[UIColor lightGrayColor]];
    [self.view addSubview:input2];

    
    UIButton*  pickButton = [UIButton ButtonWithParms:[UIColor blackColor] title:@"获取" bgnormal:[UIImage generateFromColor:[UIColor colorWithRed:0.9 green:0.9 blue:0.9 alpha:1]] imgHighlight:nil target:self action:@selector(RequestGetValid)];
    [pickButton setFrame:CGRectMake(input2.frame.origin.x + input2.frame.size.width + 3, input2.frame.origin.y, 60, 30)];
    [pickButton  ViewWithBorder:[UIColor blackColor]];
    [self.view addSubview:pickButton];
    
    UILabel*  introduceLabel = [[UILabel alloc] initWithFrame:CGRectMake(6, pickButton.frame.origin.y + pickButton.frame.size.height + 18, 290, 100)];
    [introduceLabel setFont:[UIFont systemFontOfSize:14.0f]];
    [introduceLabel setNumberOfLines:0];
    [introduceLabel setTextColor:[UIColor lightGrayColor]];
    [introduceLabel setBackgroundColor:[UIColor clearColor]];
    [self.view addSubview:introduceLabel];
    [introduceLabel setText:Introduce_Text];
    
    [TextStyle alignLabelWithTop:introduceLabel];
    
    
    UIImage* LightImage = [UIImage imageNamed:@"btn_bg_light"];
    UIButton*  okBtn = [UIButton ButtonWithParms:[UIColor whiteColor] title:@"确认" bgnormal:LightImage imgHighlight:nil target:self action:@selector(requestUpdateMobile)];
    [okBtn setFrame:CGRectMake(ScreenWidth/2 - 60, introduceLabel.frame.origin.y + introduceLabel.frame.size.height + 20, 120, 40)];
    [self.view addSubview:okBtn];
}


- (void)ResignKeyBoard
{
    UITextField*  textFiled = (UITextField*)[self.view viewWithTag:3];
    
    UITextField*  textFiled2 = (UITextField*)[self.view viewWithTag:4];
    
    [textFiled resignFirstResponder];
    [textFiled2 resignFirstResponder];
}



- (void)RequestGetValid
{
    UITextField*  textFiled = (UITextField*)[self.view viewWithTag:3];
    
    UITextField*  textFiled2 = (UITextField*)[self.view viewWithTag:4];

    [textFiled resignFirstResponder];
    [textFiled2 resignFirstResponder];
    
    
    NSString*  MobileNumber = [textFiled text];
    
    if(IsEmptyString(MobileNumber))
    {
        [self.view makeToast:@"手机号码不能为空!"];
        return;
    }
    
    if(![NSString checkPhone:MobileNumber])
    {
        [self.view makeToast:@"请输入正确格式的手机号码!"];
        return;
    }
    
    NSLog(@"get code");
    NSString*  validCodeURL =  [NSString stringWithFormat:@"%@mpayFront/getCode",  WEB_SERVICE_ENV_VAR];
    NSLog(@"validCodeURL = %@",validCodeURL);
    
    NSDictionary*  dic = [[NSDictionary alloc] initWithObjectsAndKeys:MobileNumber,@"mobile", nil];
    
    [SystemDialog alert:@"请求已发送..."];
    HttpService*  tempservice = [HttpService HttpInitPostForm:validCodeURL
                                                         body:dic
                                                      withHud:YES];
    
    [tempservice  setDataHandler:^(NSString* data)
     {
         NSLog(@"response getcode str = %@",data);
         NSDictionary *dict = [data objectFromJSONString];
         
         [SystemDialog alert:[dict objectForKey:@"message"]];

     }];
    
    [tempservice setErrorHandler:^(NSError* error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [SystemDialog alert:kConnectFailure];
        });
    }];
    
    [tempservice startOperation];
}



- (void)viewDidAppear:(BOOL)animated
{
    [super  viewDidAppear:YES];
    dispatch_async(dispatch_get_main_queue(),
    ^{
         UITextField*  textFiled = (UITextField*)[self.view viewWithTag:3];
         [textFiled becomeFirstResponder];
     });

    
    
    
}



- (void)requestUpdateMobile
{
    NSString*  testURL =  [NSString stringWithFormat:@"%@%@",  WEB_SERVICE_ENV_VAR,Key_Secrity_UpdateMobile];
    NSLog(@"testURL = %@",testURL);
    
    UITextField*  Filed1 = (UITextField*)[self.view viewWithTag:3];
    NSString* mobileNo = [Filed1 text];
   
    UITextField*  Filed2 = (UITextField*)[self.view viewWithTag:4];
    NSString* valideNo = [Filed2 text];
    
    [Filed1 resignFirstResponder];
    [Filed2 resignFirstResponder];
    

    if(IsEmptyString(mobileNo))
    {
        [self.view makeToast:@"手机号码不能为空!"];
        return;
    }
    
    if(![NSString checkPhone:mobileNo])
    {
        [self.view makeToast:@"请输入正确格式的手机号码!"];
        return;
    }

    if(IsEmptyString(valideNo))
    {
        [self.view makeToast:@"验证码不能为空!"];
        return;
    }

    NSDictionary* dic = [NSDictionary dictionaryWithObjectsAndKeys:
                         mobileNo,@"mobile",
                         valideNo,@"valid_code",
                         nil];
    
    HttpService*  tempservice = [HttpService  HttpInitPostForm:testURL
                    body:dic
                 withHud:YES];
    
    [tempservice  setDataHandler:^(NSString* data)
     {
         NSLog(@"return data = %@",data);
         
         [self ParseJsonToMessage:data block:^{
         dispatch_async(dispatch_get_main_queue(),
        ^{
            AccountViewController* AVCtr = (AccountViewController*)[self GetPreController];
            [AVCtr setRefreshFlag:YES];

            [self backToPrevious];
         });

         }];

     }
     ];
    [tempservice startOperation];

}

@end
