//
//  RegisterScrollView.h
//  Miteno
//
//  Created by HWG on 14-2-27.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface RegisterScrollView : UIScrollView
@end
