//
//  DisMerDetailViewController.h
//  Miteno
//
//  Created by wg on 14-3-28.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "RootViewController.h"

@interface DisMerDetailViewController : RootViewController
@property (nonatomic, copy)NSString * intro;    //商家详情介绍
@end
