//
//  DisMerViewController.h
//  Miteno
//
//  Created by zhengguangkuo on 14-5-7.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "RootViewController.h"
#import "BaseNavigationController.h"
#import "MerchantDet.h"

@interface DisMerViewController : RootViewController<UITableViewDataSource,UITableViewDelegate,CLLocationManagerDelegate>
@property (nonatomic,strong)BaseNavigationController *navigation;
@property (nonatomic, strong)MerchantDet * merchantDet;

@end
