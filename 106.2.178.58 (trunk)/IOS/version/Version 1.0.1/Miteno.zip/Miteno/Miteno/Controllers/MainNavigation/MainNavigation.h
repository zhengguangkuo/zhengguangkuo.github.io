//
//  MainNavigation.h
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright wenguang 2014年. All rights reserved.
// 暂且未用到此类 测试...

#import <UIKit/UIKit.h>

@interface MainNavigation : UINavigationBar<UINavigationBarDelegate>

-(void)NavigationViewBackBtn:(UIButton*)back;

-(void)NavigationTitle:(NSString*)title;

-(void)NavigationViewRightBtns:(NSArray*)buttons;

-(void)NavigationBgImage:(NSString*)imageName;


@end
