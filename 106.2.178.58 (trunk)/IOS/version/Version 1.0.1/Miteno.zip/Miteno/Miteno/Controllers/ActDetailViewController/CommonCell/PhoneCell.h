//
//  PhoneCell.h
//  Miteno
//
//  Created by wg on 14-4-2.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "ActDetailCell.h"

@interface PhoneCell : ActDetailCell
@property (nonatomic, strong, readonly) UILabel *number;
@property (nonatomic, strong, readonly) UIButton *phoneIcon;
@end
