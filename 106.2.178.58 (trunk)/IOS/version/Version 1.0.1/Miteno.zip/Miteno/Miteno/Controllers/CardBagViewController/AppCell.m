//
//  ImageTableViewCell.m
//  NSOperationTest
//
//  Created by jhwang on 11-10-30.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//
#import "AppCell.h"
#import "AppCard.h"
#import "UIImageView+DispatchLoad.h"
#import "UIView(category).h"


@implementation AppCell

@synthesize imageView;

@synthesize mCard;

- (id)initCustom
{
    self = [super init];
    if(self)
    {
        self = [[[NSBundle mainBundle] loadNibNamed:@"AppCell" owner:self options:nil] lastObject];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        
        [self setBackgroundColor:[UIColor clearColor]];
        [self.contentView setBackgroundColor:[UIColor clearColor]];
        [self ViewWithBorder:[UIColor lightGrayColor]];
        
    }
    return self;
}


- (void)SetCardObject:(AppCard*)card
{
    self.mCard = card;
    [self.imageView setImage:[UIImage imageNamed:@"adload.png"]];
    [self.imageView setImageFromUrl:mCard.mpayApp.pic_path];
}



@end
