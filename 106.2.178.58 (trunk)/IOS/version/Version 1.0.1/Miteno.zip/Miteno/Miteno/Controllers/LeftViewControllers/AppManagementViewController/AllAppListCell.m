//
//  AllAppListCell.m
//  Miteno
//
//  Created by wg on 14-4-12.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "AllAppListCell.h"
@interface AllAppListCell()
{
    UIButton        *_current;
}
@end
@implementation AllAppListCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code

    }
    return self;
}
- (void)awakeFromNib
{
    UIImageView *bg = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"leather_bg.png"]];
    self.backgroundView = bg;
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    [self.binding setBackgroundImage:[UIImage imageNamed:@"checkbox_normal.png"] forState:UIControlStateNormal];
    [self.binding setBackgroundImage:[UIImage  imageNamed:@"checkbox_pressed.png"]forState:UIControlStateSelected];
    self.binding.adjustsImageWhenHighlighted = NO;

}


@end