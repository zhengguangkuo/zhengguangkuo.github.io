//
//  ActDetailCell.m
//  Miteno
//
//  Created by HWG on 14-3-18.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "ActDetailCell.h"

@interface ActDetailCell()
{
//    UILabel     *_headerText;
//    UITextView  *_textView;
//    UILabel     *_content;
//    UIButton    *_contentBtn;
//    UIButton    *_icon;
}
@end
@implementation ActDetailCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        //设置背景
//        [self setBg];
        //添加所有子控件
//        [self addChildSubviews];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}
- (void)setBg
{
    //设置cell的背景
    UIImageView *img = [[UIImageView alloc] init];
    img.image = [UIImage stretchImageWithName:@"common_card_background.png"];
    self.backgroundView = img;

}
- (void)setFrame:(CGRect)frame
{
    frame.origin.x = kActDetailSpace;
    frame.size.width -= 2*kActDetailSpace;
    [super setFrame:frame];
}
@end
