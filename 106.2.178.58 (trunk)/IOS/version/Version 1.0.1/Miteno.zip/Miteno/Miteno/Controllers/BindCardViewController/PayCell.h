//
//  ImageTableViewCell.h
//  NSOperationTest
//
//  Created by jhwang on 11-10-30.
//  Copyright 2011年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

@class PayCard;


@interface PayCell : UITableViewCell{

}
@property (weak, nonatomic) IBOutlet UIImageView *LeftImageView;
@property (weak, nonatomic) IBOutlet UILabel *EnterNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *CardNameLabel;

@property (weak, nonatomic) IBOutlet UIButton *BindBtn;

@property  (nonatomic, strong) PayCard* mPayCard;

- (id)initCustom;

- (void)SetPayCardObject:(PayCard*)card;



@end
