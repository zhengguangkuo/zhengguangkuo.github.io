//
//  CouponCell.h
//  Miteno移动支付
//
//  Created by HWG on 13-11-18.
//  Copyright (c) 2013年 miteno. All rights reserved.
//优惠劵 

#import <UIKit/UIKit.h>

@interface CouponCell : UITableViewCell
//图片
@property (weak, nonatomic) IBOutlet UIImageView *icon;
//商家优惠
@property (weak, nonatomic) IBOutlet UILabel *cname;
//商家信息
@property (weak, nonatomic) IBOutlet UILabel *merchantMessage;
//有效限
@property (weak, nonatomic) IBOutlet UILabel *deadline;
//发行数量
@property (weak, nonatomic) IBOutlet UILabel *issueCount;
//距离
@property (weak, nonatomic) IBOutlet UILabel *distance;

@end
