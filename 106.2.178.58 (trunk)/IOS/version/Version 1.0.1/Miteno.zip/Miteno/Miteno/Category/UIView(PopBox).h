#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>

#import "UICustAlertView.h"

@interface UIView(PopBox)

- (void)drawPopBox:(NSString*)msg title:(NSString*)text  input:(void(^)(void))inputblock style:(UIAlertStyle)style;






@end
