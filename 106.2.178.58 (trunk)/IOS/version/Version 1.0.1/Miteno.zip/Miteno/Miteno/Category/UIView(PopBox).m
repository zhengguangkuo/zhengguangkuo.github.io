#import "UIView(PopBox).h"
#import "TextStyle.h"
#import "UIView(category).h"

@implementation UIView(PopBox)

- (void)drawPopBox:(NSString*)msg title:(NSString*)text  input:(void(^)(void))inputblock style:(UIAlertStyle)style
{
    UIView* LabelbgView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 56)];
    [LabelbgView setBackgroundColor:[UIColor clearColor]];
    
    
    UILabel* input =[[UILabel alloc] initWithFrame:CGRectMake(7, 15, 293, 36)];
    [input setNumberOfLines:0];
    UIFont* font = [UIFont boldSystemFontOfSize:14.0f];
    [input setBackgroundColor:[UIColor blackColor]];
    [input setFont:font];
    [input  ViewWithBorder:[UIColor clearColor]];
    [input setText:msg];
    [input setTextColor:[UIColor whiteColor]];
    
    CGFloat heightValue = [TextStyle deriveTextHeight:msg width:300.0f font:font];
    
    CGFloat height = (CGFloat)heightValue>36.0?heightValue:36.0;
    
    [input setFrame:CGRectMake(7, 15, 293, height)];
    
    
    [LabelbgView setFrame:CGRectMake(0, 0, 300, height + 30)];
    [LabelbgView addSubview:input];
    
    dispatch_async(dispatch_get_main_queue(),
                   ^{
                       UICustAlertView*  alertview = [[UICustAlertView alloc]initWithAlertContent:LabelbgView title:text style:style];
                       [alertview setYesBlock:
                        ^{
                            if(inputblock)
                            {
                                inputblock();
                            }
                        }];
                   });
}

@end

