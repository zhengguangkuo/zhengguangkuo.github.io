//
//  CateMerch.h
//  Miteno
//
//  Created by wg on 14-4-10.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "BaseModel.h"

@interface CateMerch : BaseModel
@property (nonatomic, copy)NSString * ID;
@property (nonatomic, copy)NSString * type_code;
@property (nonatomic, copy)NSString * type_name;
@property (nonatomic, copy)NSString * type_level;
@property (nonatomic, copy)NSString * super_type;
@end
