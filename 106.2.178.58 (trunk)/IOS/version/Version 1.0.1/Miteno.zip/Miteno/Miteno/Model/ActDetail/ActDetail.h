//
//  ActDetail.h
//  Miteno
//
//  Created by HWG on 14-3-19.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "BaseModel.h"

@interface ActDetail : BaseModel
@property (nonatomic, copy) NSString  * picPath;    //图片
@property (nonatomic, copy) NSString  * content;      //活动详情
@property (nonatomic, copy) NSString  * detailMeg;    //商家详情
@property (nonatomic, copy) NSString  * dayLimit;     //每天最多发行量
@property (nonatomic, copy) NSString  * personLimit;  //每人最多领用数量
@property (nonatomic, copy) NSString  * maxPieces;     //一笔消费最多使用张数
@property (nonatomic, copy) NSString  * dayCnt;       //当天发行量
@property (nonatomic, copy) NSString  * startDate;    //有效期开始日期
@property (nonatomic, copy) NSString  * endDate;      //结束时间
@property (nonatomic, copy) NSString  * address;      //商家地址
@property (nonatomic, copy) NSString  * telephone;    //联系方式
@property (nonatomic, copy) NSString  * couponIssuerId;//发卷系统标示

@property (nonatomic, copy)NSString *lowAmtRule;    //

//Y	最低消费金额：actDetail.lowAmtRule
//一笔消费最多使用的张数：actDetail.max_pieces,
//其他使用规则:actDetail.detail,
@end
