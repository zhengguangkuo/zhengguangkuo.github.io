//
//  UsermapyApp.h
//  Miteno
//
//  Created by wg on 14-4-14.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "BaseModel.h"

@interface UsermapyApp : BaseModel
@property (nonatomic, copy) NSString    * app_name;
@property (nonatomic, copy) NSString    * app_type;
@property (nonatomic, copy) NSString    * detail;
@property (nonatomic, copy) NSString    * instName;
@property (nonatomic, copy) NSString    * pic_path;
@end
