//
//  UsermapyApp.m
//  Miteno
//
//  Created by wg on 14-4-14.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "UsermapyApp.h"

@implementation UsermapyApp
- (id)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.app_name = dict[@"app_name"];
        self.app_type = dict[@"app_type"];
        self.detail = dict[@"detail"];
        self.instName = dict[@"instName"];
        self.pic_path = dict[@"pic_path"];
        
    }
    return self;
}
@end
