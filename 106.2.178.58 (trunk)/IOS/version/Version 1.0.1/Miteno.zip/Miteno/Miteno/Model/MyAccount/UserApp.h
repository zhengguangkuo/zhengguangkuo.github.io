//
//  UserApp.h
//  Miteno
//
//  Created by wg on 14-4-12.
//  Copyright (c) 2014年 wenguang. All rights reserved.
// 用户绑定的详情应用

#import "BaseModel.h"
@class UserAppId,UsermapyApp;
@interface UserApp : BaseModel

@property (nonatomic, copy) NSString    * app_card_no;

@property (nonatomic, copy) NSString    * isDefault; //isDefault值为1为默认支付应用为0不是默认的
@property (nonatomic, copy) NSString    * action;   //绑定标示。解绑 unBind

@property (nonatomic, strong) UserAppId     * ID;
@property (nonatomic, strong) UsermapyApp   * mpayApp;



@end
