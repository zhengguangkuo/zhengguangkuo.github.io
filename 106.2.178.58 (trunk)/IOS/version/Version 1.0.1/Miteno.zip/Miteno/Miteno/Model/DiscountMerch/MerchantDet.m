//
//  MerchantDet.m
//  Miteno
//
//  Created by zhengguangkuo on 14-4-22.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "MerchantDet.h"

@implementation MerchantDet

- (id)initWithDictionary:(NSDictionary *)dict
{
    if (self = [super initWithDictionary:dict]) {
        self.merchId = dict[@"id"];
        self.cName = dict[@"cname"];
        self.cshost = dict[@"cshort"];
        self.coordinate = dict[@"coordinate"];
        self.trademark_pic = dict[@"trademark_pic"];
        self.distance = [dict[@"mpayUser_merchant_distance"]doubleValue];
    }
    return  self;
}
@end
