//
//  BasicCard.h
//  M-Pay
//
//  Created by guorong on 14-2-24.
//  Copyright miteno 2014年. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Base.h"

@interface MpayID : Base

@property (nonatomic, copy)  NSString* user_id;
@property (nonatomic, copy)  NSString* app_id;

@end



@interface MpayApp : Base

@property (nonatomic, copy)  NSString* app_type;
@property (nonatomic, copy)  NSString* app_name;
@property (nonatomic, copy)  NSString* detail;
@property (nonatomic, copy)  NSString* pic_path;
@property (nonatomic, copy)  NSString* instName;

@end


@interface AppCard : Base

@property (nonatomic, strong) MpayID* ID;
@property (nonatomic, copy)  NSString* app_card_no;
@property (nonatomic, strong) MpayApp* mpayApp;
@property (nonatomic, copy)  NSString* isDefault;

@end
