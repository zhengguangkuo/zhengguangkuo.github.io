//
//  DisCountMerch.h
//  Miteno
//
//  Created by HWG on 14-3-12.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "BaseModel.h"
#import "Merchant.h"
@class AppMer;
@interface DisCountMerch : BaseModel
@property (nonatomic, copy)NSString    *   actName;
@property (nonatomic, copy)NSString    *   picPath;
@property (nonatomic, copy)NSString    *   discount;
@property (nonatomic, copy)NSString  *   otherMerchId;                //商家编码
@property (nonatomic, strong)Merchant  *   merchant;
@property (nonatomic, strong)AppMer    *   appMer;
@end
