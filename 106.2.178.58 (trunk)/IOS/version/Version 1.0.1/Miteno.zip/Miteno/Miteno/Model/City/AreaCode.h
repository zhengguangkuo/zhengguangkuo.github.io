//
//  AreaCode.h
//  Miteno
//
//  Created by wg on 14-4-8.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "BaseModel.h"
/**/
@interface AreaCode : BaseModel
@property (nonatomic, copy)NSString * ID;
@property (nonatomic, copy)NSString * area_level;
@property (nonatomic, copy)NSString * area_name;
@property (nonatomic, copy)NSString * area_code;
@property (nonatomic, copy)NSString * phone_area_code;
@property (nonatomic, copy)NSString * super_area_code;

@end
