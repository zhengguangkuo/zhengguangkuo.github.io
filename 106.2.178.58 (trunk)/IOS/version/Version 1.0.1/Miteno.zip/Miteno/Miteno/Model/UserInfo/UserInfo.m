//
//  BasicCard.m
//  M-Pay
//
//  Created by guorong on 14-2-24.
//  Copyright miteno 2014年. All rights reserved.
//

#import "UserInfo.h"
#import "FileManager.h"
#import "AppDelegate.h"

@implementation UserInfo

@synthesize  PassWord;

@synthesize  UserName;

@synthesize  isFirstLogin;

@synthesize  Mobile;

@synthesize  Email;

@synthesize  City_Code;

@synthesize  valideMobile;


-(void)LogoutAccount
{
    [self setUserName:@""];
    [self setPassWord:@""];
    [self setEmail:@""];
    [self setMobile:@""];
    [self setValideMobile:@""];
    //初始化验证码
    NSUserDefaults  *ud= [NSUserDefaults standardUserDefaults];
    [ud setBool:NO forKey:@"ValideKey"];

    [self setIsFirstLogin:FALSE];
    AppDelegate* app = [AppDelegate getApp];
    app.isLogining = NO;
    
}

-(void)LoginAccount:(UserInfo*)account
{
    [self setPassWord:account.PassWord];
    [self setUserName:account.UserName];
    //[FileManager SaveArchive:self path:@"UserInfo"];
    AppDelegate* app = [AppDelegate getApp];
    app.isLogining = YES;
    //[app setLeftMenuDragState];
}


-(BOOL)AutoLoginAccount
{
    AppDelegate* app = [AppDelegate getApp];
    if(!app.isLogining)
  {
      id object = [FileManager ReadUnArchive:@"UserInfo"];
      UserInfo* tempobject = nil;
      if(![(NSNull*)object isKindOfClass:[NSNull class]])
      {
        tempobject = (UserInfo*)object;
        [self setUserName:tempobject.UserName];
        [self setPassWord:tempobject.PassWord];
        [app setIsLogining:YES];
        return YES;
      }
  }
     return NO;
}

@end



