//
//  BasicCard.h
//  M-Pay
//
//  Created by guorong on 14-2-24.
//  Copyright miteno 2014年. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Base.h"


@interface PayCard : Base

@property (nonatomic, copy) NSString*  ID;

@property (nonatomic, copy) NSString*  app_type;

@property (nonatomic, copy) NSString*  app_name;

@property (nonatomic, copy) NSString*  detail;

@property (nonatomic, copy) NSString*  pic_path;

@property (nonatomic, copy) NSString*  bind_flag;

@property (nonatomic, copy) NSString*  app_card_no;

@property (nonatomic, copy) NSString*  instName;

@end
