//
//  Merchant.m
//  Miteno
//
//  Created by HWG on 14-3-12.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "Merchant.h"

@implementation Merchant
- (id)initWithDict:(NSDictionary *)dict
{
    if (self = [super initWithDict:dict]) {
        //商家信息
        self.cName = dict[@"cname"];
        self.distance = [dict[@"mpayUser_merchant_distance"] doubleValue];
    }
    return self;
}
@end
