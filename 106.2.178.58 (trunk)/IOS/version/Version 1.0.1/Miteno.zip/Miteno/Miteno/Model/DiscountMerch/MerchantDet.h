//
//  MerchantDet.h
//  Miteno
//
//  Created by zhengguangkuo on 14-4-22.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MerchantDet : NSObject
//add by zgk
@property (nonatomic,copy)NSString * merchId;
@property (nonatomic,copy)NSString * cName;
@property (nonatomic,assign)double distance;
@property (nonatomic,copy)NSString * cshost;
@property (nonatomic,copy)NSString * coordinate;
@property (nonatomic,copy)NSString * trademark_pic;
@end
