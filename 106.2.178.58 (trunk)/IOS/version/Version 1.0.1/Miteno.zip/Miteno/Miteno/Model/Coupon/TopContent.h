//
//  TopContent.h
//  M-pay(Model)
//
//  Created by HWG on 13-12-5.
//  Copyright (c) 2013年 miteno. All rights reserved.
//

#import "BaseModel.h"

@interface TopContent : BaseModel
@property (nonatomic, copy)NSString * idStr;            //主键ID
@property (nonatomic, copy)NSString * image_path;       //图片路径
@property (nonatomic, copy)NSString * url;              //访问路径
@property (nonatomic, copy)NSString * display_order;    //显示的顺序
@property (nonatomic, copy)NSString * display_level;
@end
