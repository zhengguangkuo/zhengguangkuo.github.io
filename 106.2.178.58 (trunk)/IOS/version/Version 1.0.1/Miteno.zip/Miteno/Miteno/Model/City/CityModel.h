//
//  CityModel.h
//  Miteno
//
//  Created by HWG on 14-2-24.
//  Copyright wenguang 2014年. All rights reserved.
//

//#import <Foundation/Foundation.h>
#import "Base.h"

@interface CityModel : Base
@property (nonatomic, copy)NSString * cities;
@property (nonatomic, copy)NSString * state;


@end
