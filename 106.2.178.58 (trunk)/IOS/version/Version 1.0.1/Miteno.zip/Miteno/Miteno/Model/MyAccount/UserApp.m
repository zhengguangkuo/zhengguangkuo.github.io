//
//  UserApp.m
//  Miteno
//
//  Created by wg on 14-4-12.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "UserApp.h"
#import "UserAppId.h"
#import "UsermapyApp.h"
@implementation UserApp
- (id)initWithDict:(NSDictionary *)dict
{
    if (self = [super init]) {
        self.app_card_no = dict[@"app_card_no"];
        self.isDefault = dict[@"isDefault"];
        
        NSDictionary *ids = dict[@"id"];
        if (ids) {
            self.ID = [[UserAppId alloc] initWithDict:ids];
        }
        
        NSDictionary *mpay = dict[@"mpayApp"];
        if (mpay) {
            self.mpayApp = [[UsermapyApp alloc] initWithDict:mpay];
        }
    }
    return self;
}
- (void)setAction:(NSString *)action
{
    _action = action;
    _action = @"bind";
}
@end
