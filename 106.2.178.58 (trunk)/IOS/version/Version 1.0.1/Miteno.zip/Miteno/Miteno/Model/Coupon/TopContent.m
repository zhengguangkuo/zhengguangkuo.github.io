//
//  TopContent.m
//  M-pay(Model)
//
//  Created by HWG on 13-12-5.
//  Copyright (c) 2013年 miteno. All rights reserved.
//

#import "TopContent.h"

@implementation TopContent
- (id)initWithDict:(NSDictionary *)dict
{
    if (self = [super initWithDict:dict]) {
        self.idStr = dict[@"idStr"];
        self.image_path = dict[@"image_path"];
        self.url = dict[@"url"];
        self.display_order = dict[@"display_order"];
        self.display_level = dict[@"display_level"];
    }
    return self;
}
@end
