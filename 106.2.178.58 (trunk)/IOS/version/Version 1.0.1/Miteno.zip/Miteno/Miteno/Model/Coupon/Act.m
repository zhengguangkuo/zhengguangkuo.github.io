//
//  Act.m
//  M-pay(Model)
//
//  Created by HWG on 13-12-2.
//  Copyright (c) 2013年 miteno. All rights reserved.
//

#import "Act.h"
#import "AppMer.h"
@implementation Act

- (id)initWithDict:(NSDictionary *)dict
{
    if (self = [super initWithDict:dict]) {
        
        self.idStr = dict[@"act_id"];
        
        self.merchId = dict[@"merch_id"];
        //商家信息
        self.act_name = dict[@"act_name"];
        //商家优惠信息
        self.merch_name = dict[@"merch_name"];
        //坐标
        self.coordinate = dict[@"coordinate"];

        
        self.actType = [dict[@"act_type"] intValue];
        self.voch_amt = dict[@"voch_amt"];
        self.discount = dict[@"discount"];

//        self.couponIssuer = [[CouponIssuer alloc] initWithDict:dict];
        
        self.issuer_type = dict[@"issuer_type"];
        self.issuer_id = dict[@"issuer_id"];
        self.issue_type = dict[@"issue_type"];
        //有效期开始
        self.start_date = dict[@"start_date"];
        //结束
        self.end_date = dict[@"use_end_date"];
  
        self.start_time = dict[@"start_time"];
        self.end_time = dict[@"end_time"];
        
        self.status = dict[@"status"];
        self.claimable = dict[@"claimable"];
        self.total_cnt = dict[@"total_cnt"];
        self.day_cnt = dict[@"day_cnt"];
        
        self.personal_limit = [dict[@"personal_limit"] intValue];
        self.day_limit = [dict[@"day_limit"] intValue];
        self.issued_cnt = [dict[@"issued_cnt"] intValue];
        self.exchanged_cnt = [dict[@"exchanged_cnt"] intValue];

        self.pic_path = dict[@"pic_path"];
        
        self.pic_path_m = dict[@"pic_path_m"];
        self.pic_path_s = dict[@"pic_path_s"];

        self.actRule = dict[@"act_rule"];
        
//        self.creditsRule = [[CreditsRule alloc] initWithDict:dict];
        
        self.content = dict[@"content"];
        self.lv1_category = dict[@"lv1_category"];
        self.lv2_category = dict[@"lv2_category"];
        self.distr_target = dict[@"distr_target"];
        
        self.consum_duration = dict[@"consum_duration"];
        self.dis_trtarget = [dict[@"dis_trtarget"] doubleValue];
        self.handle_flag = dict[@"handle_flag"];
        self.couponIssuerId = dict[@"couponIssuerId"];
        self.claimFlag = dict[@"claimFlag"];


    }
    return self;
}

@end
