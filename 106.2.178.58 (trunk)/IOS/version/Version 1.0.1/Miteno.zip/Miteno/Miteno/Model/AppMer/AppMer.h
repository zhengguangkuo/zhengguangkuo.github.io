//
//  AppMer.h
//  Miteno
//
//  Created by HWG on 14-3-24.
//  Copyright (c) 2014年 wenguang. All rights reserved.
//

#import "BaseModel.h"

@interface AppMer : BaseModel
@property (nonatomic, copy) NSString *appID;    //折扣商家ID
@property (nonatomic, copy) NSString *merchID;  //折扣商家应用ID
@end
