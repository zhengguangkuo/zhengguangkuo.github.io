//
//  MerchantDetail.h
//  Miteno
//
//  Created by wg on 14-4-2.
//  Copyright (c) 2014年 wenguang. All rights reserved.
/*
 直接从商户获取的接口数据
 */

#import "BaseModel.h"
@class Contact;
@interface MerchantDetail : BaseModel
@property (nonatomic, copy)   NSString    * name;             //商家名称
@property (nonatomic, copy)   NSString    * disDescription;   //雅酷折扣
@property (nonatomic, copy)   NSString    * addr;             //地址
@property (nonatomic, copy)   NSString    * xpos;             //坐标
@property (nonatomic, copy)   NSString    * ypos;
@property (nonatomic, assign) int      positiveAppraiseCount;           //好评数量
@property (nonatomic, copy)   NSString    * intro;            //详情介绍
@property (nonatomic, copy)  NSString     * busline;          //路线

@property (nonatomic, strong)Contact      * contact;          //联系信息(电话等)



@end
